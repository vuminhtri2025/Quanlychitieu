package com.vichitieu.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Slider
import androidx.compose.foundation.clickable
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.CoroutineScope
import java.util.Calendar

// ======================= TAB 5: NGÂN SÁCH & MỤC TIÊU =======================
@Composable
fun BudgetScreen(s: AppState) {
    val now = Calendar.getInstance()
    val y = now.get(Calendar.YEAR)
    val m = now.get(Calendar.MONTH)
    val spentBy = s.visible().filter { it.isExpense && sameMonth(it.time, y, m) }
        .groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
    var budgetDialog by remember { mutableStateOf(false) }
    var goalDialog by remember { mutableStateOf(false) }
    var depositFor by remember { mutableStateOf<Goal?>(null) }
    var catDialog by remember { mutableStateOf<Cat?>(null) }
    var catNew by remember { mutableStateOf(false) }
    var walletDialog by remember { mutableStateOf<Wallet?>(null) }
    var walletNew by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    val totalLimit = s.budgets.sumOf { it.limit }
    val totalSpent = s.budgets.sumOf { spentBy[it.category] ?: 0L }

    if (budgetDialog) {
        var cat by remember { mutableStateOf(expenseCats().firstOrNull()?.name ?: "Khác") }
        var amt by remember { mutableStateOf("") }
        FormDialog("Đặt ngân sách tháng", (amt.toLongOrNull() ?: 0L) > 0,
            { s.setBudget(Budget(cat, amt.toLong())); budgetDialog = false }, { budgetDialog = false }) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(expenseCats()) { c -> Pill(c.emoji + " " + c.name, cat == c.name, c.color) { cat = c.name } }
            }
            AmountField(amt, { amt = it }, "Hạn mức (₫)")
        }
    }
    if (goalDialog) {
        var name by remember { mutableStateOf("") }
        var amt by remember { mutableStateOf("") }
        FormDialog("Mục tiêu mới", name.isNotBlank() && (amt.toLongOrNull() ?: 0L) > 0,
            { s.upsertGoal(Goal(System.currentTimeMillis(), name.trim(), amt.toLong(), 0)); goalDialog = false },
            { goalDialog = false }) {
            OutlinedTextField(name, { name = it }, label = { Text("Tên mục tiêu") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            AmountField(amt, { amt = it }, "Số tiền cần đạt (₫)")
        }
    }
    depositFor?.let { g ->
        var amt by remember { mutableStateOf("") }
        FormDialog("Nạp vào “${g.name}”", (amt.toLongOrNull() ?: 0L) > 0,
            { s.upsertGoal(g.copy(saved = g.saved + amt.toLong())); depositFor = null }, { depositFor = null }) {
            AmountField(amt, { amt = it }, "Số tiền nạp (₫)")
        }
    }
    if (catNew || catDialog != null) {
        val orig = catDialog
        var name by remember { mutableStateOf(orig?.name ?: "") }
        var emoji by remember { mutableStateOf(orig?.emoji ?: "🏷️") }
        var income by remember { mutableStateOf(orig?.isIncome ?: false) }
        var color by remember { mutableStateOf(orig?.color ?: PALETTE[0]) }
        var err by remember { mutableStateOf("") }
        FormDialog(if (orig == null) "Thêm nhóm" else "Sửa nhóm", name.isNotBlank(),
            {
                val c = Cat(name.trim(), emoji.ifBlank { "🏷️" }, color, income, orig?.keywords ?: listOf(name.trim().lowercase()))
                val ok = if (orig == null) s.addCat(c) else s.updateCat(orig.name, c)
                if (ok) { catNew = false; catDialog = null } else err = "Tên nhóm đã tồn tại"
            },
            { catNew = false; catDialog = null }) {
            OutlinedTextField(name, { name = it }, label = { Text("Tên nhóm") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(emoji, { emoji = it.take(4) }, label = { Text("Biểu tượng (emoji)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Chi tiêu", !income, Red) { income = false }
                Pill("Thu nhập", income, Green) { income = true }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(PALETTE) { c ->
                    Box(Modifier.size(30.dp).clip(CircleShape).background(c).clickable { color = c })
                }
            }
            if (err.isNotBlank()) Text(err, color = Red, fontSize = 13.sp)
        }
    }
    if (walletNew || walletDialog != null) {
        val orig = walletDialog
        var name by remember { mutableStateOf(orig?.name ?: "") }
        var emoji by remember { mutableStateOf(orig?.emoji ?: "👛") }
        var initial by remember { mutableStateOf(if ((orig?.initial ?: 0L) > 0) orig!!.initial.toString() else "") }
        FormDialog(if (orig == null) "Thêm ví" else "Sửa ví", name.isNotBlank(),
            {
                s.upsertWallet(Wallet(orig?.id ?: System.currentTimeMillis(), name.trim(), emoji.ifBlank { "👛" },
                    initial.toLongOrNull() ?: 0L))
                walletNew = false; walletDialog = null
            },
            { walletNew = false; walletDialog = null }) {
            OutlinedTextField(name, { name = it }, label = { Text("Tên ví (VD: Tiền mặt, Momo, Techcombank)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(emoji, { emoji = it.take(4) }, label = { Text("Biểu tượng") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            AmountField(initial, { initial = it }, "Số dư ban đầu (₫)")
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Ngân sách & mục tiêu", "Kiểm soát chi tiêu, tiến tới ước mơ")
        if (msg.isNotBlank()) Text(msg, color = Orange, fontSize = 13.sp)

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Orange).padding(20.dp)) {
            Text("Ngân sách tháng ${m + 1}", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            Text(if (totalLimit > 0) "Còn ${money(totalLimit - totalSpent)}" else "Chưa đặt ngân sách",
                color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            if (totalLimit > 0) {
                Spacer(Modifier.height(10.dp))
                Bar(totalSpent.toFloat() / totalLimit, Color.White)
                Text("Đã chi ${money(totalSpent)} / ${money(totalLimit)}", color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp))
            }
        }

        // ---- Ví ----
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Title("Ví")
            Pill("+ Thêm ví", true) { walletNew = true }
        }
        s.wallets.forEach { w ->
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${w.emoji} ${w.name}", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(money(s.walletBalance(w.id)), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Sửa", false) { walletDialog = w }
                    Pill("Xóa", false, Red) {
                        if (!s.deleteWallet(w.id)) msg = "Phải giữ ít nhất 1 ví"
                        else msg = "Đã xóa ví “${w.name}”, số dư chuyển sang ví khác"
                    }
                }
            }
        }

        // ---- Nhóm ----
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Title("Nhóm")
            Pill("+ Thêm nhóm", true) { catNew = true }
        }
        Text("Chạm để sửa tên, biểu tượng, màu. Xóa nhóm sẽ chuyển các giao dịch sang nhóm “Khác”.", color = Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Chi tiêu", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(expenseCats()) { c -> Pill(c.emoji + " " + c.name, false, c.color) { catDialog = c } }
        }
        Text("Thu nhập", color = Muted, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(incomeCats()) { c -> Pill(c.emoji + " " + c.name, false, c.color) { catDialog = c } }
        }
        if (catDialog != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Xóa nhóm “${catDialog!!.name}”", false, Red) {
                    if (s.deleteCat(catDialog!!.name)) msg = "Đã xóa nhóm, giao dịch đã chuyển sang nhóm khác"
                    catDialog = null
                }
            }
        }

        // ---- Ngân sách theo nhóm ----
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Title("Ngân sách theo nhóm")
            Pill("+ Thêm", true) { budgetDialog = true }
        }
        if (s.budgets.isEmpty()) Text("Đặt hạn mức cho từng nhóm để được cảnh báo khi sắp vượt.", color = Muted, fontSize = 14.sp)
        s.budgets.forEach { b ->
            val spent = spentBy[b.category] ?: 0L
            val p = spent.toFloat() / b.limit
            val col = when { p >= 1f -> Red; p >= 0.8f -> Orange; else -> Green }
            val c = catOf(b.category)
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${c.emoji} ${b.category}", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("${(p * 100).toInt()}%", color = col, fontWeight = FontWeight.Bold)
                    Text("  ✕", color = Muted, modifier = Modifier.clickable { s.deleteBudget(b.category) })
                }
                Spacer(Modifier.height(10.dp))
                Bar(p, col)
                Text(
                    if (p >= 1f) "Vượt ${money(spent - b.limit)} • ${money(spent)} / ${money(b.limit)}"
                    else "Còn ${money(b.limit - spent)} • ${money(spent)} / ${money(b.limit)}",
                    color = if (p >= 1f) Red else Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        // ---- Mục tiêu ----
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Title("Mục tiêu tiết kiệm")
            Pill("+ Thêm", true, Green) { goalDialog = true }
        }
        if (s.goals.isEmpty()) Text("Ví dụ: Mua điện thoại mới, du lịch, quỹ khẩn cấp…", color = Muted, fontSize = 14.sp)
        s.goals.forEach { g ->
            val p = g.saved.toFloat() / g.target
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎯 ${g.name}", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("${(p * 100).toInt().coerceAtMost(100)}%", color = Green, fontWeight = FontWeight.Bold)
                    Text("  ✕", color = Muted, modifier = Modifier.clickable { s.deleteGoal(g.id) })
                }
                Spacer(Modifier.height(10.dp))
                Bar(p, Green)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${money(g.saved)} / ${money(g.target)}", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    if (g.saved < g.target) Pill("+ Nạp tiền", false) { depositFor = g }
                    else Text("Hoàn thành 🎉", color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ======================= CÀI ĐẶT: API / MÔ HÌNH / SAO LƯU =======================
@Composable
fun SettingsScreen(s: AppState, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(s.apiKey) }
    var models by remember { mutableStateOf(listOf<String>()) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }
    var restoreText by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }

    if (confirmReset) {
        ConfirmDialog("Xóa toàn bộ dữ liệu trên máy? Hãy sao lưu trước.",
            onConfirm = { s.resetAll(); confirmReset = false; status = "Đã xóa dữ liệu" },
            onDismiss = { confirmReset = false })
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("← Quay lại", color = Orange, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onClose() })
        }
        ScreenHeader("Cài đặt", "API, mô hình AI, sao lưu")

        Panel {
            Title("Google AI Studio")
            Text("Lấy API key miễn phí tại aistudio.google.com/app/apikey. Key chỉ lưu trên máy này.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
            OutlinedTextField(key, { key = it }, label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(if (busy) "Đang kiểm tra…" else "Lưu & tải danh sách mô hình", true) {
                    if (busy) return@Pill
                    scope.launch {
                        busy = true
                        s.updateApiKey(key)
                        try {
                            models = Gemini.listModels(s.apiKey)
                            status = if (models.isEmpty()) "Không có mô hình Gemini nào cho key này" else "Đã tải ${models.size} mô hình"
                        } catch (e: Exception) { status = "Lỗi: ${e.message?.take(160)}" }
                        busy = false
                    }
                }
                Pill("Xóa key", false, Red) { key = ""; s.updateApiKey(""); models = emptyList(); status = "Đã xóa key" }
            }
            if (status.isNotBlank()) Text(status, color = Orange, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }

        Panel {
            Title("Mô hình")
            Text("Đang dùng: ${s.model}", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 6.dp))
            val list = if (models.isEmpty()) listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro") else models
            list.forEach { mdl ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .clickable { s.model = mdl; s.saveSettings() }
                    .padding(vertical = 8.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (s.model == mdl) "●" else "○", color = if (s.model == mdl) Orange else Muted, modifier = Modifier.padding(end = 10.dp))
                    Text(mdl, color = Color.White, fontSize = 14.sp)
                }
            }
        }

        Panel {
            Title("Ngưỡng tự tin tự lưu: ${(s.threshold * 100).toInt()}%")
            Slider(value = s.threshold, onValueChange = { s.threshold = it }, onValueChangeFinished = { s.saveSettings() },
                valueRange = 0.5f..1f, steps = 9)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Tự tạo nhóm mới khi AI phân tích", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Switch(checked = s.autoCats, onCheckedChange = { s.autoCats = it; s.saveSettings() },
                    colors = SwitchDefaults.colors(checkedTrackColor = Orange))
            }
            Text(if (s.autoCats) "Tự tạo nhóm và chuyển giao dịch ngay." else "Hiện hộp xác nhận trước khi tạo nhóm.",
                color = Muted, fontSize = 12.sp)
        }

        Panel {
            Title("Sao lưu & khôi phục")
            Text("Dữ liệu gồm ví, giao dịch, nhóm, ngân sách, mục tiêu. Sao lưu thành JSON để bạn tự lưu (Ghi chú, Drive, email).",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
            Pill("Tạo bản sao lưu", true) { backupText = s.exportJson(); status = "Đã tạo bản sao lưu bên dưới" }
            if (backupText.isNotBlank()) {
                OutlinedTextField(backupText, {}, readOnly = true, minLines = 3, maxLines = 6,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                Text("Nhấn giữ để chọn toàn bộ, sao chép và lưu lại.", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(restoreText, { restoreText = it }, minLines = 2, maxLines = 5,
                modifier = Modifier.fillMaxWidth(), placeholder = { Text("Dán nội dung sao lưu JSON vào đây") })
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Khôi phục", false, Green) {
                    status = if (s.importJson(restoreText)) "Khôi phục thành công" else "Nội dung sao lưu không hợp lệ"
                }
                Pill("Xóa toàn bộ", false, Red) { confirmReset = true }
            }
        }

        if (status.isNotBlank()) Text(status, color = Orange, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
    }
}
@Composable
fun FormDialog(
    title: String,
    canSave: Boolean,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp), content = content) },
        confirmButton = { TextButton(enabled = canSave, onClick = onSave) { Text("Lưu", color = Orange, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = Muted) } }
    )
}


