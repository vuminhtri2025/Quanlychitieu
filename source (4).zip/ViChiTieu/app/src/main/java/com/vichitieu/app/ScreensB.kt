package com.vichitieu.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import java.util.Calendar

// ======================= TAB 3: LỊCH SỬ =======================
@Composable
fun HistoryScreen(s: AppState) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) } // 0 tất cả, 1 chi, 2 thu
    var editing by remember { mutableStateOf<Txn?>(null) }

    editing?.let { e ->
        TxnDialog(e, "Sửa giao dịch", wallets = s.wallets,
            onSave = { s.upsert(it); editing = null },
            onDelete = { s.delete(e.id); editing = null },
            onDismiss = { editing = null })
    }

    val list = s.visible().sortedByDescending { it.time }.filter {
        (filter == 0 || (filter == 1 && it.isExpense) || (filter == 2 && !it.isExpense)) &&
            (query.isBlank() || it.note.contains(query, true) || it.category.contains(query, true) ||
                it.amount.toString().contains(query))
    }
    val rows = ArrayList<Any>()
    var lastDay = -1L
    list.forEach { t ->
        val key = cal(t.time).let { it.get(Calendar.YEAR) * 1000L + it.get(Calendar.DAY_OF_YEAR) }
        if (key != lastDay) { rows.add(t.time); lastDay = key }
        rows.add(t)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenHeader("Lịch sử", "${list.size} giao dịch")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Tìm theo ghi chú, nhóm, số tiền") },
            modifier = Modifier.fillMaxWidth())
        Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Tất cả", filter == 0) { filter = 0 }
            Pill("Chi tiêu", filter == 1, Red) { filter = 1 }
            Pill("Thu nhập", filter == 2, Green) { filter = 2 }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (rows.isEmpty()) item { Text("Không có giao dịch nào.", color = Muted, modifier = Modifier.padding(top = 20.dp)) }
            items(rows) { r ->
                if (r is Long) {
                    val dayTotal = list.filter { sameDay(it.time, r) }.sumOf { if (it.isExpense) -it.amount else it.amount }
                    val label = when {
                        sameDay(r, System.currentTimeMillis()) -> "Hôm nay"
                        sameDay(r, System.currentTimeMillis() - 86_400_000L) -> "Hôm qua"
                        else -> fmtDate(r)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label, color = Muted, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text((if (dayTotal > 0) "+" else "") + money(dayTotal), color = Muted, fontSize = 13.sp)
                    }
                } else if (r is Txn) {
                    TxnRow(r) { editing = r }
                }
            }
        }
    }
}

// ======================= TAB 4: PHÂN TÍCH =======================
@Composable
fun AnalysisScreen(s: AppState) {
    var offset by remember { mutableStateOf(0) }
    val base = Calendar.getInstance().apply { add(Calendar.MONTH, offset) }
    val y = base.get(Calendar.YEAR)
    val m = base.get(Calendar.MONTH)
    val vis = s.visible()
    val month = vis.filter { sameMonth(it.time, y, m) }
    val exp = month.filter { it.isExpense }
    val inc = month.filter { !it.isExpense }.sumOf { it.amount }
    val expTotal = exp.sumOf { it.amount }
    val byCat = exp.groupBy { it.category }.map { it.key to it.value.sumOf { t -> t.amount } }.sortedByDescending { it.second }

    val prev = Calendar.getInstance().apply { add(Calendar.MONTH, offset - 1) }
    val prevExp = vis.filter { it.isExpense && sameMonth(it.time, prev.get(Calendar.YEAR), prev.get(Calendar.MONTH)) }.sumOf { it.amount }

    val daysCount = if (offset == 0) Calendar.getInstance().get(Calendar.DAY_OF_MONTH) else base.getActualMaximum(Calendar.DAY_OF_MONTH)

    val six = (5 downTo 0).map { k ->
        val c = Calendar.getInstance().apply { add(Calendar.MONTH, offset - k) }
        val ms = vis.filter { sameMonth(it.time, c.get(Calendar.YEAR), c.get(Calendar.MONTH)) }
        Triple("T${c.get(Calendar.MONTH) + 1}", ms.filter { !it.isExpense }.sumOf { it.amount }, ms.filter { it.isExpense }.sumOf { it.amount })
    }
    val maxBar = six.maxOf { maxOf(it.second, it.third) }.coerceAtLeast(1L)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Phân tích", "Hiểu tiền của bạn đi đâu")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Pill("‹", false) { offset-- }
            Text("Tháng ${m + 1}/$y", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Pill("›", false) { if (offset < 0) offset++ }
        }

        Panel {
            Title("Cơ cấu chi tiêu")
            Spacer(Modifier.height(12.dp))
            if (byCat.isEmpty()) {
                Text("Chưa có dữ liệu chi tiêu trong tháng này.", color = Muted, fontSize = 14.sp)
            } else {
                Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(180.dp)) {
                        val sw = 26.dp.toPx()
                        var start = -90f
                        byCat.forEach { (name, v) ->
                            val sweep = v.toFloat() / expTotal * 360f
                            drawArc(
                                color = catOf(name).color,
                                startAngle = start, sweepAngle = (sweep - 2f).coerceAtLeast(0.5f), useCenter = false,
                                topLeft = Offset(sw / 2, sw / 2),
                                size = Size(size.width - sw, size.height - sw),
                                style = Stroke(sw, cap = StrokeCap.Butt)
                            )
                            start += sweep
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tổng chi", color = Muted, fontSize = 12.sp)
                        Text(money(expTotal), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                byCat.forEach { (name, v) ->
                    val c = catOf(name)
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(c.color))
                        Text("  ${c.emoji} $name", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("${(v * 100 / expTotal)}%  ", color = Muted, fontSize = 13.sp)
                        Text(money(v), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Panel {
            Title("Thu – Chi 6 tháng")
            Spacer(Modifier.height(12.dp))
            Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                val slot = size.width / six.size
                val bw = slot * 0.26f
                six.forEachIndexed { i, t ->
                    val hi = (t.second.toFloat() / maxBar) * size.height
                    val he = (t.third.toFloat() / maxBar) * size.height
                    val x0 = i * slot + slot / 2
                    drawRoundRect(Green, Offset(x0 - bw - 2.dp.toPx(), size.height - hi.coerceAtLeast(3.dp.toPx())),
                        Size(bw, hi.coerceAtLeast(3.dp.toPx())), CornerRadius(6.dp.toPx()))
                    drawRoundRect(Red, Offset(x0 + 2.dp.toPx(), size.height - he.coerceAtLeast(3.dp.toPx())),
                        Size(bw, he.coerceAtLeast(3.dp.toPx())), CornerRadius(6.dp.toPx()))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                six.forEach { Text(it.first, Modifier.weight(1f), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center) }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("■ Thu", color = Green, fontSize = 12.sp)
                Text("■ Chi", color = Red, fontSize = 12.sp)
            }
        }

        AiAnalysisPanel(s)

        Panel(color = Card2) {
            Title("Nhận xét nhanh")
            Spacer(Modifier.height(8.dp))
            val avg = expTotal / daysCount.coerceAtLeast(1)
            Text("• Trung bình mỗi ngày chi ${money(avg)}", color = Color.White, fontSize = 14.sp)
            if (byCat.isNotEmpty())
                Text("• Nhóm chi nhiều nhất: ${catOf(byCat[0].first).emoji} ${byCat[0].first} (${byCat[0].second * 100 / expTotal}%)",
                    color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            if (prevExp > 0) {
                val diff = (expTotal - prevExp) * 100 / prevExp
                Text("• So với tháng trước: ${if (diff >= 0) "+" else ""}$diff% chi tiêu",
                    color = if (diff > 0) Orange else Green, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            }
            if (inc > 0) {
                val rate = (inc - expTotal) * 100 / inc
                Text("• Tỷ lệ tiết kiệm: $rate% thu nhập", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
fun AiAnalysisPanel(s: AppState) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var proposal by remember { mutableStateOf<AnalysisResult?>(null) }

    proposal?.let { p ->
        FormDialog("AI đề xuất nhóm mới", true,
            { status = applySuggestions(s, p); proposal = null }, { proposal = null }) {
            p.suggestions.forEach { Text("${it.emoji} ${it.name} • ${it.ids.size} giao dịch", color = Color.White, fontSize = 14.sp) }
            Text("Nhấn Lưu để tạo nhóm và chuyển các giao dịch tương ứng.", color = Muted, fontSize = 12.sp)
        }
    }

    Panel(color = Card2) {
        Title("🤖 AI phân tích hành vi")
        if (s.lastInsight.isNotBlank()) {
            Text(s.lastInsight, color = Color.White, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp))
        } else {
            Text("AI đọc lịch sử giao dịch, nhận xét thói quen chi tiêu và tự tạo thêm nhóm mới cho các khoản chưa có nhóm phù hợp.",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
        if (status.isNotBlank()) Text(status, color = Orange, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(10.dp))
        Pill(if (busy) "Đang phân tích…" else "Phân tích ngay", true) {
            if (busy) return@Pill
            if (s.apiKey.isBlank()) { status = "Hãy nhập API Google AI Studio trong ⚙ Cài đặt."; return@Pill }
            scope.launch {
                busy = true; status = ""
                try {
                    val r = runBehaviorAnalysis(s)
                    s.lastInsight = r.insight
                    s.lastAnalyzed = s.txns.size
                    s.saveSettings()
                    when {
                        r.suggestions.isEmpty() -> status = "Không có nhóm mới nào cần tạo."
                        s.autoCats -> status = applySuggestions(s, r)
                        else -> proposal = r
                    }
                } catch (e: Exception) { status = "Lỗi: ${e.message?.take(160)}" }
                busy = false
            }
        }
    }
}
