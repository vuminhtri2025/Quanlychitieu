package com.vichitieu.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Wallet(val id: Long, val name: String, val emoji: String, val initial: Long)

data class Txn(
    val id: Long,
    val amount: Long,
    val isExpense: Boolean,
    val time: Long,
    val category: String,
    val note: String,
    val walletId: Long
)

data class Budget(val category: String, val limit: Long)
data class Goal(val id: Long, val name: String, val target: Long, val saved: Long)

data class Cat(
    val name: String,
    val emoji: String,
    val color: Color,
    val isIncome: Boolean,
    val keywords: List<String>
)

val PALETTE = listOf(
    Color(0xFFFF762E), Color(0xFF4F8DF7), Color(0xFFB36BFF), Color(0xFFF2C94C), Color(0xFFE94343),
    Color(0xFF16A765), Color(0xFF2DD4BF), Color(0xFFEC4899), Color(0xFF9AA0AA)
)

val DEFAULT_CATS = listOf(
    Cat("Ăn uống", "🍜", PALETTE[0], false,
        listOf("ăn", "uống", "cơm", "phở", "bún", "cà phê", "cafe", "trà sữa", "nhà hàng", "bữa", "trưa", "tối", "sáng", "bia", "nước")),
    Cat("Di chuyển", "🛵", PALETTE[1], false,
        listOf("xăng", "grab", "xe", "taxi", "gửi xe", "vé xe", "bus", "buýt", "di chuyển", "đổ xăng")),
    Cat("Mua sắm", "🛍️", PALETTE[2], false,
        listOf("mua", "quần", "áo", "giày", "shopee", "lazada", "siêu thị", "đồ", "tạp hóa")),
    Cat("Hóa đơn", "🧾", PALETTE[3], false,
        listOf("điện", "nước", "wifi", "internet", "thuê nhà", "tiền nhà", "hóa đơn", "điện thoại", "cước")),
    Cat("Giải trí", "🎬", PALETTE[4], false,
        listOf("phim", "game", "du lịch", "xem", "karaoke", "netflix", "giải trí", "chơi")),
    Cat("Sức khỏe", "💊", PALETTE[5], false,
        listOf("thuốc", "bệnh viện", "khám", "bác sĩ", "gym", "sức khỏe", "nha khoa")),
    Cat("Giáo dục", "📚", PALETTE[6], false,
        listOf("học", "sách", "khóa học", "học phí", "giáo dục")),
    Cat("Khác", "📦", PALETTE[8], false, emptyList()),
    Cat("Lương", "💰", PALETTE[5], true, listOf("lương", "tiền lương")),
    Cat("Thưởng", "🎁", PALETTE[0], true, listOf("thưởng", "bonus", "lì xì")),
    Cat("Thu nhập khác", "💵", PALETTE[6], true,
        listOf("nhận", "thu nhập", "bán", "được cho", "hoàn tiền", "lãi"))
)

/** Danh sách nhóm dùng chung toàn app (có thể đổi tên / xóa / thêm). */
object CatStore { val list = mutableStateListOf<Cat>() }

fun expenseCats(): List<Cat> = CatStore.list.filter { !it.isIncome }
fun incomeCats(): List<Cat> = CatStore.list.filter { it.isIncome }
fun catOf(name: String): Cat = CatStore.list.firstOrNull { it.name == name } ?: Cat(name, "🏷️", Muted, false, emptyList())

class AppState(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("vichitieu", Context.MODE_PRIVATE)
    val txns = mutableStateListOf<Txn>()
    val budgets = mutableStateListOf<Budget>()
    val goals = mutableStateListOf<Goal>()
    val wallets = mutableStateListOf<Wallet>()

    // cài đặt
    var apiKey by mutableStateOf(prefs.getString("apiKey", "") ?: "")
        private set
    var model by mutableStateOf("gemini-2.5-flash")
    var threshold by mutableStateOf(0.8f)
    var autoCats by mutableStateOf(true)
    var lastAnalyzed by mutableStateOf(0)
    var lastInsight by mutableStateOf("")
    var activeWallet by mutableStateOf(-1L) // -1 = tất cả ví

    init { load() }

    // ---------- ví ----------
    fun defaultWalletId(): Long = (wallets.firstOrNull { it.id == activeWallet } ?: wallets.first()).id
    fun visible(): List<Txn> = if (activeWallet == -1L) txns.toList() else txns.filter { it.walletId == activeWallet }
    fun walletBalance(id: Long): Long =
        (wallets.firstOrNull { it.id == id }?.initial ?: 0L) +
            txns.filter { it.walletId == id }.sumOf { if (it.isExpense) -it.amount else it.amount }
    fun shownBalance(): Long = if (activeWallet == -1L) wallets.sumOf { walletBalance(it.id) } else walletBalance(activeWallet)

    fun upsertWallet(w: Wallet) {
        val i = wallets.indexOfFirst { it.id == w.id }
        if (i >= 0) wallets[i] = w else wallets.add(w)
        save()
    }

    fun deleteWallet(id: Long): Boolean {
        if (wallets.size <= 1) return false
        val w = wallets.firstOrNull { it.id == id } ?: return false
        val target = wallets.first { it.id != id }
        for (i in txns.indices) if (txns[i].walletId == id) txns[i] = txns[i].copy(walletId = target.id)
        val ti = wallets.indexOf(target)
        wallets[ti] = target.copy(initial = target.initial + w.initial)
        wallets.removeAll { it.id == id }
        if (activeWallet == id) activeWallet = -1L
        save()
        return true
    }

    // ---------- giao dịch ----------
    fun upsert(t: Txn) {
        if (CatStore.list.none { it.name == t.category }) {
            CatStore.list.add(Cat(t.category, "🏷️", PALETTE[CatStore.list.size % PALETTE.size], !t.isExpense, listOf(t.category.lowercase())))
        }
        val i = txns.indexOfFirst { it.id == t.id }
        if (i >= 0) txns[i] = t else txns.add(t)
        save()
    }
    fun delete(id: Long) { txns.removeAll { it.id == id }; save() }

    fun moveTxns(ids: Set<Long>, cat: String) {
        for (i in txns.indices) if (txns[i].id in ids) txns[i] = txns[i].copy(category = cat)
        save()
    }

    // ---------- nhóm ----------
    fun addCat(c: Cat): Boolean {
        if (c.name.isBlank() || CatStore.list.any { it.name.equals(c.name, true) }) return false
        CatStore.list.add(c); save(); return true
    }

    fun updateCat(old: String, n: Cat): Boolean {
        val i = CatStore.list.indexOfFirst { it.name == old }
        if (i < 0 || n.name.isBlank()) return false
        if (n.name != old && CatStore.list.any { it.name.equals(n.name, true) }) return false
        CatStore.list[i] = n
        if (n.name != old) {
            for (k in txns.indices) if (txns[k].category == old) txns[k] = txns[k].copy(category = n.name)
            for (k in budgets.indices) if (budgets[k].category == old) budgets[k] = budgets[k].copy(category = n.name)
        }
        save(); return true
    }

    /** Xóa nhóm: giao dịch của nhóm chuyển sang nhóm "Khác" cùng loại (hoặc nhóm đầu tiên còn lại). */
    fun deleteCat(name: String): Boolean {
        val c = CatStore.list.firstOrNull { it.name == name } ?: return false
        val same = CatStore.list.filter { it.isIncome == c.isIncome && it.name != name }
        val fb = same.firstOrNull { it.name == "Khác" || it.name == "Thu nhập khác" } ?: same.firstOrNull() ?: return false
        for (k in txns.indices) if (txns[k].category == name) txns[k] = txns[k].copy(category = fb.name)
        budgets.removeAll { it.category == name }
        CatStore.list.remove(c)
        save(); return true
    }

    // ---------- ngân sách / mục tiêu ----------
    fun setBudget(b: Budget) {
        val i = budgets.indexOfFirst { it.category == b.category }
        if (i >= 0) budgets[i] = b else budgets.add(b)
        save()
    }
    fun deleteBudget(cat: String) { budgets.removeAll { it.category == cat }; save() }
    fun upsertGoal(g: Goal) {
        val i = goals.indexOfFirst { it.id == g.id }
        if (i >= 0) goals[i] = g else goals.add(g)
        save()
    }
    fun deleteGoal(id: Long) { goals.removeAll { it.id == id }; save() }

    // ---------- cài đặt ----------
    fun updateApiKey(k: String) { apiKey = k.trim(); prefs.edit().putString("apiKey", apiKey).apply() }
    fun saveSettings() = save()

    fun resetAll() {
        prefs.edit().clear().apply()
        wallets.clear(); wallets.add(Wallet(1L, "Tiền mặt", "💵", 0))
        CatStore.list.clear(); CatStore.list.addAll(DEFAULT_CATS)
        txns.clear(); budgets.clear(); goals.clear()
        activeWallet = -1L; lastInsight = ""; lastAnalyzed = 0
        apiKey = ""
        save()
    }

    // ---------- lưu / sao lưu ----------
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("app", "ViChiTieu").put("version", 2).put("exportedAt", System.currentTimeMillis())
        o.put("wallets", JSONArray().also { a -> wallets.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("emoji", it.emoji).put("initial", it.initial)) } })
        o.put("cats", JSONArray().also { a -> CatStore.list.forEach {
            a.put(JSONObject().put("name", it.name).put("emoji", it.emoji).put("color", it.color.toArgb())
                .put("income", it.isIncome).put("kw", JSONArray(it.keywords))) } })
        o.put("txns", JSONArray().also { a -> txns.forEach {
            a.put(JSONObject().put("id", it.id).put("amount", it.amount).put("exp", it.isExpense).put("time", it.time)
                .put("cat", it.category).put("note", it.note).put("wid", it.walletId)) } })
        o.put("budgets", JSONArray().also { a -> budgets.forEach { a.put(JSONObject().put("cat", it.category).put("limit", it.limit)) } })
        o.put("goals", JSONArray().also { a -> goals.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("target", it.target).put("saved", it.saved)) } })
        o.put("settings", JSONObject().put("model", model).put("threshold", threshold.toDouble())
            .put("autoCats", autoCats).put("lastAnalyzed", lastAnalyzed).put("insight", lastInsight))
        return o
    }

    fun exportJson(): String = toJson().toString(2)

    fun importJson(text: String): Boolean = try {
        val o = JSONObject(text)
        if (!o.has("txns")) false else { applyJson(o); save(); true }
    } catch (e: Exception) { false }

    private fun applyJson(o: JSONObject) {
        val ws = mutableListOf<Wallet>()
        o.optJSONArray("wallets")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                ws.add(Wallet(x.getLong("id"), x.getString("name"), x.optString("emoji", "👛"), x.optLong("initial", 0)))
            }
        }
        if (ws.isEmpty()) ws.add(Wallet(1L, "Tiền mặt", "💵", 0))
        val cs = mutableListOf<Cat>()
        o.optJSONArray("cats")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val kw = mutableListOf<String>()
                x.optJSONArray("kw")?.let { k -> for (j in 0 until k.length()) kw.add(k.getString(j)) }
                cs.add(Cat(x.getString("name"), x.optString("emoji", "🏷️"), Color(x.getInt("color")), x.getBoolean("income"), kw))
            }
        }
        if (cs.isEmpty()) cs.addAll(DEFAULT_CATS)
        val ts = mutableListOf<Txn>()
        val ta = o.getJSONArray("txns")
        for (i in 0 until ta.length()) {
            val x = ta.getJSONObject(i)
            ts.add(Txn(x.getLong("id"), x.getLong("amount"), x.getBoolean("exp"), x.getLong("time"),
                x.getString("cat"), x.optString("note", ""), x.optLong("wid", ws.first().id)))
        }
        val bs = mutableListOf<Budget>()
        o.optJSONArray("budgets")?.let { a -> for (i in 0 until a.length()) { val x = a.getJSONObject(i); bs.add(Budget(x.getString("cat"), x.getLong("limit"))) } }
        val gs = mutableListOf<Goal>()
        o.optJSONArray("goals")?.let { a ->
            for (i in 0 until a.length()) { val x = a.getJSONObject(i); gs.add(Goal(x.getLong("id"), x.getString("name"), x.getLong("target"), x.getLong("saved"))) }
        }
        // ghi vào state sau khi đã đọc xong toàn bộ (tránh hỏng dữ liệu nếu file lỗi)
        wallets.clear(); wallets.addAll(ws)
        CatStore.list.clear(); CatStore.list.addAll(cs)
        txns.clear(); txns.addAll(ts)
        budgets.clear(); budgets.addAll(bs)
        goals.clear(); goals.addAll(gs)
        o.optJSONObject("settings")?.let {
            model = it.optString("model", model)
            threshold = it.optDouble("threshold", threshold.toDouble()).toFloat()
            autoCats = it.optBoolean("autoCats", autoCats)
            lastAnalyzed = it.optInt("lastAnalyzed", 0)
            lastInsight = it.optString("insight", "")
        }
        if (activeWallet != -1L && wallets.none { it.id == activeWallet }) activeWallet = -1L
    }

    private fun save() { prefs.edit().putString("data", toJson().toString()).apply() }

    private fun load() {
        val raw = prefs.getString("data", null)
        if (raw != null) try { applyJson(JSONObject(raw)) } catch (_: Exception) { }
        if (wallets.isEmpty()) wallets.add(Wallet(1L, "Tiền mặt", "💵", 0))
        if (CatStore.list.isEmpty()) CatStore.list.addAll(DEFAULT_CATS)
    }
}

// ---------- tiện ích ----------
fun money(v: Long): String {
    val s = kotlin.math.abs(v).toString().reversed().chunked(3).joinToString(".").reversed()
    return (if (v < 0) "-" else "") + s + " ₫"
}

fun moneyShort(v: Long): String = when {
    v >= 1_000_000_000 -> String.format("%.1ftỷ", v / 1e9)
    v >= 1_000_000 -> String.format("%.1ftr", v / 1e6)
    v >= 1_000 -> "${v / 1000}k"
    else -> v.toString()
}

fun cal(time: Long): Calendar = Calendar.getInstance().apply { timeInMillis = time }

fun sameMonth(time: Long, year: Int, month: Int): Boolean {
    val c = cal(time)
    return c.get(Calendar.YEAR) == year && c.get(Calendar.MONTH) == month
}

fun sameDay(a: Long, b: Long): Boolean {
    val x = cal(a); val y = cal(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

fun fmtDate(time: Long): String {
    val c = cal(time)
    return "%02d/%02d/%d".format(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR))
}

fun fmtTime(time: Long): String {
    val c = cal(time)
    return "%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
}
