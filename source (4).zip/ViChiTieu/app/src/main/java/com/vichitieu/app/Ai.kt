package com.vichitieu.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Một giao dịch do bộ phân tích (AI hoặc cơ bản) tách ra từ câu nói / câu gõ. */
data class Entry(
    val amount: Long?,
    val isExpense: Boolean,
    val time: Long,
    val category: String,
    val walletId: Long?,
    val note: String,
    val confidence: Float,
    val newCategory: Boolean,
    val newEmoji: String,
    val warnings: List<String> = emptyList()
)

fun Parsed.toEntry(): Entry {
    val w = mutableListOf<String>()
    if (amount == null) w += "chưa nhận được số tiền" else if (!amountClear) w += "số tiền chưa rõ đơn vị"
    if (!categoryMatched) w += "chưa xác định được nhóm"
    return Entry(amount, isExpense, time, category, null, note, if (w.isEmpty()) 0.9f else 0.5f, false, "", w)
}

object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    private fun call(method: String, url: String, key: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("x-goog-api-key", key)
        if (body != null) {
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(200) }
            throw Exception("HTTP $code: $msg")
        }
        return txt
    }

    suspend fun generate(key: String, model: String, prompt: String): String = withContext(Dispatchers.IO) {
        val name = model.trim().removePrefix("models/")
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1))
        val res = JSONObject(call("POST", "$BASE/models/$name:generateContent", key, body.toString()))
        val parts = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        sb.toString()
    }

    suspend fun listModels(key: String): List<String> = withContext(Dispatchers.IO) {
        val res = JSONObject(call("GET", "$BASE/models?pageSize=200", key, null))
        val arr = res.optJSONArray("models") ?: JSONArray()
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val methods = m.optJSONArray("supportedGenerationMethods")
            var ok = false
            if (methods != null) for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
            val name = m.optString("name").removePrefix("models/")
            if (ok && name.startsWith("gemini")) out.add(name)
        }
        out.sorted()
    }
}

fun cleanJson(t: String): String {
    val s = t.trim()
    val a = s.indexOfFirst { it == '{' || it == '[' }
    val b = s.indexOfLast { it == '}' || it == ']' }
    return if (a >= 0 && b > a) s.substring(a, b + 1) else s
}

private fun nz(s: String): String = if (s == "null") "" else s.trim()

/** Phân tích ngôn ngữ tự nhiên (gõ tay hoặc giọng nói) thành các giao dịch bằng Gemini. */
suspend fun aiParse(s: AppState, text: String): List<Entry> {
    val now = Calendar.getInstance()
    val days = arrayOf("Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy")
    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    val prompt = """
Bạn là bộ phân tích chi tiêu cá nhân tiếng Việt. Hiện tại: ${fmt.format(now.time)} (${days[now.get(Calendar.DAY_OF_WEEK) - 1]}).
Tách MỌI giao dịch có trong câu của người dùng. Chỉ trả về JSON đúng dạng:
{"transactions":[{"amount":<số nguyên VND>,"type":"expense"|"income","category":"<tên nhóm>","wallet":"<tên ví hoặc null>","datetime":"yyyy-MM-dd HH:mm hoặc null","note":"<ghi chú ngắn>","confidence":<0..1>,"new_category_emoji":"<emoji nếu tạo nhóm mới, ngược lại null>"}]}
Quy tắc: 50k=50000; 2tr=2000000; 1 triệu rưỡi=1500000. Ưu tiên chọn đúng một nhóm có sẵn trong danh sách; chỉ khi không nhóm nào phù hợp mới đặt tên nhóm mới ngắn gọn (kèm new_category_emoji). Tính "hôm qua", "sáng nay", "thứ hai tuần trước"... từ thời điểm hiện tại; không nói thời gian thì datetime=null. Chọn ví theo tên nếu người dùng nhắc, không thì null. confidence thấp nếu số tiền hoặc nhóm không chắc chắn.
Nhóm chi tiêu: ${expenseCats().joinToString(", ") { it.name }}
Nhóm thu nhập: ${incomeCats().joinToString(", ") { it.name }}
Ví: ${s.wallets.joinToString(", ") { it.name }}
Câu của người dùng: "$text"
""".trimIndent()

    val root = cleanJson(Gemini.generate(s.apiKey, s.model, prompt))
    val arr = if (root.startsWith("[")) JSONArray(root) else JSONObject(root).optJSONArray("transactions") ?: JSONArray()
    val res = mutableListOf<Entry>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val amount = o.optLong("amount", 0L).takeIf { it > 0 }
        val isExp = o.optString("type", "expense") != "income"
        val catRaw = nz(o.optString("category", ""))
        val existing = CatStore.list.firstOrNull { it.isIncome == !isExp && it.name.equals(catRaw, true) }
        val time = nz(o.optString("datetime", "")).takeIf { it.isNotBlank() }
            ?.let { try { fmt.parse(it)?.time } catch (e: Exception) { null } } ?: System.currentTimeMillis()
        val wName = nz(o.optString("wallet", ""))
        val wid = s.wallets.firstOrNull { wName.isNotBlank() && it.name.equals(wName, true) }?.id
        val conf = o.optDouble("confidence", 0.7).toFloat().coerceIn(0f, 1f)
        val emoji = nz(o.optString("new_category_emoji", "")).ifBlank { "🏷️" }
        val fallback = if (isExp) "Khác" else "Thu nhập khác"
        val isNew = existing == null && catRaw.isNotBlank()
        res.add(Entry(amount, isExp, time, existing?.name ?: if (isNew) catRaw else fallback,
            wid, nz(o.optString("note", "")), conf, isNew, emoji))
    }
    return res
}

// ---------------- AI phân tích hành vi tiêu dùng & tự tạo nhóm ----------------
data class Suggestion(val name: String, val emoji: String, val isIncome: Boolean, val ids: List<Long>)
data class AnalysisResult(val insight: String, val suggestions: List<Suggestion>)

suspend fun runBehaviorAnalysis(s: AppState): AnalysisResult {
    val list = s.txns.sortedByDescending { it.time }.take(150)
    if (list.size < 5) throw Exception("Cần ít nhất 5 giao dịch để AI phân tích")
    val lines = list.joinToString("\n") {
        "${it.id}|${if (it.isExpense) "chi" else "thu"}|${it.category}|${it.note.replace("|", " ")}|${it.amount}"
    }
    val totals = list.filter { it.isExpense }.groupBy { it.category }
        .map { it.key to it.value.sumOf { t -> t.amount } }.sortedByDescending { it.second }
        .joinToString(", ") { "${it.first}=${it.second}" }
    val prompt = """
Bạn là chuyên gia phân tích hành vi tiêu dùng cá nhân (tiền VND). Dưới đây là các giao dịch gần đây, mỗi dòng: id|loại|nhóm|ghi chú|số tiền.
$lines

Tổng chi theo nhóm: $totals
Nhóm hiện có - chi tiêu: ${expenseCats().joinToString(", ") { it.name }}; thu nhập: ${incomeCats().joinToString(", ") { it.name }}.

Nhiệm vụ:
1) Viết nhận xét ngắn (3-5 câu, tiếng Việt) về thói quen chi tiêu, điểm đáng chú ý và 1-2 gợi ý cụ thể.
2) Nếu có từ 3 giao dịch trở lên cùng một mẫu hành vi mà chưa có nhóm phù hợp (hay đang nằm ở nhóm "Khác" hoặc xếp chưa đúng), đề xuất NHÓM MỚI (tối đa 5). Mỗi nhóm có tên ngắn, 1 emoji, loại và danh sách id giao dịch thuộc nhóm đó. Không trùng tên nhóm đã có.
Chỉ trả về JSON: {"insights":"...","new_categories":[{"name":"","emoji":"","type":"expense"|"income","txn_ids":[id,...]}]}
""".trimIndent()

    val o = JSONObject(cleanJson(Gemini.generate(s.apiKey, s.model, prompt)))
    val valid = list.map { it.id }.toSet()
    val sugg = mutableListOf<Suggestion>()
    o.optJSONArray("new_categories")?.let { a ->
        for (i in 0 until a.length()) {
            val x = a.getJSONObject(i)
            val name = nz(x.optString("name", ""))
            val ids = mutableListOf<Long>()
            x.optJSONArray("txn_ids")?.let { t -> for (j in 0 until t.length()) { val id = t.optLong(j); if (id in valid) ids.add(id) } }
            if (name.isNotBlank() && ids.isNotEmpty()) {
                sugg.add(Suggestion(name, nz(x.optString("emoji", "")).ifBlank { "🏷️" }, x.optString("type", "expense") == "income", ids))
            }
        }
    }
    return AnalysisResult(o.optString("insights", ""), sugg)
}

/** Tạo nhóm mới theo đề xuất của AI và chuyển các giao dịch tương ứng sang nhóm đó. */
fun applySuggestions(s: AppState, r: AnalysisResult): String {
    var created = 0
    var moved = 0
    val names = mutableListOf<String>()
    r.suggestions.forEach { sg ->
        val exists = CatStore.list.any { it.name.equals(sg.name, true) }
        if (!exists) {
            s.addCat(Cat(sg.name, sg.emoji, PALETTE[CatStore.list.size % PALETTE.size], sg.isIncome, listOf(sg.name.lowercase())))
            created++; names.add("${sg.emoji} ${sg.name}")
        }
        val target = CatStore.list.firstOrNull { it.name.equals(sg.name, true) } ?: return@forEach
        if (target.isIncome == sg.isIncome) {
            val ids = s.txns.filter { it.id in sg.ids && it.isExpense == !sg.isIncome }.map { it.id }.toSet()
            if (ids.isNotEmpty()) { s.moveTxns(ids, target.name); moved += ids.size }
        }
    }
    return if (created == 0 && moved == 0) "Không có thay đổi nào."
    else "Đã tạo $created nhóm mới (${names.joinToString(", ")}) và chuyển $moved giao dịch."
}
