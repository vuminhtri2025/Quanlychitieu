package com.vichitieu.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF08090B)       // Dark Black
val Orange = Color(0xFFFF762E)   // Vibrant Orange
val Red = Color(0xFFE94343)      // Signal Red
val Green = Color(0xFF16A765)    // Fresh Green
val CardBg = Color(0xFF14161A)
val Card2 = Color(0xFF1D2026)
val Muted = Color(0xFF9AA0AA)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange, onPrimary = Color.White,
            background = Bg, onBackground = Color.White,
            surface = CardBg, onSurface = Color.White,
            error = Red
        ),
        content = content
    )
}
