package com.vichitieu.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.Calendar

// ======================= TAB 1: TỔNG QUAN =======================
@Composable
fun OverviewScreen(s: AppState) {
    val now = Calendar.getInstance()
    val y = now.get(Calendar.YEAR)
    val m = now.get(Calendar.MONTH)
    val vis = s.visible()
    val month = vis.filter { sameMonth(it.time, y, m) }
    val inc = month.filter { !it.isExpense }.sumOf { it.amount }
    val exp = month.filter { it.isExpense }.sumOf { it.amount }
    val total = s.shownBalance()
    val recent = vis.sortedByDescending { it.time }.take(5)
    var editing by remember { mutableStateOf<Txn?>(null) }

    editing?.let { e ->
        TxnDialog(e, "Sửa giao dịch", wallets = s.wallets,
            onSave = { s.upsert(it); editing = null },
            onDelete = { s.delete(e.id); editing = null },
            onDismiss = { editing = null })
    }

    val days = (6 downTo 0).map { k ->
        val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -k)
        val label = arrayOf("CN", "T2", "T3", "T4", "T5", "T6", "T7")[c.get(Calendar.DAY_OF_WEEK) - 1]
        label to vis.filter { it.isExpense && sameDay(it.time, c.timeInMillis) }.sumOf { it.amount }
    }
    val maxDay = (days.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
    val balanceTitle = if (s.activeWallet == -1L) "Tổng số dư (tất cả ví)"
    else "Số dư • ${s.wallets.firstOrNull { it.id == s.activeWallet }?.name ?: ""}"

    LazyColumn(
        contentPadding = PaddingValues(20.dp, 4.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("Tổng quan", "Your money. Always within reach.") }
        if (s.wallets.size > 1) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Pill("Tất cả ví", s.activeWallet == -1L) { s.activeWallet = -1L } }
                items(s.wallets) { w ->
                    Pill("${w.emoji} ${w.name} • ${moneyShort(s.walletBalance(w.id))}", s.activeWallet == w.id) { s.activeWallet = w.id }
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Orange, Color(0xFFFF9A5C)))).padding(22.dp)
            ) {
                Text(balanceTitle, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                Text(money(total), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                Text("Tháng ${m + 1}/$y: ${if (inc - exp >= 0) "+" else ""}${money(inc - exp)}",
                    color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Green).padding(18.dp)) {
                    Text("Thu nhập", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Text(money(inc), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Red).padding(18.dp)) {
                    Text("Chi tiêu", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Text(money(exp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Panel {
                Title("Chi tiêu 7 ngày qua")
                Spacer(Modifier.height(12.dp))
                Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                    val n = days.size
                    val slot = size.width / n
                    val bw = slot * 0.5f
                    days.forEachIndexed { i, d ->
                        val h = (d.second.toFloat() / maxDay) * (size.height - 4.dp.toPx())
                        val hh = if (d.second > 0) h.coerceAtLeast(6.dp.toPx()) else 4.dp.toPx()
                        drawRoundRect(
                            color = if (i == n - 1) Orange else Card2,
                            topLeft = Offset(i * slot + (slot - bw) / 2, size.height - hh),
                            size = Size(bw, hh),
                            cornerRadius = CornerRadius(8.dp.toPx())
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    days.forEach { Text(it.first, Modifier.weight(1f), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center) }
                }
            }
        }
        item { Title("Giao dịch gần đây") }
        if (recent.isEmpty()) {
            item { Text("Chưa có giao dịch. Sang tab Giọng nói để thêm khoản đầu tiên 🎙️", color = Muted, fontSize = 14.sp) }
        }
        items(recent) { t -> TxnRow(t) { editing = t } }
    }
}

// ======================= TAB 2: NHẬP BẰNG GIỌNG NÓI / GÕ TAY =======================
@Composable
fun VoiceScreen(s: AppState, scope: CoroutineScope) {
    val ctx = LocalContext.current
    val drafts = remember { mutableStateListOf<Pair<Txn, String>>() }
    var banner by remember { mutableStateOf<String?>(null) }
    var aiNote by remember { mutableStateOf<String?>(null) }
    var heard by remember { mutableStateOf("") }
    var heardConf by remember { mutableStateOf<Float?>(null) }
    var manual by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }

    /** Xử lý câu nói / câu gõ: AI (nếu có API key) hoặc bộ phân tích cơ bản; tự lưu hoặc chờ xác nhận. */
    fun process(text: String, speechConf: Float?) {
        heard = text
        heardConf = speechConf
        scope.launch {
            busy = true
            aiNote = null
            var entries: List<Entry> = emptyList()
            if (s.apiKey.isNotBlank()) {
                try { entries = aiParse(s, text) }
                catch (e: Exception) { aiNote = "AI lỗi: ${e.message?.take(140)} → dùng bộ phân tích cơ bản" }
            } else {
                aiNote = "Chưa cài API Google AI Studio (⚙ Cài đặt) → đang dùng bộ phân tích cơ bản"
            }
            if (entries.isEmpty()) entries = listOf(VoiceParser.parse(text).toEntry())

            var saved = 0
            var queued = 0
            val base = System.currentTimeMillis() * 10
            entries.forEachIndexed { i, e ->
                val reasons = e.warnings.toMutableList()
                if ((e.amount ?: 0L) <= 0L && reasons.none { it.contains("số tiền") }) reasons += "chưa nhận được số tiền"
                val conf = minOf(e.confidence, speechConf ?: 1f)
                if (conf < s.threshold) reasons += "độ tự tin thấp (${(conf * 100).toInt()}%)"
                if (e.newCategory && !s.autoCats) reasons += "AI đề xuất nhóm mới “${e.category}”"
                val t = Txn(base + i, e.amount ?: 0L, e.isExpense, e.time, e.category, e.note, e.walletId ?: s.defaultWalletId())
                if (reasons.isEmpty()) {
                    if (e.newCategory) s.addCat(Cat(e.category, e.newEmoji, PALETTE[CatStore.list.size % PALETTE.size],
                        !e.isExpense, listOf(e.category.lowercase())))
                    s.upsert(t); saved++
                } else {
                    drafts.add(t to "Cần xác nhận: " + reasons.joinToString(", ")); queued++
                }
            }
            banner = when {
                saved > 0 && queued > 0 -> "✓ Đã tự lưu $saved • $queued giao dịch cần xác nhận"
                saved > 0 -> "✓ Đã tự lưu $saved giao dịch"
                else -> null
            }
            busy = false
        }
    }

    val voice = remember { VoiceController(ctx) { text, conf -> process(text, conf) } }
    DisposableEffect(Unit) { onDispose { voice.stop() } }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) voice.start() else voice.error = "Cần cấp quyền micro để nhập bằng giọng nói"
    }
    fun toggle() {
        banner = null
        if (voice.listening) voice.stop()
        else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            voice.start()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    drafts.firstOrNull()?.let { d ->
        key(d.first.id) {
            TxnDialog(d.first, "Xác nhận giao dịch (${drafts.size})", wallets = s.wallets, hint = d.second,
                onSave = { s.upsert(it); drafts.removeAt(0); banner = "✓ Đã lưu giao dịch" },
                onDismiss = { drafts.removeAt(0) })
        }
    }
    if (manual) {
        TxnDialog(newTxn(s.defaultWalletId()), "Thêm giao dịch", wallets = s.wallets,
            onSave = { s.upsert(it); manual = false; banner = "✓ Đã lưu giao dịch" },
            onDismiss = { manual = false })
    }

    val pulse by animateFloatAsState(if (voice.listening) 1f + voice.level * 0.6f else 1f, label = "pulse")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Nhập liệu", "Nói hoặc gõ tự nhiên, AI sẽ tự tách thông tin")

        Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(140.dp).scale(pulse).clip(CircleShape).background(Orange.copy(alpha = 0.18f)))
            Box(
                Modifier.size(112.dp).clip(CircleShape)
                    .background(if (voice.listening) Red else Orange)
                    .clickable { toggle() },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (voice.listening) Icons.Rounded.Stop else Icons.Rounded.Mic, "Mic",
                    tint = Color.White, modifier = Modifier.size(50.dp))
            }
        }
        Text(
            if (voice.listening) "Đang nghe… chạm để dừng" else "Chạm vào micro để nói",
            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        voice.error?.let {
            Text(it, color = Red, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }

        // ---- nhập tay bằng ngôn ngữ tự nhiên ----
        Panel {
            Title("✍️ Gõ tự nhiên")
            Text("VD: “hôm qua ăn phở 50k, tối đổ xăng 80k” – có thể gõ nhiều khoản cùng lúc.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
            OutlinedTextField(typed, { typed = it }, minLines = 2, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Viết giao dịch của bạn…") })
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(if (busy) "Đang phân tích…" else "✨ Phân tích & lưu", true) {
                    if (!busy && typed.isNotBlank()) { banner = null; process(typed.trim(), null); typed = "" }
                }
                Pill("Biểu mẫu", false) { manual = true }
            }
        }

        banner?.let {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Green).padding(16.dp)) {
                Text(it, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
        aiNote?.let { Text(it, color = Orange, fontSize = 12.sp) }

        val shown = if (voice.listening) voice.partial else heard
        if (shown.isNotBlank()) {
            Panel {
                Text("Nội dung vừa nhận", color = Muted, fontSize = 12.sp)
                Text("“$shown”", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                if (!voice.listening) {
                    Text(
                        heardConf?.let { "Độ tự tin giọng nói: ${(it * 100).toInt()}%" } ?: "Nhập bằng văn bản / không có độ tự tin giọng nói",
                        color = Orange, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
        Text(
            (if (s.apiKey.isNotBlank()) "🤖 AI: ${s.model}" else "🤖 AI: chưa cài đặt") +
                " • tự lưu khi độ tự tin ≥ ${(s.threshold * 100).toInt()}%",
            color = Muted, fontSize = 12.sp
        )
    }
}
