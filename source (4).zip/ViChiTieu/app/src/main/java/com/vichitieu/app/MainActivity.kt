package com.vichitieu.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val state = AppState(this)
        setContent { AppTheme { Root(state) } }
    }
}

@Composable
fun Root(s: AppState) {
    val tabs = listOf(
        TabItem("Tổng quan", Icons.Rounded.Home),
        TabItem("Nhập liệu", Icons.Rounded.Mic),
        TabItem("Lịch sử", Icons.Rounded.ReceiptLong),
        TabItem("Phân tích", Icons.Rounded.PieChart),
        TabItem("Ngân sách", Icons.Rounded.Savings)
    )
    var selected by rememberSaveable { mutableIntStateOf(0) }
    var hover by remember { mutableIntStateOf(-1) }
    var showSettings by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun go(i: Int) { selected = i.coerceIn(0, tabs.size - 1) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier.weight(1f).fillMaxWidth().statusBarsPadding()
                    // vuốt ngang trong nội dung để đổi tab
                    .pointerInput(selected) {
                        var acc = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { acc = 0f },
                            onDragEnd = {
                                if (acc < -120f) go(selected + 1)
                                else if (acc > 120f) go(selected - 1)
                            },
                            onHorizontalDrag = { _, d -> acc += d }
                        )
                    }
            ) {
                if (showSettings) {
                    SettingsScreen(s) { showSettings = false }
                } else {
                    Crossfade(targetState = selected, label = "screen") { page ->
                        when (page) {
                            0 -> OverviewScreen(s)
                            1 -> VoiceScreen(s, scope)
                            2 -> HistoryScreen(s)
                            3 -> AnalysisScreen(s)
                            else -> BudgetScreen(s)
                        }
                    }
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(12.dp)
                            .clip(RoundedCornerShape(50)).background(Card2)
                            .clickable { showSettings = true }.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) { Text("⚙", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                }
            }
            HoldNavBar(tabs, selected, hover, { hover = it }, { selected = it })
        }
        if (hover >= 0) {
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 84.dp)
                    .clip(RoundedCornerShape(50)).background(Orange).padding(horizontal = 22.dp, vertical = 10.dp)
            ) {
                Text("${tabs[hover].label}  •  thả tay để chuyển", color = Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}
