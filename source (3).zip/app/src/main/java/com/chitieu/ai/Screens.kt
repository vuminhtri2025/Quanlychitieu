@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.text.input.VisualTransformation
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val RED = Color(0xFFD32F2F)
private val GREEN = Color(0xFF2E7D32)

@Composable
fun Pick(value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("$value ▾") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false }) }
        }
    }
}

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    val recorder = remember { Recorder() }
    val needKey = "Bạn chưa nhập API key. Vào tab Cài đặt, dán key lấy từ Google AI Studio nhé."
    val micHelp = "Hãy nói với Gemini rồi bấm Chia sẻ → Chi Tiêu AI, hoặc copy rồi bấm 📋."

    fun say(t: String) { Store.chat.add(Msg(false, t)) }
    fun run(m: Msg, audio: ByteArray?) {
        busy = true
        scope.launch {
            try {
                val r = Gemini.ask(audio)
                if (audio != null) m.text = "🎤 " + r.heard.ifBlank { "(không nghe rõ)" }
                Store.chat.add(Msg(false, r.reply, r.items).also { it.typing = Store.typeEffect })
            } catch (e: Exception) {
                say("⚠️ ${e.message}")
            }
            busy = false
        }
    }
    fun send(t: String) {
        if (t.isBlank() || busy) return
        if (Store.apiKey.isBlank()) { say(needKey); return }
        val m = Msg(true, t); Store.chat.add(m); input = ""; run(m, null)
    }
    fun stopRec() {
        if (!recording) return
        recording = false
        val pcm = recorder.stop()
        if (!hasSound(pcm)) { say("Không thu được âm thanh (mic có thể đang bị app công ty chặn). $micHelp"); return }
        if (Store.apiKey.isBlank()) { say(needKey); return }
        val m = Msg(true, "🎤 đang nghe…"); Store.chat.add(m); run(m, wav(pcm))
    }
    fun startRec() {
        try { recorder.start(); recording = true } catch (e: Exception) { say("⚠️ Không mở được mic: ${e.message}. $micHelp") }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else say("Bạn chưa cấp quyền micro cho app.")
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }
    LaunchedEffect(Store.chat.size, busy) { list.animateScrollToItem(Store.chat.size) }
    val last = Store.chat.lastOrNull()
    LaunchedEffect(last, last?.typing) { while (last?.typing == true) { list.scrollToItem(Store.chat.size); delay(200) } }
    LaunchedEffect(Store.incoming) { Store.incoming?.let { Store.incoming = null; send(it) } }
    LaunchedEffect(recording) { if (recording) { delay(Store.maxRecSec * 1000L); stopRec() } }

    Column(Modifier.fillMaxSize()) {
        Text("🤖 ${Store.aiName}", Modifier.padding(start = 12.dp, top = 8.dp), fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp), state = list, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Store.chat) { m ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start) {
                    Surface(shape = RoundedCornerShape(14.dp),
                        color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                        BubbleText(m)
                    }
                    if (!m.typing) m.pending.forEach { PendingCard(it) }
                }
            }
            item { if (busy) Text("${Store.aiName} đang nghĩ…", style = MaterialTheme.typography.bodySmall) }
        }
        if (recording) Text("🔴 Đang ghi âm… nói xong bấm ⏹ để gửi cho Gemini", Modifier.padding(horizontal = 12.dp), color = RED)
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Nhập khoản chi tiêu…") }, maxLines = 3)
            IconButton(onClick = {
                if (Store.voiceMode == "system") {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
                    try { voice.launch(i) } catch (e: ActivityNotFoundException) {
                        Toast.makeText(ctx, "Máy chưa có dịch vụ nhận diện giọng nói", Toast.LENGTH_SHORT).show()
                    }
                } else if (recording) stopRec()
                else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
                else perm.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text(if (recording) "⏹" else "🎤") }
            IconButton(onClick = {
                val t = ctx.getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()
                if (t.isNullOrBlank()) Toast.makeText(ctx, "Clipboard đang trống", Toast.LENGTH_SHORT).show() else send(t)
            }) { Text("📋") }
            Button(onClick = { send(input) }, enabled = !busy) { Text("Gửi") }
        }
    }
}

@Composable
fun MonthBar(off: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = { onChange(off - 1) }) { Text("◀") }
        Text(SimpleDateFormat("'Tháng' MM/yyyy", Locale.US).format(monthStart(off).time), fontWeight = FontWeight.Bold)
        TextButton(onClick = { onChange(off + 1) }, enabled = off < 0) { Text("▶") }
    }
}

@Composable
fun BudgetScreen() {
    var edit by remember { mutableStateOf<String?>(null) }
    var txt by remember { mutableStateOf("") }
    val spent = txsOfMonth(0).filter { !it.income && Store.cur(it.walletId) == "VND" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Ngân sách tháng này (chạm để đặt hạn mức)", fontWeight = FontWeight.Bold)
        CATEGORIES.filter { it !in INCOME_CATS }.forEach { c ->
            val lim = Store.budgets[c] ?: 0L
            val s = spent[c] ?: 0L
            Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                .padding(10.dp).then(Modifier), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { edit = c; txt = if (lim > 0) lim.toString() else "" }) {
                    Text("$c: ${s.vnd()} / ${if (lim > 0) lim.vnd() else "chưa đặt"}")
                }
                if (lim > 0) {
                    LinearProgressIndicator(progress = { (s.toFloat() / lim).coerceAtMost(1f) }, Modifier.fillMaxWidth(),
                        color = if (s > lim) RED else MaterialTheme.colorScheme.primary)
                    if (s > lim) Text("⚠️ Vượt ngân sách ${(s - lim).vnd()}", color = RED)
                }
            }
        }
    }
    edit?.let { c ->
        AlertDialog(onDismissRequest = { edit = null }, title = { Text("Hạn mức: $c") },
            text = { OutlinedTextField(txt, { txt = it.filter(Char::isDigit) }, label = { Text("Số tiền (đ)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
            confirmButton = { TextButton(onClick = {
                val v = txt.toLongOrNull() ?: 0L
                if (v > 0) Store.budgets[c] = v else Store.budgets.remove(c)
                Store.save(); edit = null
            }) { Text("Lưu") } },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("Hủy") } })
    }
}

@Composable
fun DateTimeRow(time: Long, onChange: (Long) -> Unit) {
    val ctx = LocalContext.current
    val cal = Calendar.getInstance().apply { timeInMillis = time }
    Row {
        TextButton(onClick = {
            DatePickerDialog(ctx, { _, y, m, d ->
                onChange(Calendar.getInstance().apply { timeInMillis = time; set(y, m, d) }.timeInMillis)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }) { Text("📅 " + SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(time))) }
        TextButton(onClick = {
            TimePickerDialog(ctx, { _, h, mi ->
                onChange(Calendar.getInstance().apply { timeInMillis = time; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, mi) }.timeInMillis)
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }) { Text("🕒 " + SimpleDateFormat("HH:mm", Locale.US).format(Date(time))) }
    }
}

@Composable
fun PendingCard(p: Pending) {
    if (p.dismissed) return
    Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text((if (p.income) "+" else "-") + p.amount.money(Store.cur(p.walletId)), fontWeight = FontWeight.Bold,
                color = if (p.income) GREEN else RED)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pick(Store.walletName(p.walletId), Store.wallets.map { it.name }) { n ->
                    Store.wallets.firstOrNull { it.name == n }?.let { p.walletId = it.id }
                }
                Pick(p.category, CATEGORIES) { p.category = it; p.income = it in INCOME_CATS }
            }
            DateTimeRow(p.time) { p.time = it }
            if (p.note.isNotBlank()) Text("📝 ${p.note}", style = MaterialTheme.typography.bodySmall)
            if (p.saved) Text("✅ Đã lưu", color = GREEN) else Row {
                Button(onClick = {
                    Store.add(Tx(System.nanoTime(), p.amount, p.income, p.walletId, p.category, p.note, p.time))
                    p.saved = true
                }) { Text("Lưu") }
                TextButton(onClick = { p.dismissed = true }) { Text("Bỏ") }
            }
        }
    }
}

@Composable
fun EditTxDialog(t: Tx, onClose: () -> Unit) {
    var amount by remember { mutableStateOf(t.amount.toString()) }
    var income by remember { mutableStateOf(t.income) }
    var wid by remember { mutableLongStateOf(t.walletId) }
    var cat by remember { mutableStateOf(t.category) }
    var note by remember { mutableStateOf(t.note) }
    var time by remember { mutableLongStateOf(t.time) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Sửa giao dịch") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false }, label = { Text("Chi") })
                    FilterChip(selected = income, onClick = { income = true }, label = { Text("Thu") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pick(Store.walletName(wid), Store.wallets.map { it.name }) { n -> Store.wallets.firstOrNull { it.name == n }?.let { wid = it.id } }
                    Pick(cat, CATEGORIES) { cat = it }
                }
                DateTimeRow(time) { time = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = amount.toLongOrNull() ?: 0L
            if (a > 0) { Store.updateTx(t.copy(amount = a, income = income, walletId = wid, category = cat, note = note, time = time)); onClose() }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun HistoryScreen() {
    var off by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    val list = txsOfMonth(off).sortedByDescending { it.time }
    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        MonthBar(off) { off = it }
        Text("Chi ${sumByCur(list.filter { !it.income }).show()}  •  Thu ${sumByCur(list.filter { it.income }).show()}")
        Text("Chạm vào giao dịch để sửa", style = MaterialTheme.typography.bodySmall)
        if (list.isEmpty()) Text("Chưa có giao dịch.", Modifier.padding(top = 16.dp))
        LazyColumn {
            items(list, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth().clickable { editing = t }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${t.category} • ${Store.walletName(t.walletId)}", fontWeight = FontWeight.Medium)
                        Text(df.format(Date(t.time)) + if (t.note.isNotBlank()) " — ${t.note}" else "", style = MaterialTheme.typography.bodySmall)
                    }
                    Text((if (t.income) "+" else "-") + t.fmt(), color = if (t.income) GREEN else RED)
                    TextButton(onClick = { Store.txs.remove(t); Store.save() }) { Text("🗑") }
                }
                HorizontalDivider()
            }
        }
    }
    editing?.let { EditTxDialog(it) { editing = null } }
}

@Composable
fun StatsScreen() {
    var off by remember { mutableIntStateOf(0) }
    val m = txsOfMonth(off)
    val thu = sumByCur(m.filter { it.income })
    val chiAll = sumByCur(m.filter { !it.income })
    val net = (thu.keys + chiAll.keys).associateWith { (thu[it] ?: 0L) - (chiAll[it] ?: 0L) }
    val chi = m.filter { !it.income && Store.cur(it.walletId) == "VND" }
    val total = chi.sumOf { it.amount }
    val byCat = chi.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        MonthBar(off) { off = it }
        Text("Thu: ${thu.show()}", color = GREEN); Text("Chi: ${chiAll.show()}", color = RED)
        Text("Còn lại: ${net.show()}", fontWeight = FontWeight.Bold)
        Text("Chi theo mục (ví VND)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        byCat.forEach { (k, v) ->
            Text("$k — ${v.vnd()} (${if (total > 0) v * 100 / total else 0}%)")
            LinearProgressIndicator(progress = { if (total > 0) v.toFloat() / total else 0f }, Modifier.fillMaxWidth())
        }
        Text("Số dư các ví", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Store.wallets.forEach { Text("${it.name}: ${Store.balance(it).money(it.currency)}") }
    }
}

@Composable
fun WalletDialog(w: Wallet?, onClose: () -> Unit) {
    var name by remember { mutableStateOf(w?.name ?: "") }
    var cur by remember { mutableStateOf(w?.currency ?: "VND") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (w == null) "Thêm ví" else "Sửa ví") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Tên ví") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Đơn vị tiền: "); Pick(cur, CURRENCIES.keys.toList()) { cur = it } }
                if (err.isNotEmpty()) Text(err, color = RED)
            }
        },
        confirmButton = { TextButton(onClick = {
            val n = name.trim()
            if (n.isEmpty()) err = "Tên ví không được để trống"
            else if (Store.wallets.any { it.name.equals(n, true) && it.id != w?.id }) err = "Tên ví đã tồn tại"
            else {
                if (w == null) Store.wallets.add(Wallet(System.currentTimeMillis(), n, cur))
                else { val i = Store.wallets.indexOfFirst { it.id == w.id }; if (i >= 0) Store.wallets[i] = w.copy(name = n, currency = cur) }
                Store.save(); onClose()
            }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun DeleteWalletDialog(w: Wallet, onClose: () -> Unit) {
    val n = Store.txs.count { it.walletId == w.id }
    val others = Store.wallets.filter { it.id != w.id }
    var target by remember { mutableLongStateOf(others.first().id) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Xóa ví \"${w.name}\"") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (n == 0) Text("Ví chưa có giao dịch nào.") else {
                    Text("Ví có $n giao dịch. Chuyển chúng sang ví:")
                    Pick(Store.walletName(target), others.map { it.name }) { nm -> others.firstOrNull { it.name == nm }?.let { target = it.id } }
                }
            }
        },
        confirmButton = { TextButton(onClick = { Store.deleteWallet(w.id, if (n == 0) null else target); onClose() }) {
            Text(if (n == 0) "Xóa ví" else "Chuyển & xóa ví") } },
        dismissButton = { Column {
            if (n > 0) TextButton(onClick = { Store.deleteWallet(w.id, null); onClose() }) { Text("Xóa cả giao dịch", color = RED) }
            TextButton(onClick = onClose) { Text("Hủy") }
        } })
}

@Composable
fun SettingsScreen() {
    var page by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = page != null) { page = null }
    val p = page
    if (p == null) SettingsMenu { page = it } else SettingsPage(p) { page = null }
}

@Composable
fun SettingsMenu(open: (String) -> Unit) {
    val rows = listOf(
        Triple("ai", "🤖 Trợ lý AI", "${Store.aiName} • ${Store.persona} • trả lời ${Store.replyLen.lowercase()}"),
        Triple("key", "🔑 Kết nối Gemini", Store.model + " • " + if (Store.apiKey.isBlank()) "chưa nhập key" else "đã có key"),
        Triple("voice", "🎙️ Giọng nói", if (Store.voiceMode == "gemini") "Ghi âm → Gemini nghe" else "Nhận diện của máy"),
        Triple("fx", "✨ Hiệu ứng chat", if (Store.typeEffect) "Chữ hiện dần • ${Store.typeMs / 1000}s" else "Tắt"),
        Triple("wallet", "👛 Ví", "${Store.wallets.size} ví"),
        Triple("data", "📤 Dữ liệu", "${Store.txs.size} giao dịch")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Cài đặt", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        rows.forEach { (id, title, sub) ->
            Card(Modifier.fillMaxWidth().clickable { open(id) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(sub, style = MaterialTheme.typography.bodySmall) }
                    Text("›")
                }
            }
        }
    }
}

@Composable
fun SettingsPage(id: String, back: () -> Unit) {
    val title = when (id) {
        "ai" -> "🤖 Trợ lý AI"; "key" -> "🔑 Kết nối Gemini"; "voice" -> "🎙️ Giọng nói"
        "fx" -> "✨ Hiệu ứng chat"; "wallet" -> "👛 Ví"; else -> "📤 Dữ liệu"
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = back) { Text("← Cài đặt") }
            Text(title, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (id) {
                "ai" -> AiSettings()
                "key" -> KeySettings()
                "voice" -> VoiceSettings()
                "fx" -> FxSettings()
                "wallet" -> WalletSettings()
                else -> DataSettings()
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun Chips(options: List<String>, selected: String, onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o -> FilterChip(selected = o == selected, onClick = { onPick(o) }, label = { Text(o) }) }
    }
}

@Composable
fun Radio(label: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Column { Text(label, fontWeight = FontWeight.Medium); if (desc.isNotEmpty()) Text(desc, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun AiSettings() {
    Section("Nhân vật") {
        OutlinedTextField(Store.aiName, { Store.aiName = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("Tên AI") }, singleLine = true)
        OutlinedTextField(Store.userName, { Store.userName = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("AI gọi bạn là") }, singleLine = true)
    }
    Section("Tính cách") {
        PERSONAS.forEach { (k, v) -> Radio(k, v, Store.persona == k) { Store.persona = k; Store.save() } }
    }
    Section("Cách trả lời") {
        Text("Độ dài")
        Chips(listOf("Ngắn", "Vừa", "Chi tiết"), Store.replyLen) { Store.replyLen = it; Store.save() }
        Text("Độ sáng tạo: " + String.format(Locale.US, "%.1f", Store.temp))
        Slider(Store.temp, { Store.temp = it }, valueRange = 0f..1f, onValueChangeFinished = { Store.save() })
    }
}

@Composable
fun KeySettings() {
    var show by remember { mutableStateOf(false) }
    Section("API key Google AI Studio") {
        OutlinedTextField(Store.apiKey, { Store.apiKey = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation())
        TextButton(onClick = { show = !show }) { Text(if (show) "🙈 Ẩn key" else "👁 Hiện key") }
        Text("Key chỉ lưu trên máy này. Lấy key tại aistudio.google.com.", style = MaterialTheme.typography.bodySmall)
    }
    Section("Model") {
        OutlinedTextField(Store.model, { Store.model = it.trim(); Store.save() }, Modifier.fillMaxWidth(), label = { Text("Tên model") }, singleLine = true)
        Chips(listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro"), Store.model) { Store.model = it; Store.save() }
    }
}

@Composable
fun VoiceSettings() {
    Section("Cách nhập giọng nói") {
        Radio("Ghi âm rồi gửi Gemini nghe", "Khuyên dùng: Gemini nghe và hiểu thẳng", Store.voiceMode == "gemini") { Store.voiceMode = "gemini"; Store.save() }
        Radio("Nhận diện giọng nói của máy", "Dùng bộ nhận diện Google có sẵn trên máy", Store.voiceMode == "system") { Store.voiceMode = "system"; Store.save() }
    }
    Section("Ghi âm tối đa (giây)") {
        Chips(listOf("30", "60", "120"), Store.maxRecSec.toString()) { Store.maxRecSec = it.toInt(); Store.save() }
    }
    Section("Khi mic bị chặn") {
        Text("Nói với app Gemini rồi bấm Chia sẻ → Chi Tiêu AI, hoặc copy văn bản rồi bấm 📋 trong chat.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun FxSettings() {
    Section("Chữ hiện dần khi AI trả lời") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Bật hiệu ứng", Modifier.weight(1f))
            Switch(Store.typeEffect, { Store.typeEffect = it; Store.save() })
        }
        Text("Thời gian hiện hết một tin nhắn dài (giây)")
        Chips(listOf("2", "3", "5"), (Store.typeMs / 1000).toString()) { Store.typeMs = it.toInt() * 1000; Store.save() }
    }
}

@Composable
fun WalletSettings() {
    var editW by remember { mutableStateOf<Wallet?>(null) }
    var delW by remember { mutableStateOf<Wallet?>(null) }
    var adding by remember { mutableStateOf(false) }
    Section("Danh sách ví") {
        Store.wallets.toList().forEach { w ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(w.name, fontWeight = FontWeight.Medium)
                    Text("${w.currency} • ${Store.balance(w).money(w.currency)}", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { editW = w }) { Text("✏️") }
                if (Store.wallets.size > 1) TextButton(onClick = { delW = w }) { Text("🗑") }
            }
        }
        Button(onClick = { adding = true }) { Text("➕ Thêm ví") }
    }
    editW?.let { WalletDialog(it) { editW = null } }
    if (adding) WalletDialog(null) { adding = false }
    delW?.let { DeleteWalletDialog(it) { delW = null } }
}

@Composable
fun DataSettings() {
    val ctx = LocalContext.current
    Section("Xuất dữ liệu") {
        Text("${Store.txs.size} giao dịch", style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val csv = "Thời gian,Loại,Số tiền,Đơn vị,Ví,Mục,Ghi chú\n" + Store.txs.sortedBy { it.time }.joinToString("\n") {
                "${f.format(Date(it.time))},${if (it.income) "Thu" else "Chi"},${it.amount},${Store.cur(it.walletId)},${Store.walletName(it.walletId)},${it.category},\"${it.note.replace("\"", "\"\"")}\""
            }
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, csv), "Xuất CSV"))
        }) { Text("📤 Xuất CSV") }
    }
    Section("Cuộc trò chuyện") {
        OutlinedButton(onClick = { Store.resetChat() }) { Text("🧹 Xóa cuộc trò chuyện") }
    }
}

@Composable
fun BubbleText(m: Msg) {
    var shown by remember { mutableIntStateOf(if (m.typing) 0 else m.text.length) }
    LaunchedEffect(m) {
        if (m.typing) {
            val n = m.text.length
            val ms = (n * 50L).coerceIn(800L, Store.typeMs.toLong()).toInt()
            try {
                Animatable(0f).animateTo(1f, tween(ms, easing = LinearEasing)) { shown = (value * n).toInt() }
            } finally { m.typing = false }
        }
    }
    Text(if (m.typing) m.text.take(shown) else m.text, Modifier.padding(10.dp))
}
