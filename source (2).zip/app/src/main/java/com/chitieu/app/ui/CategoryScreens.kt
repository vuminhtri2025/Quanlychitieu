package com.chitieu.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.chitieu.app.data.Category
import com.chitieu.app.data.T

/** Hop thoai toan man hinh "Chon nhom". */
@Composable
fun CategoryPickerDialog(
    vm: AppViewModel,
    onPick: (Category) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            CategoryTree(vm = vm, title = "Chọn nhóm", onBack = onDismiss, onPick = onPick)
        }
    }
}

@Composable
fun CategoryTree(
    vm: AppViewModel,
    title: String,
    onBack: () -> Unit,
    onPick: (Category) -> Unit
) {
    val cats by vm.categories.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var showNew by remember { mutableStateOf(false) }
    val expanded = remember { mutableStateMapOf<Long, Boolean>() }

    val types = when (tab) {
        0 -> listOf(T.EXPENSE)
        1 -> listOf(T.INCOME)
        else -> listOf(T.LOAN_IN, T.LOAN_OUT)
    }
    val roots = cats.filter { it.parentId == null && it.type in types }

    Column(modifier = Modifier.fillMaxSize().background(Bg)) {
        TopBar(title = title, onBack = onBack)
        TabRow(selectedTabIndex = tab, containerColor = CardBg) {
            val labels = listOf("KHOẢN CHI", "KHOẢN THU", "ĐI VAY/CHO VAY")
            labels.forEachIndexed { i, s ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    selectedContentColor = androidx.compose.ui.graphics.Color.White,
                    unselectedContentColor = Muted,
                    text = {
                        Text(s, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                )
            }
        }
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item(key = "new") {
                Row(
                    modifier = Modifier.fillMaxWidth().background(CardBg)
                        .clickable { showNew = true }.padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Green),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Add, contentDescription = null) }
                    Spacer(Modifier.width(16.dp))
                    Text("NHÓM MỚI", color = Green, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            }
            for (root in roots) {
                val kids = cats.filter { it.parentId == root.id }
                val isOpen = expanded[root.id] == true
                val shown = if (isOpen) kids else kids.take(2)
                item(key = "root" + root.id) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        CategoryRow(root, indent = false) { onPick(root) }
                    }
                }
                items(shown, key = { "kid" + it.id }) { kid ->
                    CategoryRow(kid, indent = true) { onPick(kid) }
                }
                if (kids.size > 2) {
                    item(key = "more" + root.id) {
                        Row(modifier = Modifier.fillMaxWidth().background(CardBg).padding(start = 56.dp)) {
                            TextButton(onClick = { expanded[root.id] = !isOpen }) {
                                Text(
                                    if (isOpen) "ẨN BỚT" else "HIỆN THÊM…",
                                    color = Green, fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        NewCategoryDialog(
            tab = tab,
            roots = roots,
            onDismiss = { showNew = false },
            onSave = { c ->
                vm.saveCategory(c)
                showNew = false
            }
        )
    }
}

@Composable
private fun CategoryRow(c: Category, indent: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(CardBg).clickable(onClick = onClick)
            .padding(start = if (indent) 56.dp else 16.dp, end = 16.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CatIcon(if (indent) 36.dp else 46.dp, c.id)
        Spacer(Modifier.width(16.dp))
        Text(c.name, fontSize = 18.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewCategoryDialog(
    tab: Int,
    roots: List<Category>,
    onDismiss: () -> Unit,
    onSave: (Category) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var parent by remember { mutableStateOf<Category?>(null) }
    var loanIn by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text("Nhóm mới") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Tên nhóm") }, singleLine = true
                )
                if (tab == 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = loanIn, onClick = { loanIn = true },
                            label = { Text("Tiền vào") }
                        )
                        FilterChip(
                            selected = !loanIn, onClick = { loanIn = false },
                            label = { Text("Tiền ra") }
                        )
                    }
                }
                Box {
                    OutlinedButton(onClick = { menu = true }) {
                        Text(parent?.name ?: "Nhóm cha: (không có)")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("(không có)") },
                            onClick = { parent = null; menu = false }
                        )
                        for (r in roots) {
                            DropdownMenuItem(
                                text = { Text(r.name) },
                                onClick = { parent = r; menu = false }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank()) {
                    val type = when {
                        parent != null -> parent!!.type
                        tab == 0 -> T.EXPENSE
                        tab == 1 -> T.INCOME
                        loanIn -> T.LOAN_IN
                        else -> T.LOAN_OUT
                    }
                    onSave(Category(name = name.trim(), parentId = parent?.id, type = type))
                }
            }) { Text("Lưu", color = Green) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

/** Man hinh quan ly nhom (cham vao nhom de xoa). */
@Composable
fun CategoriesScreen(vm: AppViewModel, onBack: () -> Unit) {
    var toDelete by remember { mutableStateOf<Category?>(null) }
    CategoryTree(vm = vm, title = "Nhóm (chạm để xóa)", onBack = onBack, onPick = { toDelete = it })
    val c = toDelete
    if (c != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = CardBg,
            title = { Text("Xóa nhóm?") },
            text = { Text("Xóa \"${c.name}\" (kể cả nhóm con). Các giao dịch cũ sẽ hiển thị là \"Khác\".") },
            confirmButton = {
                TextButton(onClick = { vm.deleteCategory(c.id); toDelete = null }) {
                    Text("Xóa", color = Red)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Hủy") } }
        )
    }
}
