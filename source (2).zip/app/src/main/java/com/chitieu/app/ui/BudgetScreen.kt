package com.chitieu.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chitieu.app.data.Budget
import com.chitieu.app.data.Category
import com.chitieu.app.data.T

@Composable
fun BudgetScreen(vm: AppViewModel) {
    val budgets by vm.budgets.collectAsState()
    val cats by vm.categories.collectAsState()
    val txns by vm.txns.collectAsState()
    val ctx = LocalContext.current
    val byId = remember(cats) { cats.associateBy { it.id } }
    val month = monthRef(0)

    var pickCat by remember { mutableStateOf(false) }
    var newCat by remember { mutableStateOf<Category?>(null) }
    var editing by remember { mutableStateOf<Budget?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = "Ngân sách tháng " + month.label, onBack = null) {
            IconButton(onClick = { pickCat = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Tạo ngân sách")
            }
        }
        if (budgets.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Filled.Inventory2, contentDescription = null,
                    tint = Color(0xFF9DB4D8), modifier = Modifier.size(96.dp)
                )
                Spacer(Modifier.height(24.dp))
                Text("Chưa có ngân sách", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = { pickCat = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White)
                ) { Text("Tạo ngân sách", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(20.dp))
                Text(
                    "Đặt hạn mức chi cho từng nhóm mỗi tháng để theo dõi mức chi tiêu.",
                    color = Muted, fontSize = 17.sp, textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(budgets, key = { it.id }) { b ->
                    val cat = byId[b.categoryId]
                    val spent = txns.filter { t ->
                        t.type == T.EXPENSE && t.date >= month.start && t.date < month.end &&
                            (t.categoryId == b.categoryId || byId[t.categoryId]?.parentId == b.categoryId)
                    }.sumOf { it.amount }
                    val left = b.amount - spent
                    val over = left < 0
                    AppCard(modifier = Modifier.padding(0.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                CatIcon(40.dp, b.categoryId)
                                Spacer(Modifier.size(12.dp))
                                Text(cat?.name ?: "Khác", fontSize = 18.sp, maxLines = 2)
                            }
                            TextButton(onClick = { editing = b }) { Text("Sửa", color = Green) }
                        }
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { (spent.toFloat() / b.amount.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = if (over) Red else Green, trackColor = BarBg
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Đã chi " + money(spent), color = Muted, fontSize = 15.sp)
                            Text("Hạn mức " + money(b.amount), color = Muted, fontSize = 15.sp)
                        }
                        Text(
                            if (over) "Vượt " + money(-left) else "Còn lại " + money(left),
                            color = if (over) Red else Green, fontSize = 17.sp, fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    if (pickCat) {
        CategoryPickerDialog(
            vm = vm,
            onPick = { c ->
                if (c.type == T.EXPENSE) {
                    pickCat = false
                    newCat = c
                } else {
                    Toast.makeText(ctx, "Chỉ đặt ngân sách cho khoản chi", Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = { pickCat = false }
        )
    }

    val nc = newCat
    if (nc != null) {
        BudgetDialog(
            title = "Ngân sách: " + nc.name,
            initial = "",
            canDelete = false,
            onSave = { amount ->
                vm.saveBudget(Budget(categoryId = nc.id, amount = amount))
                newCat = null
            },
            onDelete = {},
            onDismiss = { newCat = null }
        )
    }
    val eb = editing
    if (eb != null) {
        BudgetDialog(
            title = "Sửa: " + (byId[eb.categoryId]?.name ?: "Ngân sách"),
            initial = eb.amount.toString(),
            canDelete = true,
            onSave = { amount ->
                vm.saveBudget(eb.copy(amount = amount))
                editing = null
            },
            onDelete = {
                vm.deleteBudget(eb.id)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun BudgetDialog(
    title: String,
    initial: String,
    canDelete: Boolean,
    onSave: (Long) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { v -> text = v.filter { ch -> ch.isDigit() }.take(12) },
                    label = { Text("Hạn mức mỗi tháng (đ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                if (text.isNotBlank()) {
                    Text(moneyD(text.toLongOrNull() ?: 0), color = Muted, modifier = Modifier.padding(top = 6.dp))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = text.toLongOrNull() ?: 0L
                if (v > 0) onSave(v)
            }) { Text("Lưu", color = Green) }
        },
        dismissButton = {
            Row {
                if (canDelete) TextButton(onClick = onDelete) { Text("Xóa", color = Red) }
                TextButton(onClick = onDismiss) { Text("Hủy") }
            }
        }
    )
}
