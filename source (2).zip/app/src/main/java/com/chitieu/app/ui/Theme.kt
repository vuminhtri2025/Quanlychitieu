package com.chitieu.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

// ---- Bang mau nen / chu ----
val Bg = Color(0xFF0B0F17)
val CardBg = Color(0xFF161B26)
val BarBg = Color(0xFF212838)
val Muted = Color(0xFFB4BCCB)
val IconBg = Color(0xFF2F4858)

// ---- Mau chuc nang ----
val Green = Color(0xFF16A34A)
val Red = Color(0xFFFF6B6B)
val Blue = Color(0xFF4FC3F7)
val Orange = Color(0xFFFFA45C)
val Gold = Color(0xFFFFC857)

// ---- Gradient cho "colorful card" ----
val GradBlue = listOf(Color(0xFF3B82F6), Color(0xFF6366F1))
val GradCoral = listOf(Color(0xFFFF7A59), Color(0xFFFF4D8D))
val GradViolet = listOf(Color(0xFF8B5CF6), Color(0xFFD946EF))
val GradTeal = listOf(Color(0xFF0EA5A4), Color(0xFF22C55E))
val GradAmber = listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
val GradSky = listOf(Color(0xFF0EA5E9), Color(0xFF3B82F6))

// ---- Mau bieu tuong nhom ----
val CatColors = listOf(
    Color(0xFFEF5350), Color(0xFFFF9800), Color(0xFF26A69A), Color(0xFF42A5F5),
    Color(0xFFAB47BC), Color(0xFF66BB6A), Color(0xFFEC407A), Color(0xFF5C6BC0)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    // Gioi han co chu he thong de giao dien khong bi phinh to / mat chu
    val d = LocalDensity.current
    val density = Density(d.density, d.fontScale.coerceAtMost(1f) * 0.9f)
    CompositionLocalProvider(LocalDensity provides density) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Green,
                onPrimary = Color.White,
                background = Bg,
                onBackground = Color.White,
                surface = CardBg,
                onSurface = Color.White,
                surfaceVariant = BarBg,
                onSurfaceVariant = Muted,
                error = Red
            ),
            content = content
        )
    }
}
