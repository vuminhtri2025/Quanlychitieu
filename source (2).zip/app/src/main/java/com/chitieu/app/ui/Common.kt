package com.chitieu.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chitieu.app.data.Category
import com.chitieu.app.data.T
import com.chitieu.app.data.Txn
import com.chitieu.app.data.Wallet

@Composable
fun CatIcon(size: Dp = 44.dp, seed: Long = 0L) {
    val color = CatColors[(seed % CatColors.size).toInt()]
    Box(
        modifier = Modifier.size(size).clip(CircleShape).background(color),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Filled.Favorite, contentDescription = null,
            tint = Color.White, modifier = Modifier.size(size * 0.5f)
        )
    }
}

/** Card nhieu mau (gradient), chu trang ben tren. */
@Composable
fun GradientCard(
    colors: List<Color>,
    modifier: Modifier = Modifier,
    padding: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = modifier.fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(colors))
    ) {
        Column(modifier = Modifier.padding(padding), content = content)
    }
}

@Composable
fun WalletIcon(size: Dp = 44.dp) {
    Box(
        modifier = Modifier.size(size).clip(CircleShape).background(Color(0xFF3B82F6)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Filled.AccountBalanceWallet, contentDescription = null,
            tint = Color.White, modifier = Modifier.size(size * 0.5f)
        )
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = Muted, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        if (action != null) {
            TextButton(onClick = onAction) {
                Text(action, color = Green, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg)
    ) {
        Column(modifier = Modifier.padding(20.dp), content = content)
    }
}

@Composable
fun TopBar(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(CardBg).padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
            }
        } else {
            Spacer(Modifier.width(16.dp))
        }
        Text(
            title, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        actions()
    }
}

@Composable
fun TxnRow(t: Txn, cat: Category?, wallet: Wallet?, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(CardBg).clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CatIcon(seed = cat?.id ?: 0L)
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                cat?.name ?: "Khác", fontSize = 18.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val sub = timeVi(t.date) + " · " + t.note.ifBlank { wallet?.name ?: "" }
            if (sub.isNotBlank()) {
                Text(sub, color = Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.width(8.dp))
        Text(
            money(t.amount),
            color = if (T.isIn(t.type)) Blue else Red,
            fontSize = 18.sp
        )
    }
}
