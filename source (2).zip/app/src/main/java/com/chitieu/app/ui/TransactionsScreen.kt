package com.chitieu.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.chitieu.app.data.T

@Composable
fun TransactionsScreen(vm: AppViewModel, nav: NavController) {
    val wallets by vm.wallets.collectAsState()
    val txns by vm.txns.collectAsState()
    val cats by vm.categories.collectAsState()
    val byId = remember(cats) { cats.associateBy { it.id } }
    val walletById = remember(wallets) { wallets.associateBy { it.id } }

    val months = remember { (-12..2).map { monthRef(it) } }
    var monthIdx by remember { mutableIntStateOf(12) }
    val month = months[monthIdx]
    var walletMenu by remember { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }

    val filter = vm.txWalletFilter
    val selectedWallet = wallets.firstOrNull { it.id == filter }
    val balance = if (selectedWallet != null) {
        walletBalance(selectedWallet, txns)
    } else {
        wallets.sumOf { walletBalance(it, txns) }
    }

    val inMonth = txns.filter {
        (filter == null || it.walletId == filter) && it.date >= month.start && it.date < month.end
    }
    val totalIn = inMonth.filter { T.isIn(it.type) }.sumOf { it.amount }
    val totalOut = inMonth.filter { !T.isIn(it.type) }.sumOf { it.amount }
    val days = inMonth.groupBy { startOfDay(it.date) }.entries.sortedByDescending { it.key }

    Column(modifier = Modifier.fillMaxSize()) {
        // Thanh tren: chon vi + tim kiem
        Row(
            modifier = Modifier.fillMaxWidth().background(CardBg).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.width(48.dp))
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = BarBg,
                    modifier = Modifier.clickable { walletMenu = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WalletIcon(32.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(selectedWallet?.name ?: "Tất cả ví", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null)
                    }
                }
                DropdownMenu(expanded = walletMenu, onDismissRequest = { walletMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Tất cả ví") },
                        onClick = { vm.txWalletFilter = null; walletMenu = false }
                    )
                    for (w in wallets) {
                        DropdownMenuItem(
                            text = { Text(w.name) },
                            onClick = { vm.txWalletFilter = w.id; walletMenu = false }
                        )
                    }
                }
            }
            IconButton(onClick = { nav.navigate("search") }) {
                Icon(Icons.Filled.Search, contentDescription = "Tìm kiếm")
            }
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().background(CardBg),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Số dư", color = Muted, fontSize = 18.sp)
                    Text(moneyD(balance), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    ScrollableTabRow(
                        selectedTabIndex = monthIdx,
                        containerColor = CardBg,
                        edgePadding = 8.dp
                    ) {
                        months.forEachIndexed { i, m ->
                            Tab(
                                selected = i == monthIdx,
                                onClick = { monthIdx = i },
                                selectedContentColor = Color.White,
                                unselectedContentColor = Muted,
                                text = {
                                    Text(
                                        m.label, fontSize = 20.sp,
                                        fontWeight = if (i == monthIdx) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MiniStat("Tiền vào", money(totalIn), GradSky, Modifier.weight(1f))
                        MiniStat("Tiền ra", money(totalOut), GradCoral, Modifier.weight(1f))
                        MiniStat("Chênh lệch", money(totalIn - totalOut), GradTeal, Modifier.weight(1f))
                    }
                    TextButton(onClick = { showReport = true }) {
                        Text("Xem báo cáo cho giai đoạn này", color = Green, fontSize = 18.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            if (days.isEmpty()) {
                item {
                    Text(
                        "Chưa có giao dịch trong tháng này.\nNhấn dấu + để thêm.",
                        color = Muted, fontSize = 18.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(40.dp)
                    )
                }
            }
            for (day in days) {
                val list = day.value
                val net = list.sumOf { signedAmount(it) }
                item(key = "day" + day.key) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().background(CardBg)
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(dayOfMonth(day.key).toString(), fontSize = 44.sp)
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(weekdayVi(day.key), fontSize = 17.sp)
                                Text(monthYearVi(day.key), color = Muted, fontSize = 16.sp)
                            }
                            Text(money(net), fontSize = 20.sp)
                        }
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BarBg))
                    }
                }
                items(list, key = { "t" + it.id }) { t ->
                    TxnRow(t, byId[t.categoryId], walletById[t.walletId]) {
                        nav.navigate("add?id=" + t.id)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (showReport) {
        val expenseByGroup = inMonth.filter { it.type == T.EXPENSE }
            .groupBy { t -> byId[t.categoryId]?.let { c -> topCategory(c, byId).name } ?: "Khác" }
            .map { it.key to it.value.sumOf { t -> t.amount } }
            .sortedByDescending { it.second }
        val incomeByGroup = inMonth.filter { T.isIn(it.type) }
            .groupBy { t -> byId[t.categoryId]?.let { c -> topCategory(c, byId).name } ?: "Khác" }
            .map { it.key to it.value.sumOf { t -> t.amount } }
            .sortedByDescending { it.second }
        AlertDialog(
            onDismissRequest = { showReport = false },
            containerColor = CardBg,
            title = { Text("Báo cáo " + month.label) },
            text = {
                LazyColumn {
                    item { Text("Chi tiêu", color = Red, fontWeight = FontWeight.Bold) }
                    if (expenseByGroup.isEmpty()) item { Text("—", color = Muted) }
                    items(expenseByGroup) { g ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(g.first, modifier = Modifier.weight(1f))
                            Text(money(g.second))
                        }
                    }
                    item { Spacer(Modifier.height(12.dp)) }
                    item { Text("Thu nhập / vay", color = Blue, fontWeight = FontWeight.Bold) }
                    if (incomeByGroup.isEmpty()) item { Text("—", color = Muted) }
                    items(incomeByGroup) { g ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(g.first, modifier = Modifier.weight(1f))
                            Text(money(g.second))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showReport = false }) { Text("Đóng", color = Green) } }
        )
    }
}

@Composable
private fun MiniStat(label: String, value: String, colors: List<androidx.compose.ui.graphics.Color>, modifier: Modifier) {
    GradientCard(colors = colors, modifier = modifier, padding = 12.dp) {
        Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}
