package com.chitieu.app.ui

import androidx.compose.foundation.background
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

private val mainRoutes = listOf("home", "txns", "budget", "account")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    var showMenu by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            if (route in mainRoutes) {
                BottomBar(
                    route = route,
                    onNav = { r -> goTab(nav, r) },
                    onPlus = { showMenu = true }
                )
            }
        }
    ) { pad ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(pad)
        ) {
            composable("home") { HomeScreen(vm, nav) { showAi = true } }
            composable("txns") { TransactionsScreen(vm, nav) }
            composable("budget") { BudgetScreen(vm) }
            composable("account") { AccountScreen(vm, nav) { showAi = true } }
            composable("wallets") { WalletsScreen(vm, nav) }
            composable("categories") { CategoriesScreen(vm) { nav.popBackStack() } }
            composable("settings") { SettingsScreen(vm, nav) }
            composable("search") { SearchScreen(vm, nav) }
            composable(
                "add?id={id}",
                arguments = listOf(navArgument("id") {
                    type = NavType.LongType
                    defaultValue = -1L
                })
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: -1L
                AddTxnScreen(vm, nav, id) { showAi = true }
            }
        }
    }

    if (showMenu) {
        ModalBottomSheet(
            onDismissRequest = { showMenu = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CardBg
        ) {
            Column(modifier = Modifier.padding(bottom = 24.dp)) {
                SheetItem(Icons.Filled.Edit, "Thêm giao dịch thủ công") {
                    showMenu = false
                    nav.navigate("add?id=-1")
                }
                SheetItem(Icons.Filled.AutoAwesome, "Thêm bằng AI / giọng nói") {
                    showMenu = false
                    showAi = true
                }
            }
        }
    }

    if (showAi) {
        AiSheet(
            vm = vm,
            onDismiss = { showAi = false },
            onOpenSettings = {
                showAi = false
                nav.navigate("settings")
            }
        )
    }
}

private fun goTab(nav: NavController, route: String) {
    nav.navigate(route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun SheetItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green)
        Spacer(Modifier.width(18.dp))
        Text(label, fontSize = 19.sp)
    }
}

@Composable
private fun BottomBar(route: String?, onNav: (String) -> Unit, onPlus: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().height(92.dp)) {
        Row(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(68.dp)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFF121826)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TabItem(route == "home", "Tổng quan", Icons.Filled.Home, Color(0xFF60A5FA), Modifier.weight(1f)) { onNav("home") }
            TabItem(route == "txns", "Giao dịch", Icons.Filled.AccountBalanceWallet, Color(0xFFC084FC), Modifier.weight(1f)) { onNav("txns") }
            Spacer(Modifier.weight(1f))
            TabItem(route == "budget", "Ngân sách", Icons.Filled.Savings, Color(0xFFFFB454), Modifier.weight(1f)) { onNav("budget") }
            TabItem(route == "account", "Tài khoản", Icons.Filled.Person, Color(0xFF34D399), Modifier.weight(1f)) { onNav("account") }
        }
        Box(
            modifier = Modifier.align(Alignment.TopCenter).size(62.dp)
                .shadow(8.dp, CircleShape)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF22C55E), Color(0xFF0EA5A4))))
                .clickable(onClick = onPlus),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Thêm", tint = Color.White, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun TabItem(
    selected: Boolean,
    label: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val idle = Color(0xFF9AA3B5)
    Column(
        modifier = modifier.fillMaxHeight().clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) accent else idle, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(3.dp))
        Text(
            label,
            color = if (selected) Color.White else idle,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis
        )
    }
}
