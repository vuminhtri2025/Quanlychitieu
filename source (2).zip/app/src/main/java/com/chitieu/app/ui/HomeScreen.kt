package com.chitieu.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.chitieu.app.data.T
import java.util.Calendar

private val White85 = Color.White.copy(alpha = 0.85f)

@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController, onAi: () -> Unit) {
    val wallets by vm.wallets.collectAsState()
    val txns by vm.txns.collectAsState()
    val cats by vm.categories.collectAsState()
    val ctx = LocalContext.current

    val total = remember(wallets, txns) { wallets.sumOf { walletBalance(it, txns) } }
    val month = monthRef(0)
    val monthTx = txns.filter { it.date >= month.start && it.date < month.end }
    val spent = monthTx.filter { it.type == T.EXPENSE }.sumOf { it.amount }
    val income = monthTx.filter { T.isIn(it.type) }.sumOf { it.amount }
    val byId = cats.associateBy { it.id }
    val groups = monthTx.filter { it.type == T.EXPENSE }
        .groupBy { t -> byId[t.categoryId]?.let { c -> topCategory(c, byId).name } ?: "Khác" }
        .map { it.key to it.value.sumOf { t -> t.amount } }
        .sortedByDescending { it.second }
        .take(4)
    val dayNow = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ===== Dau trang =====
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Xin chào, " + vm.userName, color = Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Tổng quan tài chính", fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                RoundButton(Icons.Filled.Search) { nav.navigate("search") }
                Spacer(Modifier.width(8.dp))
                RoundButton(Icons.Filled.Notifications) {
                    Toast.makeText(ctx, "Chưa có thông báo mới", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // ===== Hero: tong so du + vi =====
        item {
            GradientCard(GradBlue) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Tổng số dư", color = White85, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Text(
                        "Xem tất cả", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.2f))
                            .clickable { nav.navigate("wallets") }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (vm.hideBalance) "••••••••" else moneyD(total),
                        color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, softWrap = false, modifier = Modifier.weight(1f, fill = false)
                    )
                    IconButton(onClick = { vm.toggleHide() }) {
                        Icon(
                            if (vm.hideBalance) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = "Ẩn/hiện số dư", tint = Color.White
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                for (w in wallets) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color.White.copy(alpha = 0.18f))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            WalletIcon(38.dp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(
                            w.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            if (vm.hideBalance) "•••" else moneyD(walletBalance(w, txns)),
                            color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1
                        )
                    }
                }
            }
        }

        // ===== Chi / Thu thang nay =====
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Đã chi tháng này", money(spent), GradCoral, Modifier.weight(1f))
                StatCard("Thu nhập tháng này", money(income), GradTeal, Modifier.weight(1f))
            }
        }

        // ===== Money Insider =====
        item {
            GradientCard(GradAmber) {
                Text("Money Insider", color = White85, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text("Chi tiêu theo nhóm", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Trung bình " + money(spent / dayNow.coerceAtLeast(1)) + " đ / ngày",
                    color = White85, fontSize = 14.sp
                )
                Spacer(Modifier.height(14.dp))
                if (groups.isEmpty()) {
                    Text("Chưa có khoản chi nào trong tháng này.", color = Color.White, fontSize = 15.sp)
                } else {
                    val max = groups.first().second.coerceAtLeast(1)
                    for (g in groups) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                g.first, color = Color.White, fontSize = 15.sp,
                                modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(money(g.second), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        }
                        Spacer(Modifier.height(5.dp))
                        LinearProgressIndicator(
                            progress = { g.second.toFloat() / max.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)),
                            color = Color.White, trackColor = Color.White.copy(alpha = 0.28f)
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                }
                Button(
                    onClick = { nav.navigate("txns") },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFFD9480F))
                ) { Text("Xem sổ giao dịch", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            }
        }

        // ===== Them bang AI / giong noi =====
        item {
            GradientCard(GradViolet) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color(0xFFFFE082))
                    Spacer(Modifier.width(10.dp))
                    Text("Thêm giao dịch bằng AI", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Nói hoặc gõ: “Hôm nay ăn phở 50k, đổ xăng 100k trả tiền mặt”",
                    color = White85, fontSize = 15.sp
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onAi,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF7E22CE))
                ) {
                    Icon(Icons.Filled.Mic, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Nói / nhập ngay", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun RoundButton(icon: ImageVector, onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(44.dp).clip(CircleShape).background(BarBg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun StatCard(label: String, value: String, colors: List<Color>, modifier: Modifier) {
    GradientCard(colors = colors, modifier = modifier, padding = 16.dp) {
        Text(label, color = White85, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(6.dp))
        Text(
            value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, softWrap = false
        )
        Text("đ", color = White85, fontSize = 13.sp)
    }
}
