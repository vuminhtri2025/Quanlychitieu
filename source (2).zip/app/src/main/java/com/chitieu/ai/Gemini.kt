package com.chitieu.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Gemini {
    class Result(val reply: String, val items: List<Pending>, val heard: String)

    private val fmt get() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    private fun system(): String {
        val now = SimpleDateFormat("EEEE yyyy-MM-dd HH:mm", Locale("vi")).format(Date())
        val month = txsOfMonth(0).filter { Store.cur(it.walletId) == "VND" }
        val chi = month.filter { !it.income }
        val byCat = chi.groupBy { it.category }.map { "${it.key}: ${it.value.sumOf { t -> t.amount }.vnd()}" }
        val bal = Store.wallets.joinToString { "${it.name}: ${Store.balance(it).money(it.currency)}" }
        return """
Bạn là "${Store.aiName}", trợ lý quản lý chi tiêu cá nhân trong app chat. Tính cách: ${PERSONAS[Store.persona]}. Luôn nói tiếng Việt, giữ đúng tính cách, trả lời ngắn gọn.
Bây giờ là: $now (giờ địa phương).
Danh sách ví (kèm đơn vị tiền): ${Store.wallets.joinToString { "${it.name} (${it.currency})" }}.
Danh sách mục: ${CATEGORIES.joinToString()}.
Tháng này: tổng chi ${chi.sumOf { it.amount }.vnd()}, tổng thu ${month.filter { it.income }.sumOf { it.amount }.vnd()}. Chi theo mục: ${byCat.joinToString("; ")}. Số dư ví: $bal. Ngân sách: ${Store.budgets.entries.joinToString { "${it.key}=${it.value.vnd()}" }}.

Nếu người dùng nhập thông tin chi/thu, hãy tách thành từng giao dịch. Quy tắc:
- amount là số nguyên theo đơn vị tiền của ví đã chọn (với VND: "50k"=50000, "2 triệu"=2000000, "1tr5"=1500000, "một củ"=1000000).
- type là "expense" hoặc "income". wallet phải đúng TÊN một ví trong danh sách (không kèm đơn vị); không nói rõ thì dùng ví đầu tiên. category chọn trong danh sách mục.
- datetime dạng "yyyy-MM-dd HH:mm". QUAN TRỌNG: tuyệt đối không dùng giờ hiện tại nếu người dùng có nhắc giờ, buổi hay bữa ăn. Quy đổi: giờ nói rõ ("8 giờ", "8h30", "20:15") dùng đúng giờ đó (nếu có chiều/tối và giờ <= 12 thì cộng 12); "sáng", "ăn sáng", "cà phê sáng" = 07:30; "trưa", "ăn trưa" = 12:00; "chiều", "ăn xế" = 16:00; "tối", "ăn tối" = 19:00; "khuya", "đêm" = 22:30. Các mốc ngày như "hôm qua", "hôm kia", "tuần trước", "thứ hai" thì đổi sang ngày tương ứng (giữ giờ theo quy tắc trên). Chỉ dùng giờ hiện tại khi người dùng không nhắc bất kỳ mốc thời gian nào hoặc nói "vừa xong", "mới đây", "bây giờ".
- note: gộp mọi chi tiết phụ (địa điểm, phương tiện, mua xăng ở đâu, đi với ai...) thành MỘT đoạn ghi chú ngắn.
Nếu không phải giao dịch (hỏi đáp, trò chuyện, hỏi thống kê), để transactions là mảng rỗng và trả lời dựa trên số liệu ở trên.
CHỈ trả về JSON: {"heard":"nội dung nghe được nếu tin nhắn là âm thanh, ngược lại để trống","reply":"lời nhắn theo tính cách","transactions":[{"amount":0,"type":"expense","wallet":"","category":"","note":"","datetime":""}]}
""".trimIndent()
    }

    suspend fun ask(audio: ByteArray? = null): Result = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        val msgs = Store.chat.takeLast(12).dropWhile { !it.fromUser }
        msgs.forEachIndexed { i, m ->
            val parts = JSONArray()
            if (audio != null && i == msgs.lastIndex) {
                parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav")
                    .put("data", Base64.encodeToString(audio, Base64.NO_WRAP))))
                parts.put(JSONObject().put("text", "(Tin nhắn này là giọng nói tiếng Việt. Hãy nghe, chép lại nguyên văn vào trường heard, rồi xử lý như tin nhắn gõ.)"))
            } else parts.put(JSONObject().put("text", m.text))
            contents.put(JSONObject().put("role", if (m.fromUser) "user" else "model").put("parts", parts))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.5))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/${Store.model}:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", Store.apiKey.trim())
        c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) error("Lỗi API $code: ${txt.take(250)}")
        var out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        out = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val j = JSONObject(out)
        val items = ArrayList<Pending>()
        val arr = j.optJSONArray("transactions") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val amount = o.optDouble("amount", 0.0).toLong()
            if (amount <= 0) continue
            val wallet = Store.wallets.firstOrNull { it.name.equals(o.optString("wallet").trim(), true) } ?: Store.wallets.first()
            val cat = CATEGORIES.firstOrNull { it.equals(o.optString("category"), true) } ?: "Khác"
            val time = try { fmt.parse(o.optString("datetime"))!!.time } catch (e: Exception) { System.currentTimeMillis() }
            items.add(Pending(amount, o.optString("type") == "income", wallet.id, cat, o.optString("note"), time))
        }
        Result(j.optString("reply", "Đã xong!"), items, j.optString("heard"))
    }
}
