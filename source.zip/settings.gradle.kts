// Bản sao Maven Central của Google đặt trước mavenCentral(): runner GitHub dùng chung IP nên
// repo.maven.apache.org hay trả lỗi 429 (Too Many Requests); bản sao này không bị giới hạn kiểu đó.
// Nếu bản sao thiếu gói nào, Gradle tự lấy tiếp từ mavenCentral() như cũ.
pluginManagement {
    repositories {
        google()
        maven(url = "https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        maven(url = "https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
    }
}
rootProject.name = "ChiTieuAI"
include(":app")
