plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.chitieu.ai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.chitieu.ai"
        minSdk = 26
        targetSdk = 34
        // build.yml truyền VERSION_CODE = số lần chạy workflow -> luôn tăng, cài đè được bản cũ
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
        versionName = "1.0.$versionCode"
    }
    signingConfigs {
        create("release") {
            storeFile = file("chitieu.jks")
            storePassword = "chitieu2026"
            keyAlias = "chitieu"
            keyPassword = "chitieu2026"
        }
    }
    buildTypes {
        release {
            // R8: thu gọn + tối ưu mã, bỏ tài nguyên/icon không dùng -> APK nhỏ, khởi động nhanh, ít tốn RAM/pin
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }
    // lint chạy lâu và có thể chặn build vì cảnh báo không ảnh hưởng; bản cá nhân bỏ qua cho nhanh, ổn định
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
