@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(active: Boolean = true) {
    var page by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = active && page != null) { page = null }
    val p = page
    if (p == null) SettingsMenu { page = it } else SettingsPage(p) { page = null }
}

private class SRow(val id: String, val emoji: String, val color: Color, val title: String, val sub: String)

@Composable
fun SettingsMenu(open: (String) -> Unit) {
    val ctx = LocalContext.current
    var about by remember { mutableStateOf(false) }
    val rows = listOf(
        SRow("ai", "🤖", Color(0xFF4C8DDB), "Trợ lý AI", "${Store.aiName} • ${Store.persona} • trả lời ${Store.replyLen.lowercase()}"),
        SRow("auto", "⚡", Color(0xFFF2994A), "Tự động lưu",
            if (Store.autoSave) "Bật • ngưỡng ${(Store.autoThreshold * 100).toInt()}% • AI đã học ${Auto.learned()} giao dịch" else "Tắt"),
        SRow("key", "🔑", Color(0xFF8E6BDB), "Kết nối Gemini", Store.model + " • " + if (Store.apiKey.isBlank()) "chưa nhập key" else "đã có key"),
        SRow("voice", "🎙️", Color(0xFFE867A0), "Giọng nói", if (Store.voiceMode == "gemini") "Ghi âm → Gemini nghe" else "Nhận diện của máy"),
        SRow("fx", "✨", Color(0xFF26A69A), "Hiệu ứng chat", if (Store.typeEffect) "Chữ hiện dần • ${Store.typeMs / 1000}s" else "Tắt"),
        SRow("wallet", "👛", Fresh, "Ví", "${Store.wallets.size} ví"),
        SRow("data", "📤", Color(0xFF3F8FE0), "Dữ liệu", "${Store.txs.size} giao dịch")
    )
    val name = Store.userName.trim()
    val ver = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Cài đặt")
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            AppCard(Modifier.fillMaxWidth(), color = Lilac) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(60.dp).background(Paper, CircleShape), contentAlignment = Alignment.Center) {
                        Text(name.firstOrNull()?.uppercase() ?: "🙂", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Fresh)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(if (name.isEmpty()) "Chưa đặt tên" else name, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("Trợ lý ${Store.aiName} • ${Store.persona}", color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            AppCard(Modifier.fillMaxWidth()) {
                rows.forEach { r ->
                    Row(Modifier.fillMaxWidth().clickable { open(r.id) }.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(r.emoji, r.color, 40.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.title, fontWeight = FontWeight.SemiBold)
                            Text(r.sub, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text("›", color = Muted, fontSize = 22.sp)
                    }
                    HorizontalDivider(Modifier.padding(start = 70.dp), color = Lilac)
                }
                Row(Modifier.fillMaxWidth().clickable { about = true }.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBubble("ℹ️", Muted, 40.dp)
                    Spacer(Modifier.width(14.dp))
                    Text("Giới thiệu ứng dụng", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text("›", color = Muted, fontSize = 22.sp)
                }
            }
        }
    }
    if (about) AlertDialog(
        onDismissRequest = { about = false }, title = { Text("Chi Tiêu AI") },
        text = { Text("Phiên bản $ver\nTrợ lý chi tiêu cá nhân: nhắn hoặc nói khoản chi, AI ghi sổ giúp bạn (dùng Google Gemini).") },
        confirmButton = { TextButton(onClick = { about = false }) { Text("Đóng") } }
    )
}

@Composable
fun SettingsPage(id: String, back: () -> Unit) {
    val title = when (id) {
        "ai" -> "🤖 Trợ lý AI"; "auto" -> "⚡ Tự động lưu"; "key" -> "🔑 Kết nối Gemini"; "voice" -> "🎙️ Giọng nói"
        "fx" -> "✨ Hiệu ứng chat"; "wallet" -> "👛 Ví"; else -> "📤 Dữ liệu"
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại") }
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (id) {
                "ai" -> AiSettings()
                "auto" -> AutoSettings()
                "key" -> KeySettings()
                "voice" -> VoiceSettings()
                "fx" -> FxSettings()
                "wallet" -> WalletSettings()
                else -> DataSettings()
            }
        }
    }
}
