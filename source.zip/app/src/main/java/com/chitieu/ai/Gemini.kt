package com.chitieu.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Gemini {
    class Result(val reply: String, val items: List<Pending>, val heard: String)

    private val fmt get() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    private fun system(wid: Long): String {
        val now = SimpleDateFormat("EEEE yyyy-MM-dd HH:mm", Locale("vi")).format(Date())
        val month = txsOfMonth(0).filter { Store.cur(it.walletId) == "VND" }
        val chi = month.filter { !it.income }
        val byCat = chi.groupBy { it.category }.map { "${it.key}: ${it.value.sumOf { t -> t.amount }.vnd()}" }
        val bal = Store.wallets.joinToString { "${it.name}: ${Store.balance(it).money(it.currency)}" }
        val lenRule = when (Store.replyLen) {
            "Ngắn" -> "Trả lời tối đa 1 câu."
            "Chi tiết" -> "Trả lời 3-5 câu, kèm nhận xét hoặc lời khuyên chi tiêu."
            else -> "Trả lời 1-2 câu."
        }
        val callRule = if (Store.userName.isBlank()) "" else "Gọi người dùng là ${Store.userName.trim()}."
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val debtTxt = Store.debts.filter { Store.remaining(it) > 0 }.joinToString("; ") {
            (if (it.lend) "${it.person} nợ mình " else "mình nợ ${it.person} ") + Store.remaining(it).money(it.cur) +
                (if (it.due > 0) " (hạn ${sdf.format(Date(it.due))})" else "")
        }.ifBlank { "không có" }
        val habitTxt = Auto.habits()
        return """
Bạn là "${Store.aiName}", trợ lý quản lý chi tiêu cá nhân trong app chat. Tính cách: ${PERSONAS[Store.persona]}. Luôn nói tiếng Việt, giữ đúng tính cách. $lenRule $callRule
Bây giờ là: $now (giờ địa phương).
Danh sách ví (kèm đơn vị tiền): ${Store.wallets.joinToString { "${it.name} (${it.currency})" }}.
Danh sách mục: ${CATEGORIES.joinToString()}.
Tháng này: tổng chi ${chi.sumOf { it.amount }.vnd()}, tổng thu ${month.filter { it.income }.sumOf { it.amount }.vnd()}. Chi theo mục: ${byCat.joinToString("; ")}. Số dư ví: $bal. Ngân sách: ${Store.budgets.entries.joinToString { "${it.key}=${it.value.vnd()}" }}.
Các khoản vay/nợ đang mở: $debtTxt. (Vay/nợ không tính vào thu chi tháng.)
Thói quen của người dùng (học từ lịch sử; dùng để chọn mục/ví khi người dùng không nói rõ):
$habitTxt

Nếu người dùng nhập thông tin chi/thu, hãy tách thành từng giao dịch. Quy tắc:
- amount là số nguyên theo đơn vị tiền của ví đã chọn (với VND: "50k"=50000, "2 triệu"=2000000, "1tr5"=1500000, "một củ"=1000000).
- type là một trong: "transfer" (chuyển tiền giữa hai ví của chính mình, KHÔNG phải chi tiêu; wallet = ví gửi, toWallet = ví nhận, chỉ khi hai ví cùng đơn vị tiền), "expense" (chi), "income" (thu), "borrow" (mình đi vay/mượn tiền, tiền vào ví), "lend" (mình cho người khác vay/mượn, tiền ra khỏi ví), "repay" (mình trả nợ, tiền ra), "collect" (người khác trả nợ mình, tiền vào). Với borrow/lend/repay/collect PHẢI điền person (tên người, giữ cách gọi như "anh Nam"); borrow/lend có thể điền due là hạn trả dạng "yyyy-MM-dd" (để trống nếu không nói). Trả một phần vẫn là repay/collect với số tiền đã trả. wallet phải đúng TÊN một ví trong danh sách (không kèm đơn vị); không nói rõ ví nào thì dùng ví mặc định của cuộc trò chuyện này là "${Store.walletName(wid)}" (chuyển ví mà không nói ví gửi thì ví gửi cũng là ví này). category chọn trong danh sách mục.
- datetime dạng "yyyy-MM-dd HH:mm". QUAN TRỌNG: tuyệt đối không dùng giờ hiện tại nếu người dùng có nhắc giờ, buổi hay bữa ăn. Quy đổi: giờ nói rõ ("8 giờ", "8h30", "20:15") dùng đúng giờ đó (nếu có chiều/tối và giờ <= 12 thì cộng 12); "sáng", "ăn sáng", "cà phê sáng" = 07:30; "trưa", "ăn trưa" = 12:00; "chiều", "ăn xế" = 16:00; "tối", "ăn tối" = 19:00; "khuya", "đêm" = 22:30. Các mốc ngày như "hôm qua", "hôm kia", "tuần trước", "thứ hai" thì đổi sang ngày tương ứng (giữ giờ theo quy tắc trên). Chỉ dùng giờ hiện tại khi người dùng không nhắc bất kỳ mốc thời gian nào hoặc nói "vừa xong", "mới đây", "bây giờ".
- note: gộp mọi chi tiết phụ (địa điểm, phương tiện, mua xăng ở đâu, đi với ai...) thành MỘT đoạn ghi chú ngắn.
- Thêm confidence (0 đến 1) cho từng giao dịch: mức chắc chắn số tiền, mục, ví, thời gian đã đúng ý người dùng (câu rõ ràng và khớp thói quen thì cao; mơ hồ hoặc khác thói quen thì thấp). walletGiven = true nếu người dùng nói rõ tên ví, ngược lại false.
- Hệ thống có thể tự lưu giao dịch khi đủ tin cậy, nên đừng bảo người dùng bấm Lưu; chỉ phản hồi ngắn theo tính cách.
Nếu không phải giao dịch (hỏi đáp, trò chuyện, hỏi thống kê), để transactions là mảng rỗng và trả lời dựa trên số liệu ở trên.
CHỈ trả về JSON: {"heard":"nội dung nghe được nếu tin nhắn là âm thanh, ngược lại để trống","reply":"lời nhắn theo tính cách","transactions":[{"amount":0,"type":"expense","wallet":"","category":"","note":"","datetime":"","person":"","due":"","toWallet":"","confidence":0.0,"walletGiven":false}]}
""".trimIndent()
    }

    suspend fun ask(chat: List<Msg>, wid: Long, audio: ByteArray? = null): Result = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        val msgs = chat.takeLast(12).dropWhile { !it.fromUser }
        msgs.forEachIndexed { i, m ->
            val parts = JSONArray()
            if (audio != null && i == msgs.lastIndex) {
                parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav")
                    .put("data", Base64.encodeToString(audio, Base64.NO_WRAP))))
                parts.put(JSONObject().put("text", "(Tin nhắn này là giọng nói tiếng Việt. Hãy nghe, chép lại nguyên văn vào trường heard, rồi xử lý như tin nhắn gõ.)"))
            } else parts.put(JSONObject().put("text", m.text))
            contents.put(JSONObject().put("role", if (m.fromUser) "user" else "model").put("parts", parts))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system(wid)))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", Store.temp.toDouble()))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/${Store.model}:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", Store.apiKey.trim())
        c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) error("Lỗi API $code: ${txt.take(250)}")
        var out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        out = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val j = JSONObject(out)
        val items = ArrayList<Pending>()
        val arr = j.optJSONArray("transactions") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val amount = o.optDouble("amount", 0.0).toLong()
            if (amount <= 0) continue
            val wallet = Store.wallets.firstOrNull { it.name.equals(o.optString("wallet").trim(), true) } ?: Store.wallets.first()
            val cat = CATEGORIES.firstOrNull { it.equals(o.optString("category"), true) } ?: "Khác"
            val time = try { fmt.parse(o.optString("datetime"))!!.time } catch (e: Exception) { System.currentTimeMillis() }
            val type = o.optString("type")
            val kind = if (type in listOf("borrow", "lend", "repay", "collect", "transfer")) type else "tx"
            val toW = Store.wallets.firstOrNull { it.name.equals(o.optString("toWallet").trim(), true) && it.id != wallet.id && it.currency == wallet.currency }?.id ?: Store.defaultTo(wallet.id)
            val due = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(o.optString("due"))!!.time } catch (e: Exception) { 0L }
            val pend = Pending(amount, type == "income", wallet.id, cat, o.optString("note"), time, kind, o.optString("person").trim(), due, toW, kind != "transfer")
            if (kind == "tx" && Store.autoSave) {
                val v = Auto.evaluate(pend, o.optDouble("confidence", 0.5).toFloat().coerceIn(0f, 1f), o.optBoolean("walletGiven", false) || wallet.id == wid)
                pend.conf = v.conf; pend.why = v.why; pend.auto = v.auto
            }
            items.add(pend)
        }
        Result(j.optString("reply", "Đã xong!"), items, j.optString("heard"))
    }
}
