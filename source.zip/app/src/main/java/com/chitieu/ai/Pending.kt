@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Thẻ xác nhận giao dịch trong khung chat: tóm tắt gọn, bấm "Chỉnh sửa" để mở đủ trường. */
@Composable
fun PendingCard(p: Pending) {
    if (p.dismissed) return
    if (p.autoSaved) { AutoSavedCard(p); return }
    val debt = p.kind in listOf("borrow", "lend", "repay", "collect")
    var edit by remember { mutableStateOf(false) }
    val cur = Store.cur(p.walletId)
    val sign = if (p.kind == "transfer") "" else if (p.isIncome()) "+" else "-"
    val color = if (p.kind == "transfer") Muted else if (p.isIncome()) Fresh else Coral
    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    val dd = remember { SimpleDateFormat("dd/MM/yyyy", Locale.US) }
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Pill(p.label(), color)
                Spacer(Modifier.weight(1f))
                Pill(if (p.saved) "Đã lưu" else "AI nhận diện", Fresh)
            }
            Text(sign + p.amount.money(cur), color = color, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            when {
                p.kind == "transfer" -> {
                    InfoRow("Từ ví", Store.walletName(p.walletId))
                    InfoRow("Đến ví", Store.wallets.firstOrNull { it.id == p.toWalletId }?.name ?: "Chưa chọn")
                }
                debt -> {
                    InfoRow("Người", p.person)
                    InfoRow("Ví", Store.walletName(p.walletId))
                    if ((p.kind == "borrow" || p.kind == "lend") && p.due > 0) InfoRow("Hạn trả", dd.format(Date(p.due)))
                }
                else -> {
                    InfoRow("Danh mục", catEmoji(p.category) + " " + p.category)
                    InfoRow("Ví", Store.walletName(p.walletId))
                }
            }
            InfoRow("Nội dung", p.note)
            InfoRow("Thời gian", df.format(Date(p.time)))
            if (p.conf > 0f && p.kind == "tx" && !p.saved) {
                Text("🤔 Tin cậy ${(p.conf * 100).toInt()}% — cần bạn xác nhận: ${p.why}", color = Muted, fontSize = 12.sp)
            }
            if (p.error.isNotEmpty()) Text(p.error, color = Coral, fontSize = 13.sp)

            if (edit && !p.saved) {
                HorizontalDivider(color = Lilac)
                OutlinedTextField(
                    p.amount.toString(), { p.amount = it.filter(Char::isDigit).toLongOrNull() ?: 0L }, Modifier.fillMaxWidth(),
                    label = { Text("Số tiền") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pick(p.label(), KIND_LABELS) { p.setLabel(it) }
                    Pick(Store.walletName(p.walletId), Store.wallets.map { it.name }) { n ->
                        Store.wallets.firstOrNull { it.name == n }?.let {
                            p.walletId = it.id
                            if (p.kind == "transfer" && !Store.canTransfer(p.walletId, p.toWalletId)) p.toWalletId = Store.defaultTo(p.walletId)
                        }
                    }
                }
                if (p.kind == "transfer") {
                    val opts = Store.wallets.filter { it.id != p.walletId && it.currency == Store.cur(p.walletId) }
                    if (opts.isEmpty()) Text("Chưa có ví thứ hai cùng đơn vị tiền để chuyển.", color = Coral, fontSize = 13.sp)
                    else Pick("→ " + (Store.wallets.firstOrNull { it.id == p.toWalletId }?.name ?: "Chọn ví nhận"), opts.map { it.name }) { n ->
                        opts.firstOrNull { it.name == n }?.let { p.toWalletId = it.id }
                    }
                } else if (!debt) {
                    Pick(p.category, CATEGORIES) { p.category = it; p.income = it in INCOME_CATS }
                } else {
                    OutlinedTextField(p.person, { p.person = it }, Modifier.fillMaxWidth(), label = { Text("Tên người") }, singleLine = true)
                    if (p.kind == "borrow" || p.kind == "lend") DueRow(p.due) { p.due = it }
                }
                DateTimeRow(p.time) { p.time = it }
                OutlinedTextField(p.note, { p.note = it }, Modifier.fillMaxWidth(), label = { Text("Nội dung") })
                if (!debt) ReportSwitch(p.report) { p.report = it }
            }

            if (p.saved) {
                Text("✅ Đã lưu", color = Fresh, fontWeight = FontWeight.Bold)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = {
                            val e = Store.savePending(p)
                            if (e == null) { p.saved = true; p.error = ""; edit = false } else p.error = e
                        },
                        modifier = Modifier.weight(1.3f).height(48.dp), shape = CircleShape
                    ) { Text("Xác nhận", fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { edit = !edit }, modifier = Modifier.weight(1f)) {
                        Text(if (edit) "Thu gọn" else "Chỉnh sửa", color = Muted)
                    }
                    TextButton(onClick = { p.dismissed = true }) { Text("Bỏ", color = Coral) }
                }
            }
        }
    }
}

@Composable
fun AutoSavedCard(p: Pending) {
    var edit by remember { mutableStateOf(false) }
    val t = Store.txs.firstOrNull { it.id == p.txId }
    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (t == null) {
                Text("🗑 Giao dịch đã bị xóa", color = Muted, fontSize = 13.sp)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pill("⚡ Đã tự lưu", Fresh)
                    Spacer(Modifier.weight(1f))
                    Pill("Tin cậy ${(p.conf * 100).toInt()}%", Muted)
                }
                Text(
                    (if (t.income) "+" else "-") + t.fmt(), color = if (t.income) Fresh else Coral,
                    fontSize = 32.sp, fontWeight = FontWeight.Bold
                )
                InfoRow("Danh mục", catEmoji(t.category) + " " + t.category)
                InfoRow("Ví", Store.walletName(t.walletId))
                InfoRow("Nội dung", t.note)
                InfoRow("Thời gian", df.format(Date(t.time)))
                if (p.why.isNotBlank()) Text(p.why, color = Muted, fontSize = 12.sp)
                Row {
                    TextButton(onClick = { Store.txs.remove(t); Store.save(); p.autoSaved = false; p.saved = false }) { Text("↩ Hoàn tác") }
                    TextButton(onClick = { edit = true }) { Text("✏️ Sửa") }
                }
            }
        }
    }
    if (edit && t != null) EditTxDialog(t) { edit = false }
}
