@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Cấu hình một AI dự phòng bất kỳ dùng kiểu API của OpenAI (chat/completions). */
class ExtraCfg {
    var preset by mutableStateOf(CUSTOM_PRESET)
    var url by mutableStateOf("")
    var key by mutableStateOf("")
    var model by mutableStateOf("")

    /** Đủ thông tin và dùng https (không gửi key qua http). */
    fun ready() = key.isNotBlank() && model.isNotBlank() && url.trim().startsWith("https://")
    fun label(): String = if (preset != CUSTOM_PRESET) preset.substringBefore(" (") else url.trim().removePrefix("https://").substringBefore('/')
}

class ExtraPreset(val name: String, val url: String, val model: String, val keyAt: String)

const val CUSTOM_PRESET = "Tùy chỉnh"

val EXTRA_PRESETS = listOf(
    ExtraPreset("DeepSeek", "https://api.deepseek.com", "deepseek-flash", "platform.deepseek.com"),
    ExtraPreset("Cerebras", "https://api.cerebras.ai/v1", "llama-3.3-70b", "cloud.cerebras.ai"),
    ExtraPreset("Mistral", "https://api.mistral.ai/v1", "mistral-small-latest", "console.mistral.ai"),
    ExtraPreset("OpenRouter (miễn phí)", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free", "openrouter.ai/keys"),
    ExtraPreset("NVIDIA NIM", "https://integrate.api.nvidia.com/v1", "meta/llama-3.3-70b-instruct", "build.nvidia.com"),
    ExtraPreset(CUSTOM_PRESET, "", "", "")
)

/** Gọi một AI dự phòng kiểu OpenAI: chat/completions, ưu tiên chế độ JSON. */
object ExtraAi {
    private val THINK = Regex("(?s)<think>.*?</think>")

    private fun errText(name: String, code: Int, raw: String): String {
        val parsed = try {
            val e = JSONObject(raw).opt("error")
            if (e is JSONObject) e.optString("message") else e?.toString().orEmpty()
        } catch (_: Exception) { "" }
        val msg = parsed.ifBlank { raw.take(160) }.trim()
        val hint = when (code) { 401, 403 -> " Kiểm tra lại API key."; 404 -> " Kiểm tra lại địa chỉ API và tên model."; 429 -> " Đã hết hạn mức hoặc gọi quá nhanh."; else -> "" }
        return "$name $code: ${msg.take(140)}$hint"
    }

    /** Lấy phần JSON từ câu trả lời (bỏ rào ```json, bỏ phần suy nghĩ <think>). */
    fun extractJson(s: String): String {
        val t = THINK.replace(s, "").trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = t.indexOf('{'); val b = t.lastIndexOf('}')
        return if (a >= 0 && b > a) t.substring(a, b + 1) else t
    }

    private fun post(url: String, key: String, body: JSONObject): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer " + key.trim())
        c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
        return Pair(code, stream.bufferedReader().use { it.readText() })
    }

    suspend fun chatJson(x: ExtraCfg, system: String, msgs: List<Pair<String, String>>, temperature: Double): String = withContext(Dispatchers.IO) {
        val base = x.url.trim().trimEnd('/')
        val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        var useJson = true
        var lastErr: Exception = IllegalStateException("Không gọi được ${x.label()}")
        for (attempt in 0 until 3) {
            try {
                val body = JSONObject().put("model", x.model.trim()).put("messages", arr)
                    .put("temperature", temperature.coerceIn(0.0, 1.5))
                if (useJson) body.put("response_format", JSONObject().put("type", "json_object"))
                val (code, resp) = post(url, x.key, body)
                if (code in 200..299) {
                    val content = JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                    return@withContext extractJson(content)
                }
                lastErr = ApiException(code, errText(x.label(), code, resp))
                // dịch vụ không hỗ trợ chế độ JSON -> thử lại không dùng (prompt đã yêu cầu chỉ trả JSON)
                if (code == 400 && useJson && (resp.contains("response_format", true) || resp.contains("json", true))) { useJson = false; continue }
                if (code == 408 || code == 429 || code >= 500) { if (attempt < 2) delay(1500L); continue }
                throw lastErr
            } catch (e: IOException) {
                lastErr = e
                if (attempt < 2) delay(1500L)
            }
        }
        throw lastErr
    }
}

/** Trang cài đặt cho AI dự phòng thứ 2 và thứ 3. */
@Composable
fun ExtraAiSettings() {
    Section("Thứ tự dự phòng") {
        Text(
            "Gemini → Groq → AI thứ 2 → AI thứ 3. Khi một AI lỗi, app tự thử AI kế tiếp (nếu đã nhập key). " +
                "AI thứ 2 và 3 chỉ xử lý chữ; giọng nói vẫn do Gemini hoặc Groq (Whisper) chép thành chữ trước.",
            style = MaterialTheme.typography.bodySmall
        )
    }
    Store.extras.forEachIndexed { i, x -> ExtraAiSection(i + 2, x) }
}

@Composable
private fun ExtraAiSection(n: Int, x: ExtraCfg) {
    var show by remember { mutableStateOf(false) }
    val preset = EXTRA_PRESETS.firstOrNull { it.name == x.preset }
    Section("AI dự phòng thứ ${n + 0} (tùy chọn)") {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Nhà cung cấp", Modifier.weight(1f))
            Pick(x.preset, EXTRA_PRESETS.map { it.name }) { name ->
                val p = EXTRA_PRESETS.first { it.name == name }
                x.preset = name
                if (p.url.isNotEmpty()) { x.url = p.url; x.model = p.model }
                Store.save()
            }
        }
        OutlinedTextField(x.key, { x.key = it.trim(); Store.save() }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation())
        TextButton(onClick = { show = !show }) { Text(if (show) "🙈 Ẩn key" else "👁 Hiện key") }
        OutlinedTextField(x.url, { x.url = it.trim(); Store.save() }, Modifier.fillMaxWidth(), label = { Text("Địa chỉ API (https://...)") }, singleLine = true)
        OutlinedTextField(x.model, { x.model = it.trim(); Store.save() }, Modifier.fillMaxWidth(), label = { Text("Tên model") }, singleLine = true)
        if (preset != null && preset.keyAt.isNotEmpty()) {
            Text("Lấy key tại ${preset.keyAt}. Tên model có thể đổi theo thời gian, hãy sửa ở ô trên nếu báo lỗi 404.", style = MaterialTheme.typography.bodySmall)
        }
        if (x.key.isNotBlank() && !x.url.trim().startsWith("https://")) {
            Text("⚠️ Địa chỉ API phải bắt đầu bằng https:// thì mới được dùng.", color = Coral, style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = { x.preset = CUSTOM_PRESET; x.url = ""; x.key = ""; x.model = ""; Store.save() }) { Text("🗑 Xóa cấu hình này") }
    }
}
