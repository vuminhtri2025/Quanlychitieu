@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

@Composable
fun StatsScreen() {
    var tab by remember { mutableIntStateOf(0) }
    val offs = when (tab) { 0 -> listOf(0); 1 -> listOf(-1); else -> (-5..0).toList() }
    val m = offs.flatMap { txsOfMonth(it) }
    val thu = sumByCur(m.filter { it.income })
    val chiAll = sumByCur(m.filter { !it.income })
    val net = (thu.keys + chiAll.keys).associateWith { (thu[it] ?: 0L) - (chiAll[it] ?: 0L) }
    val chi = m.filter { !it.income && Store.cur(it.walletId) == "VND" }
    val total = chi.sumOf { it.amount }
    val byCat = chi.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }

    // ---- Dòng tiền (VND): lũy kế theo ngày (1 tháng) hoặc tổng theo tháng (6 tháng)
    val vndIds = Store.wallets.filter { it.currency == "VND" }.map { it.id }.toSet()
    val a = ArrayList<Float>()
    val b = ArrayList<Float>()
    val labels: List<String>
    val flowTitle: String
    if (tab < 2) {
        val off = offs[0]
        val days = if (off == 0) Calendar.getInstance().get(Calendar.DAY_OF_MONTH) else monthStart(off).getActualMaximum(Calendar.DAY_OF_MONTH)
        val tin = LongArray(days + 1)
        val tout = LongArray(days + 1)
        m.filter { it.walletId in vndIds }.forEach { t ->
            val d = Calendar.getInstance().apply { timeInMillis = t.time }.get(Calendar.DAY_OF_MONTH)
            if (d in 1..days) { if (t.income) tin[d] += t.amount else tout[d] += t.amount }
        }
        var ci = 0L
        var co = 0L
        for (d in 1..days) { ci += tin[d]; co += tout[d]; a.add(ci.toFloat()); b.add(co.toFloat()) }
        labels = listOf(1, 1 + (days - 1) / 4, 1 + (days - 1) / 2, 1 + 3 * (days - 1) / 4, days).distinct().map { it.toString() }
        flowTitle = "Dòng tiền trong tháng (lũy kế)"
    } else {
        offs.forEach { o ->
            val mm = txsOfMonth(o).filter { it.walletId in vndIds }
            a.add(mm.filter { it.income }.sumOf { it.amount }.toFloat())
            b.add(mm.filter { !it.income }.sumOf { it.amount }.toFloat())
        }
        labels = offs.map { "T" + (monthStart(it).get(Calendar.MONTH) + 1) }
        flowTitle = "Dòng tiền theo tháng"
    }
    val maxV = maxOf(a.maxOrNull() ?: 0f, b.maxOrNull() ?: 0f).coerceAtLeast(1f)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Thống kê")
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            PillTabs(listOf("Tháng này", "Tháng trước", "6 tháng"), tab) { tab = it }
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Chi tiêu theo danh mục (ví VND)", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    CategoryDonut(topCats(chi, 4), total, "Chi tiêu")
                }
            }
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(flowTitle, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        LegendDot(Fresh, "Thu")
                        Spacer(Modifier.width(10.dp))
                        LegendDot(Coral, "Chi")
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().height(150.dp)) {
                        Column(Modifier.fillMaxHeight().padding(end = 8.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Text(maxV.toLong().shortVnd(), fontSize = 11.sp, color = Muted)
                            Text((maxV / 2).toLong().shortVnd(), fontSize = 11.sp, color = Muted)
                            Text("0", fontSize = 11.sp, color = Muted)
                        }
                        LineChart(a, b, Fresh, Coral, maxV, Modifier.weight(1f).fillMaxHeight())
                    }
                    Row(Modifier.fillMaxWidth().padding(start = 36.dp, top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        labels.forEach { Text(it, fontSize = 11.sp, color = Muted) }
                    }
                }
            }
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Tài chính tổng quan", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SumCard("Thu nhập", thu.show(), Fresh, FreshSoft, Modifier.weight(1f))
                        SumCard("Chi tiêu", chiAll.show(), Coral, CoralSoft, Modifier.weight(1f))
                    }
                    val left = net.values.sum()
                    SumCard("Còn lại", net.show(), if (left >= 0) Fresh else Coral, Lilac, Modifier.fillMaxWidth())
                }
            }
            if (byCat.isNotEmpty()) {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Chi tiết theo mục", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        byCat.forEach { (k, v) ->
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(catEmoji(k) + "  " + k, Modifier.weight(1f), fontSize = 14.sp)
                                    Text("${v.vnd()} (${if (total > 0) v * 100 / total else 0}%)", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                                Bar(if (total > 0) v.toFloat() / total else 0f, catColor(k))
                            }
                        }
                    }
                }
            }
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Số dư các ví", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Store.wallets.forEach {
                        Row(Modifier.fillMaxWidth()) {
                            Text(it.name, Modifier.weight(1f))
                            Text(Store.balance(it).money(it.currency), fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}
