package com.chitieu.ai

/** AI "học" từ lịch sử giao dịch để quyết định có đủ tự tin tự lưu hay không. */
object Auto {
    class Verdict(val conf: Float, val auto: Boolean, val why: String)

    private val STOP = setOf("và", "với", "ở", "tại", "cho", "của", "là", "hết", "bằng", "các", "này", "nay", "hôm", "đã", "vừa", "mình", "tôi")

    fun tokens(s: String): Set<String> =
        NotifScan.cleanNote(s).lowercase().split(Regex("[^\\p{L}]+")).filter { it.length >= 2 && it !in STOP }.toSet()

    /** Số giao dịch thường (không vay/nợ, không chuyển ví) mà AI đã học. */
    fun learned(): Int = Store.txs.count { it.debtId == 0L && it.transferId == 0L }

    fun level(n: Int) = when {
        n < 10 -> "Đang làm quen"
        n < 50 -> "Đã biết thói quen của bạn"
        else -> "Rất hiểu bạn"
    }

    /** Tóm tắt thói quen (món/khoản hay gặp -> mục, ví, số tiền thường) để gửi cho Gemini. */
    fun habits(): String {
        val g = Store.txs.filter { it.debtId == 0L && it.transferId == 0L && tokens(it.note).isNotEmpty() }
            .groupBy { tokens(it.note).sorted().joinToString(" ") to it.income }
        return g.values.filter { it.size >= 2 }.sortedByDescending { it.size }.take(30).joinToString("\n") { l ->
            val cat = l.groupingBy { it.category }.eachCount().maxByOrNull { it.value }!!.key
            val w = l.groupingBy { it.walletId }.eachCount().maxByOrNull { it.value }!!.key
            "- \"${NotifScan.cleanNote(l.first().note)}\" x${l.size} → ${if (l.first().income) "thu" else "chi"}, mục $cat, ví ${Store.walletName(w)}, thường ${l.map { it.amount }.sorted()[l.size / 2].money(Store.cur(w))}"
        }.ifBlank { "(chưa có)" }
    }

    fun evaluate(p: Pending, modelConf: Float, walletGiven: Boolean): Verdict {
        val n = learned()
        val key = tokens(p.note)
        val sims = if (key.isEmpty()) emptyList() else Store.txs.filter {
            it.debtId == 0L && it.transferId == 0L && it.income == p.income &&
                tokens(it.note).let { k -> k.isNotEmpty() && (k intersect key).size.toFloat() / (k union key).size >= 0.5f }
        }
        val m = sims.size
        val agreeCat = if (m == 0) 0f else sims.count { it.category == p.category }.toFloat() / m
        val agreeWal = if (m == 0) 0.5f else sims.count { it.walletId == p.walletId }.toFloat() / m
        val h = agreeCat * minOf(1f, m / 5f)                       // càng nhiều lần gặp, càng chắc
        val wal = if (walletGiven) 1f else agreeWal
        val amt = if (m >= 3) {
            val med = sims.map { it.amount }.sorted()[m / 2].toFloat()
            if (p.amount / med in 0.2f..5f) 1f else 0.3f           // số tiền lệch xa thói quen -> kém chắc
        } else 0.7f
        val exp = minOf(1f, n / 30f)                                // càng nhiều dữ liệu tổng, càng tin
        val conf = (0.35f * modelConf + 0.35f * h + 0.15f * wal + 0.15f * amt) * (0.6f + 0.4f * exp)

        val blockers = ArrayList<String>()
        if (n < Store.autoMinData) blockers += "mới học $n/${Store.autoMinData} giao dịch"
        if (conf < Store.autoThreshold) blockers += "chưa đạt ngưỡng ${(Store.autoThreshold * 100).toInt()}%"
        if (Store.cur(p.walletId) != "VND") blockers += "ví không phải VND"
        else if (p.amount > Store.autoMax) blockers += "vượt hạn mức tự lưu ${Store.autoMax.vnd()}"
        val info = if (m == 0) "chưa có giao dịch tương tự" else "đã gặp $m lần tương tự, ${(agreeCat * 100).toInt()}% cùng mục ${p.category}"
        val auto = Store.autoSave && p.kind == "tx" && p.amount > 0 && blockers.isEmpty()
        return Verdict(conf, auto, if (blockers.isEmpty()) info else info + " • " + blockers.joinToString(", "))
    }
}
