package com.chitieu.ai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Khung nghe giọng nói nổi trên màn hình chính, mở từ widget: nghe ngay, nói xong tự dừng,
 * AI hiểu và ghi giao dịch, hiện thẻ xác nhận. Không cần mở màn hình chat của app.
 */
class VoiceQuickActivity : ComponentActivity() {
    private val recorder = Recorder()
    private var phase by mutableStateOf("init")   // init | perm | listening | thinking | done | error
    private var heard by mutableStateOf("")
    private var result by mutableStateOf<Msg?>(null)
    private var errorText by mutableStateOf("")
    private var elapsed by mutableIntStateOf(0)
    private var lvl by mutableIntStateOf(0)
    private var wid = TOTAL_ID

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else fail("Chưa cấp quyền micro. Hãy cấp quyền micro cho app hoặc đổi sang \"Nhận diện của máy\" ở Tài khoản → Giọng nói.")
    }
    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !t.isNullOrBlank()) process(null, t) else finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Store.systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        readIntent(intent)
        setContent { AppTheme { QuickUi() } }
        if (savedInstanceState == null) begin()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (phase == "listening") try { recorder.stop() } catch (_: Exception) {}
        readIntent(intent)
        begin()
    }

    override fun onDestroy() {
        if (phase == "listening") try { recorder.stop() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun readIntent(i: Intent?) {
        val auto = i?.getBooleanExtra(VoiceWidget.EXTRA_AUTO, false) ?: false
        val id = i?.getLongExtra(VoiceWidget.EXTRA_WALLET, TOTAL_ID) ?: TOTAL_ID
        wid = when {
            auto || id == TOTAL_ID -> TOTAL_ID
            Store.wallets.any { it.id == id } -> id
            else -> Store.wallets.firstOrNull()?.id ?: TOTAL_ID
        }
    }

    private fun roomName() = if (wid == TOTAL_ID) "Trò chuyện tổng (AI tự chọn ví)" else "Ví " + Store.walletName(wid)

    private fun fail(msg: String) { errorText = msg; phase = "error" }

    private fun begin() {
        heard = ""; result = null; errorText = ""; elapsed = 0; lvl = 0
        if (!Store.hasAi()) { fail("Chưa nhập API key. Vào app → Tài khoản → Trợ lý AI để nhập."); return }
        Speaker.stop()
        if (Store.voiceMode == "system") {
            phase = "init"
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            try { speechLauncher.launch(i) } catch (e: ActivityNotFoundException) { fail("Máy chưa có dịch vụ nhận diện giọng nói.") }
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecording()
        } else {
            phase = "perm"
            permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startRecording() {
        try {
            recorder.start()
            elapsed = 0; lvl = 0
            phase = "listening"
        } catch (e: Exception) {
            fail("Không mở được mic: ${e.message}. Thử đổi chế độ ở Tài khoản → Giọng nói.")
        }
    }

    private fun stopAndProcess() {
        if (phase != "listening") return
        val pcm = recorder.stop()
        if (!hasSound(pcm)) { fail("Không thu được âm thanh (mic có thể đang bị app khác chặn). Bạn thử nói lại nhé."); return }
        process(wav(pcm), null)
    }

    /** Gửi câu lệnh (giọng nói hoặc chữ) cho AI, ghi vào lịch sử phòng chat tương ứng và hiện kết quả. */
    private fun process(audio: ByteArray?, text: String?) {
        phase = "thinking"
        val chat = Store.chatOf(wid)
        val m = Msg(true, if (audio != null) "🎤 đang nghe…" else "🎤 $text")
        chat.add(m)
        Store.busy.add(wid)
        val app = applicationContext
        Store.scope.launch {
            try {
                val r = Gemini.ask(chat, wid, audio)
                if (audio != null) m.text = "🎤 " + r.heard.ifBlank { "(không nghe rõ)" }
                heard = m.text
                r.items.forEach { if (it.auto && Store.savePending(it) == null) { it.saved = true; it.autoSaved = true } }
                val reply = Msg(false, r.reply, r.items)
                chat.add(reply)
                result = reply
                phase = "done"
                if (Store.voiceReply) runCatching { Speaker.speak(app, Speaker.compose(r)) }
            } catch (e: Exception) {
                chat.remove(m)   // không để lại tin nhắn không có trả lời
                fail("⚠️ ${e.message}")
            } finally {
                Store.busy.remove(wid)
                Store.saveChats()
            }
        }
    }

    private fun openChat() {
        Store.chatWallet = wid
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        finish()
    }

    @Composable
    private fun QuickUi() {
        // theo dõi mức âm: tự dừng khi bạn nói xong (im lặng ~1,6 giây sau khi đã nói) hoặc hết thời gian ghi tối đa
        LaunchedEffect(phase) {
            if (phase == "listening") {
                var silentMs = 0
                var spoke = false
                var ticks = 0
                while (phase == "listening") {
                    delay(150)
                    lvl = recorder.level
                    ticks++
                    if (ticks % 7 == 0) elapsed++
                    if (lvl > 1200) { spoke = true; silentMs = 0 } else if (spoke) silentMs += 150
                    if ((spoke && silentMs >= 1600) || elapsed >= Store.maxRecSec) { stopAndProcess(); break }
                }
            }
        }
        val none = remember { MutableInteractionSource() }
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = none, indication = null) { if (phase != "thinking") finish() },
            contentAlignment = Alignment.BottomCenter
        ) {
            Surface(
                color = Lavender,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                modifier = Modifier.fillMaxWidth().clickable(interactionSource = none, indication = null) {}
            ) {
                Column(Modifier.navigationBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("🎤 Ra lệnh bằng giọng nói", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(roomName(), color = Muted, fontSize = 12.sp)
                    when (phase) {
                        "listening" -> {
                            val s by animateFloatAsState(1f + (lvl / 32768f).coerceIn(0f, 1f) * 1.4f, label = "mic")
                            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(84.dp).scale(s).background(Fresh, CircleShape), contentAlignment = Alignment.Center) {
                                    Text("🎤", fontSize = 34.sp)
                                }
                            }
                            Text(
                                "Đang nghe… nói xong mình tự dừng (${elapsed}s/${Store.maxRecSec}s)",
                                color = Muted, fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
                            )
                            if (wid == TOTAL_ID) Text("Gợi ý: nói kèm tên ví hoặc loại tiền, ví dụ \"ăn trưa 120 nghìn ví Techcombank\".", color = Muted, fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { stopAndProcess() }, modifier = Modifier.weight(1f)) { Text("✔ Xong") }
                                OutlinedButton(onClick = { finish() }) { Text("Hủy") }
                            }
                        }
                        "thinking" -> {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                CircularProgressIndicator(Modifier.size(28.dp), color = Fresh, strokeWidth = 3.dp)
                                Text("Đang hiểu câu lệnh…")
                            }
                        }
                        "done" -> {
                            val r = result
                            if (heard.isNotBlank()) Text(heard, color = Muted, fontSize = 13.sp, lineHeight = 18.sp)
                            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (r != null) Text(r.text, fontSize = 15.sp, lineHeight = 21.sp)
                                r?.pending?.forEach { PendingCard(it) }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { begin() }) { Text("🎤 Nói tiếp", maxLines = 1, softWrap = false) }
                                OutlinedButton(onClick = { openChat() }) { Text("💬 Mở chat", maxLines = 1, softWrap = false) }
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = { finish() }) { Text("Đóng", maxLines = 1, softWrap = false) }
                            }
                        }
                        "error" -> {
                            Text(errorText, color = Coral, fontSize = 14.sp, lineHeight = 20.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { begin() }) { Text("🎤 Thử lại", maxLines = 1, softWrap = false) }
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = { finish() }) { Text("Đóng", maxLines = 1, softWrap = false) }
                            }
                        }
                        else -> Text("Đang chuẩn bị…", color = Muted)
                    }
                }
            }
        }
    }
}
