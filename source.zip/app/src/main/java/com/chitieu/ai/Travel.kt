@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

object Travel {
    /** (mã, tên nước/vùng, tỉ giá tham khảo: 1 đơn vị = ? VND). Tỉ giá chỉ để gợi ý, người dùng tự sửa. */
    val CURRENCIES = listOf(
        Triple("USD", "Mỹ", 25400.0),
        Triple("EUR", "Châu Âu", 29500.0),
        Triple("JPY", "Nhật Bản", 168.0),
        Triple("KRW", "Hàn Quốc", 18.5),
        Triple("THB", "Thái Lan", 760.0),
        Triple("SGD", "Singapore", 19500.0),
        Triple("CNY", "Trung Quốc", 3550.0),
        Triple("HKD", "Hồng Kông", 3250.0),
        Triple("TWD", "Đài Loan", 800.0),
        Triple("MYR", "Malaysia", 5700.0),
        Triple("IDR", "Indonesia", 1.6),
        Triple("GBP", "Anh", 33500.0),
        Triple("AUD", "Úc", 16500.0),
        Triple("CAD", "Canada", 18500.0),
        Triple("AED", "UAE", 6900.0)
    )

    fun label(code: String): String =
        CURRENCIES.firstOrNull { it.first == code }?.let { "${it.first} — ${it.second}" } ?: code

    fun defaultRate(code: String): Double = CURRENCIES.firstOrNull { it.first == code }?.third ?: 0.0

    /** 1 đơn vị [cur] = ? VND (0 nếu không biết). Tiền của chuyến đi dùng tỉ giá người dùng nhập. */
    fun rateToVnd(cur: String): Double = when {
        cur == "VND" -> 1.0
        cur == Store.travelCur -> Store.travelRate
        else -> defaultRate(cur)
    }

    /** Quy đổi [amount] đơn vị [from] sang đơn vị tiền của ví ([to]); 0 nếu không có tỉ giá. */
    fun convert(amount: Double, from: String, to: String): Long {
        if (from == to) return Math.round(amount)
        val a = rateToVnd(from)
        val b = rateToVnd(to)
        if (a <= 0.0 || b <= 0.0) return 0L
        return Math.round(amount * a / b)
    }

    /** 5000.0 -> "5.000"; 5.5 -> "5.50". */
    fun fmtForeign(v: Double): String =
        if (v == Math.floor(v)) String.format(Locale.US, "%,d", v.toLong()).replace(',', '.')
        else String.format(Locale.US, "%.2f", v)

    private const val DAY = 86_400_000L

    /** Giao dịch chi/thu thuộc chuyến đi hiện tại (hoặc gần nhất), chỉ tính ví VND. */
    fun tripTxs(): List<Tx> {
        if (Store.travelStart <= 0L) return emptyList()
        val end = if (Store.travelOn || Store.travelEnd <= 0L) Long.MAX_VALUE else Store.travelEnd
        return Store.txs.filter {
            it.time >= Store.travelStart && it.time <= end && it.debtId == 0L && it.transferId == 0L &&
                it.report && Store.cur(it.walletId) == "VND"
        }
    }

    fun tripDays(): Int {
        if (Store.travelStart <= 0L) return 1
        val end = if (Store.travelOn || Store.travelEnd <= 0L) System.currentTimeMillis() else Store.travelEnd
        return (((end - Store.travelStart) / DAY).toInt() + 1).coerceAtLeast(1)
    }
}

private fun rateText(r: Double): String =
    if (r == Math.floor(r)) r.toLong().toString() else r.toString()

@Composable
fun TravelSettings() {
    var name by remember { mutableStateOf(Store.travelName) }
    var rateTxt by remember { mutableStateOf(rateText(Store.travelRate)) }
    var conv by remember { mutableStateOf("") }
    val cur = Store.travelCur

    fun setOn(on: Boolean) {
        if (on) {
            // bật: nếu chưa có chuyến nào đang mở thì bắt đầu chuyến mới từ bây giờ
            if (Store.travelStart <= 0L || Store.travelEnd > 0L) { Store.travelStart = System.currentTimeMillis(); Store.travelEnd = 0L }
            Store.travelOn = true
        } else {
            Store.travelOn = false
            Store.travelEnd = System.currentTimeMillis()
        }
        Store.save()
    }

    Section("✈️ Chế độ du lịch") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Đang đi du lịch", fontWeight = FontWeight.Medium)
                Text(
                    "Bật lên thì nhắn \"ăn phở 5 đô\" hoặc \"mua áo 30000\" trong chat, app tự quy đổi ra tiền ví theo tỉ giá bên dưới.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(checked = Store.travelOn, onCheckedChange = { setOn(it) })
        }
        OutlinedTextField(
            name, { name = it; Store.travelName = it; Store.save() }, Modifier.fillMaxWidth(),
            label = { Text("Tên chuyến đi (vd: Hàn Quốc 2026)") }, singleLine = true
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Tiền nước đến", Modifier.weight(1f))
            Pick(Travel.label(cur), Travel.CURRENCIES.map { "${it.first} — ${it.second}" }) { sel ->
                val code = sel.substringBefore(" ")
                Store.travelCur = code
                Store.travelRate = Travel.defaultRate(code)
                rateTxt = rateText(Store.travelRate)
                Store.save()
            }
        }
        OutlinedTextField(
            rateTxt,
            { s ->
                rateTxt = s
                val v = s.replace(',', '.').toDoubleOrNull()
                if (v != null && v > 0.0) { Store.travelRate = v; Store.save() }
            },
            Modifier.fillMaxWidth(),
            label = { Text("1 $cur = ... VND") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Text(
            "Tỉ giá gợi ý chỉ để tham khảo, hãy sửa lại theo tỉ giá bạn đổi tiền thực tế.",
            style = MaterialTheme.typography.bodySmall
        )
        if (Store.travelOn) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Bắt đầu từ", Modifier.weight(1f))
                DateTimeRow(Store.travelStart) { Store.travelStart = it; Store.save() }
            }
        }
    }

    Section("Quy đổi nhanh") {
        OutlinedTextField(
            conv, { conv = it }, Modifier.fillMaxWidth(),
            label = { Text("Số tiền ($cur)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        val v = conv.replace(',', '.').toDoubleOrNull()
        if (v != null && Store.travelRate > 0.0) {
            Text("≈ " + Math.round(v * Store.travelRate).vnd(), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        } else {
            Text("Nhập số tiền ngoại tệ để xem quy đổi ra VND.", style = MaterialTheme.typography.bodySmall)
        }
    }

    Section("Chi tiêu chuyến đi") {
        if (Store.travelStart <= 0L) {
            Text("Chưa có chuyến đi nào. Bật chế độ du lịch để bắt đầu theo dõi.", style = MaterialTheme.typography.bodySmall)
        } else {
            val trip = Travel.tripTxs()
            val spent = trip.filter { !it.income }.sumOf { it.amount }
            val days = Travel.tripDays()
            val title = Store.travelName.trim().ifBlank { "Chuyến đi" } + if (Store.travelOn) " • đang diễn ra" else " • đã kết thúc"
            Text(title, fontWeight = FontWeight.Medium)
            Text(spent.vnd(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Coral)
            if (Store.travelRate > 0.0) {
                Text("≈ ${Travel.fmtForeign(spent / Store.travelRate)} $cur", color = Muted, fontSize = 14.sp)
            }
            Text("$days ngày • trung bình ${(spent / days).vnd()}/ngày • ${trip.count { !it.income }} khoản chi", color = Muted, fontSize = 13.sp)
            val byCat = trip.filter { !it.income }.groupBy { it.category }
                .mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }.take(5)
            byCat.forEach { (k, v2) ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row {
                        Text(catEmoji(k) + "  " + k, Modifier.weight(1f), fontSize = 14.sp)
                        Text(v2.vnd(), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                    Bar(if (spent > 0L) v2.toFloat() / spent else 0f, catColor(k))
                }
            }
        }
    }
}
