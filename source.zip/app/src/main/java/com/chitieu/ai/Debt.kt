@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DebtScreen(onBack: (() -> Unit)? = null) {
    val names = listOf("Tất cả", "Mình nợ", "Nợ mình", "Đã xong")
    var tab by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    val open = Store.debts.filter { Store.remaining(it) > 0 }
    val shown = when (tab) {
        0 -> open
        1 -> open.filter { !it.lend }
        2 -> open.filter { it.lend }
        else -> Store.debts.filter { Store.remaining(it) <= 0 }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Sổ nợ", onBack) {
            RoundBtn(onClick = { adding = true }) { Icon(Icons.Default.Add, contentDescription = "Thêm khoản nợ", tint = Color.White) }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AppCard(Modifier.fillMaxWidth(), color = Lilac) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Tổng nợ phải trả", color = Muted, fontSize = 14.sp)
                            Text(sumDebt(open.filter { !it.lend }).show(), color = Coral, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text("Người khác nợ mình: " + sumDebt(open.filter { it.lend }).show(), color = Fresh, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                        Text("💳", fontSize = 44.sp)
                    }
                }
            }
            item { PillTabs(names, tab) { tab = it } }
            if (shown.isEmpty()) {
                item {
                    Text(
                        "Chưa có khoản nào. Bạn cũng có thể nhắn cho AI: \"vay anh Nam 2 triệu\".",
                        color = Muted, modifier = Modifier.padding(8.dp)
                    )
                }
            }
            items(shown.sortedBy { if (it.due > 0) it.due else Long.MAX_VALUE }, key = { it.id }) { DebtCard(it) }
            item { TipCard("Thanh toán đúng hạn giúp bạn tránh phát sinh lãi suất nhé!", "💡") }
        }
    }
    if (adding) DebtDialog(null) { adding = false }
}

@Composable
fun DebtCard(d: Debt) {
    var expand by remember { mutableStateOf(false) }
    var pay by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    val paid = Store.paid(d)
    val rem = d.principal - paid
    val over = d.due > 0 && d.due < System.currentTimeMillis() && rem > 0
    val df = remember { SimpleDateFormat("dd/MM/yyyy", Locale.US) }
    val dft = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    val verb = if (d.lend) "thu" else "trả"
    val color = if (d.lend) Fresh else Coral
    AppCard(Modifier.fillMaxWidth(), onClick = { expand = !expand }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(if (d.lend) "👤" else "🏦", color)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.person, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "Ngày ${df.format(Date(d.time))}" + if (d.due > 0) " • hạn ${df.format(Date(d.due))}" else "",
                        color = if (over) Coral else Muted, fontSize = 12.sp
                    )
                }
                Text(rem.money(d.cur), color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
            }
            Bar((paid.toFloat() / d.principal).coerceIn(0f, 1f), color)
            Text("Gốc ${d.principal.money(d.cur)} • đã $verb ${paid.money(d.cur)}", color = Muted, fontSize = 12.sp)
            if (over) Text("⚠️ Quá hạn", color = Coral, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (d.note.isNotBlank()) Text("📝 ${d.note}", color = Muted, fontSize = 12.sp)
            if (!expand) {
                Text("Chạm để xem lịch sử và thao tác ›", color = Muted, fontSize = 12.sp)
            } else {
                HorizontalDivider(color = Lilac)
                val pays = Store.txs.filter { it.debtId == d.id && it.id != d.id }.sortedByDescending { it.time }
                if (pays.isEmpty()) Text("Chưa có lần $verb nào.", color = Muted, fontSize = 13.sp)
                pays.forEach { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${dft.format(Date(t.time))} • ${Store.walletName(t.walletId)}", Modifier.weight(1f), color = Muted, fontSize = 13.sp)
                        Text(t.amount.money(d.cur), fontSize = 14.sp)
                        TextButton(onClick = { Store.txs.remove(t); Store.save() }) { Text("🗑") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (rem > 0) Button(onClick = { pay = true }) { Text(if (d.lend) "💰 Thu nợ" else "💸 Trả nợ") }
                    TextButton(onClick = { edit = true }) { Text("✏️ Sửa") }
                    TextButton(onClick = { del = true }) { Text("🗑 Xóa", color = Coral) }
                }
            }
        }
    }
    if (pay) PayDialog(d) { pay = false }
    if (edit) DebtDialog(d) { edit = false }
    if (del) AlertDialog(
        onDismissRequest = { del = false }, title = { Text("Xóa khoản nợ của ${d.person}?") },
        text = { Text("Sẽ xóa luôn các giao dịch gốc và trả/thu của khoản này, số dư ví thay đổi theo.") },
        confirmButton = { TextButton(onClick = { Store.deleteDebt(d); del = false }) { Text("Xóa", color = Coral) } },
        dismissButton = { TextButton(onClick = { del = false }) { Text("Hủy") } }
    )
}
