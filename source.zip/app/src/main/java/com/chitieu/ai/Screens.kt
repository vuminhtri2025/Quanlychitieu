@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val RED = Color(0xFFD32F2F)
private val GREEN = Color(0xFF2E7D32)

@Composable
fun Pick(value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("$value ▾") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false }) }
        }
    }
}

@Composable
fun PendingCard(p: Pending) {
    if (p.dismissed) return
    val ctx = LocalContext.current
    val cal = Calendar.getInstance().apply { timeInMillis = p.time }
    Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text((if (p.income) "+" else "-") + p.amount.vnd(), fontWeight = FontWeight.Bold,
                color = if (p.income) GREEN else RED)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pick(p.wallet, Store.wallets) { p.wallet = it }
                Pick(p.category, CATEGORIES) { p.category = it; p.income = it in INCOME_CATS }
            }
            Row {
                TextButton(onClick = {
                    DatePickerDialog(ctx, { _, y, m, d ->
                        p.time = Calendar.getInstance().apply { timeInMillis = p.time; set(y, m, d) }.timeInMillis
                    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                }) { Text("📅 " + SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(p.time))) }
                TextButton(onClick = {
                    TimePickerDialog(ctx, { _, h, mi ->
                        p.time = Calendar.getInstance().apply { timeInMillis = p.time; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, mi) }.timeInMillis
                    }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
                }) { Text("🕒 " + SimpleDateFormat("HH:mm", Locale.US).format(Date(p.time))) }
            }
            if (p.note.isNotBlank()) Text("📝 ${p.note}", style = MaterialTheme.typography.bodySmall)
            if (p.saved) Text("✅ Đã lưu", color = GREEN) else Row {
                Button(onClick = {
                    Store.add(Tx(System.nanoTime(), p.amount, p.income, p.wallet, p.category, p.note, p.time))
                    p.saved = true
                }) { Text("Lưu") }
                TextButton(onClick = { p.dismissed = true }) { Text("Bỏ") }
            }
        }
    }
}

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun send(t: String) {
        if (t.isBlank() || busy) return
        if (Store.apiKey.isBlank()) {
            Store.chat.add(Msg(false, "Bạn chưa nhập API key. Vào tab Cài đặt, dán key lấy từ Google AI Studio nhé."))
            return
        }
        Store.chat.add(Msg(true, t)); input = ""; busy = true
        scope.launch {
            try {
                val r = Gemini.ask()
                Store.chat.add(Msg(false, r.reply, r.items))
            } catch (e: Exception) {
                Store.chat.add(Msg(false, "⚠️ ${e.message}"))
            }
            busy = false
        }
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }
    LaunchedEffect(Store.chat.size, busy) { list.animateScrollToItem(Store.chat.size) }

    Column(Modifier.fillMaxSize()) {
        Text("🤖 ${Store.aiName}", Modifier.padding(start = 12.dp, top = 8.dp), fontWeight = FontWeight.Bold)
        LazyRow(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(PERSONAS.keys.toList()) { p ->
                FilterChip(selected = Store.persona == p, onClick = { Store.persona = p; Store.save() }, label = { Text(p) })
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp), state = list, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Store.chat) { m ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start) {
                    Surface(shape = RoundedCornerShape(14.dp),
                        color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                        Text(m.text, Modifier.padding(10.dp))
                    }
                    m.pending.forEach { PendingCard(it) }
                }
            }
            item { if (busy) Text("${Store.aiName} đang nghĩ…", style = MaterialTheme.typography.bodySmall) }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Nhập khoản chi tiêu…") }, maxLines = 3)
            TextButton(onClick = {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
                try { voice.launch(i) } catch (e: ActivityNotFoundException) {
                    Toast.makeText(ctx, "Máy chưa có dịch vụ nhận diện giọng nói", Toast.LENGTH_SHORT).show()
                }
            }) { Text("🎤") }
            Button(onClick = { send(input) }, enabled = !busy) { Text("Gửi") }
        }
    }
}

@Composable
fun MonthBar(off: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = { onChange(off - 1) }) { Text("◀") }
        Text(SimpleDateFormat("'Tháng' MM/yyyy", Locale.US).format(monthStart(off).time), fontWeight = FontWeight.Bold)
        TextButton(onClick = { onChange(off + 1) }, enabled = off < 0) { Text("▶") }
    }
}

@Composable
fun HistoryScreen() {
    var off by remember { mutableIntStateOf(0) }
    val list = txsOfMonth(off).sortedByDescending { it.time }
    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        MonthBar(off) { off = it }
        Text("Chi ${list.filter { !it.income }.sumOf { it.amount }.vnd()}  •  Thu ${list.filter { it.income }.sumOf { it.amount }.vnd()}")
        if (list.isEmpty()) Text("Chưa có giao dịch.", Modifier.padding(top = 16.dp))
        LazyColumn {
            items(list, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${t.category} • ${t.wallet}", fontWeight = FontWeight.Medium)
                        Text(df.format(Date(t.time)) + if (t.note.isNotBlank()) " — ${t.note}" else "", style = MaterialTheme.typography.bodySmall)
                    }
                    Text((if (t.income) "+" else "-") + t.amount.vnd(), color = if (t.income) GREEN else RED)
                    TextButton(onClick = { Store.txs.remove(t); Store.save() }) { Text("🗑") }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun StatsScreen() {
    var off by remember { mutableIntStateOf(0) }
    val m = txsOfMonth(off)
    val chi = m.filter { !it.income }
    val total = chi.sumOf { it.amount }
    val byCat = chi.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        MonthBar(off) { off = it }
        val thu = m.filter { it.income }.sumOf { it.amount }
        Text("Thu: ${thu.vnd()}", color = GREEN); Text("Chi: ${total.vnd()}", color = RED)
        Text("Còn lại: ${(thu - total).vnd()}", fontWeight = FontWeight.Bold)
        Text("Chi theo mục", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        byCat.forEach { (k, v) ->
            Text("$k — ${v.vnd()} (${if (total > 0) v * 100 / total else 0}%)")
            LinearProgressIndicator(progress = { if (total > 0) v.toFloat() / total else 0f }, Modifier.fillMaxWidth())
        }
        Text("Số dư các ví", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Store.wallets.forEach { w ->
            Text("$w: " + Store.txs.filter { it.wallet == w }.sumOf { if (it.income) it.amount else -it.amount }.vnd())
        }
    }
}

@Composable
fun BudgetScreen() {
    var edit by remember { mutableStateOf<String?>(null) }
    var txt by remember { mutableStateOf("") }
    val spent = txsOfMonth(0).filter { !it.income }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Ngân sách tháng này (chạm để đặt hạn mức)", fontWeight = FontWeight.Bold)
        CATEGORIES.filter { it !in INCOME_CATS }.forEach { c ->
            val lim = Store.budgets[c] ?: 0L
            val s = spent[c] ?: 0L
            Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                .padding(10.dp).then(Modifier), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { edit = c; txt = if (lim > 0) lim.toString() else "" }) {
                    Text("$c: ${s.vnd()} / ${if (lim > 0) lim.vnd() else "chưa đặt"}")
                }
                if (lim > 0) {
                    LinearProgressIndicator(progress = { (s.toFloat() / lim).coerceAtMost(1f) }, Modifier.fillMaxWidth(),
                        color = if (s > lim) RED else MaterialTheme.colorScheme.primary)
                    if (s > lim) Text("⚠️ Vượt ngân sách ${(s - lim).vnd()}", color = RED)
                }
            }
        }
    }
    edit?.let { c ->
        AlertDialog(onDismissRequest = { edit = null }, title = { Text("Hạn mức: $c") },
            text = { OutlinedTextField(txt, { txt = it.filter(Char::isDigit) }, label = { Text("Số tiền (đ)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
            confirmButton = { TextButton(onClick = {
                val v = txt.toLongOrNull() ?: 0L
                if (v > 0) Store.budgets[c] = v else Store.budgets.remove(c)
                Store.save(); edit = null
            }) { Text("Lưu") } },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("Hủy") } })
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var newWallet by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Google AI Studio", fontWeight = FontWeight.Bold)
        OutlinedTextField(Store.apiKey, { Store.apiKey = it; Store.save() }, Modifier.fillMaxWidth(),
            label = { Text("API key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(Store.model, { Store.model = it.trim(); Store.save() }, Modifier.fillMaxWidth(),
            label = { Text("Model") }, singleLine = true)
        Text("Trợ lý AI", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        OutlinedTextField(Store.aiName, { Store.aiName = it; Store.save() }, Modifier.fillMaxWidth(),
            label = { Text("Tên AI") }, singleLine = true)
        PERSONAS.forEach { (k, v) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = Store.persona == k, onClick = { Store.persona = k; Store.save() })
                Column { Text(k, fontWeight = FontWeight.Medium); Text(v, style = MaterialTheme.typography.bodySmall) }
            }
        }
        Text("Ví", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Store.wallets.toList().forEach { w ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(w, Modifier.weight(1f))
                if (Store.wallets.size > 1) TextButton(onClick = { Store.wallets.remove(w); Store.save() }) { Text("🗑") }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(newWallet, { newWallet = it }, Modifier.weight(1f), label = { Text("Thêm ví mới") }, singleLine = true)
            Button(onClick = {
                if (newWallet.isNotBlank() && newWallet !in Store.wallets) { Store.wallets.add(newWallet.trim()); Store.save(); newWallet = "" }
            }) { Text("Thêm") }
        }
        Button(onClick = {
            val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val csv = "Thời gian,Loại,Số tiền,Ví,Mục,Ghi chú\n" + Store.txs.sortedBy { it.time }.joinToString("\n") {
                "${f.format(Date(it.time))},${if (it.income) "Thu" else "Chi"},${it.amount},${it.wallet},${it.category},\"${it.note.replace("\"", "\"\"")}\""
            }
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, csv), "Xuất CSV"))
        }, Modifier.padding(top = 8.dp)) { Text("📤 Xuất dữ liệu CSV") }
    }
}
