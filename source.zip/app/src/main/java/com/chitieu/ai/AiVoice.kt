@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import android.util.Base64
import android.widget.Toast
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

const val TTS_MODEL_FAST = "gemini-3.8-flash-lite-tts"
const val TTS_MODEL_QUALITY = "gemini-3.8-flash-tts"

/** Giọng dựng sẵn của Gemini (đều đọc được tiếng Việt). Giới tính theo bảng của Google. */
val AI_PREBUILT = listOf(
    VoiceOpt("Kore", "Nữ • Kore"), VoiceOpt("Leda", "Nữ • Leda"),
    VoiceOpt("Aoede", "Nữ • Aoede"), VoiceOpt("Despina", "Nữ • Despina"),
    VoiceOpt("Charon", "Nam • Charon"), VoiceOpt("Fenrir", "Nam • Fenrir"),
    VoiceOpt("Orus", "Nam • Orus"), VoiceOpt("Algieba", "Nam • Algieba")
)

/** Đọc bằng giọng AI của Gemini (cần mạng + API key). Lỗi thì tự quay về giọng của máy. */
object AiVoice {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private var job: Job? = null
    private var track: AudioTrack? = null

    /** Thư viện giọng tiếng Việt lấy từ Gemini. libState: 0 chưa tải, 1 đang tải, 2 xong, 3 lỗi. */
    var lib by mutableStateOf<List<VoiceOpt>>(emptyList())
        private set
    var libState by mutableStateOf(0)
        private set
    var libError by mutableStateOf("")
        private set

    private fun style(): String {
        // Giọng trong thư viện đã gắn sẵn vùng miền nên không thêm chỉ dẫn; chỉ giọng dựng sẵn mới cần
        if (AI_PREBUILT.none { it.name == Store.aiVoice }) return ""
        return when (Store.aiAccent) {
            "Miền Bắc" -> "Speak Vietnamese with a Northern Vietnamese (Hanoi) accent, natural and clear."
            "Miền Nam" -> "Speak Vietnamese with a Southern Vietnamese (Saigon) accent, natural and friendly."
            else -> ""
        }
    }

    fun speak(ctx: Context, text: String, fallback: () -> Unit) {
        stop()
        val app = ctx.applicationContext
        job = Store.scope.launch {
            try {
                val (pcm, rate) = synth(text)
                val tr = play(pcm, rate)
                // phát xong thì giải phóng ngay (không giữ bộ đệm âm thanh)
                val playMs = ((pcm.size / 2L) * 1000L / rate / Speaker.speedValue()).toLong() + 1500L
                delay(playMs)
                if (track === tr) releaseTrack()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(app, "Giọng AI lỗi (${(e.message ?: e.javaClass.simpleName).take(70)}), dùng giọng của máy", Toast.LENGTH_SHORT).show()
                fallback()
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        releaseTrack()
    }

    private fun releaseTrack() {
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }

    private fun play(pcm: ByteArray, rate: Int): AudioTrack {
        releaseTrack()
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        try { t.setPlaybackParams(PlaybackParams().setSpeed(Speaker.speedValue()).setPitch(Speaker.pitchValue())) } catch (_: Exception) {}
        t.play()
        track = t
        return t
    }

    /** Gọi Gemini TTS, trả về PCM 16-bit mono và tần số lấy mẫu. */
    private suspend fun synth(text: String): Pair<ByteArray, Int> = withContext(Dispatchers.IO) {
        val part = JSONObject().put("text", text)
        val st = style()
        if (st.isNotEmpty()) part.put("speech_metadata", JSONObject().put("style", st))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(part))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("voice", Store.aiVoice))))
        val c = URL("$BASE/models/${Store.aiTtsModel}:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", Store.apiKey.trim())
        c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) error("API $code: ${txt.take(100)}")
        val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data") ?: continue
            val data = inl.optString("data")
            if (data.isBlank()) continue
            val mime = inl.optString("mimeType", inl.optString("mime_type"))
            val rate = Regex("""rate=(\d+)""").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
            return@withContext Pair(Base64.decode(data, Base64.DEFAULT), rate)
        }
        error("Gemini không trả về âm thanh")
    }

    // ------------------------------------------------------------ thư viện giọng tiếng Việt

    private fun accentVi(a: String): String {
        val l = a.lowercase()
        return when {
            listOf("north", "hanoi", "hà nội", "miền bắc").any { it in l } -> "Miền Bắc"
            listOf("south", "saigon", "sài gòn", "ho chi minh", "miền nam").any { it in l } -> "Miền Nam"
            listOf("central", "hue", "huế", "miền trung").any { it in l } -> "Miền Trung"
            else -> a
        }
    }

    private fun genderVi(g: String) = when (g.lowercase()) { "female" -> "Nữ"; "male" -> "Nam"; else -> g }

    fun loadLibrary() {
        if (libState == 1) return
        if (Store.apiKey.isBlank()) { libError = "Chưa nhập API key Gemini"; libState = 3; return }
        libState = 1
        libError = ""
        Store.scope.launch {
            try {
                lib = fetchLibrary()
                libState = 2
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                libError = (e.message ?: e.javaClass.simpleName).take(120)
                libState = 3
            }
        }
    }

    private suspend fun fetchLibrary(): List<VoiceOpt> = withContext(Dispatchers.IO) {
        val c = URL("$BASE/voices?language_code=vi-VN&page_size=100").openConnection() as HttpURLConnection
        c.setRequestProperty("x-goog-api-key", Store.apiKey.trim())
        c.connectTimeout = 20000; c.readTimeout = 40000
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) error("API $code: ${txt.take(100)}")
        val arr = JSONObject(txt).optJSONArray("voices") ?: JSONArray()
        val out = ArrayList<VoiceOpt>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            if (id.isBlank()) continue
            val lang = o.optString("languageCode", o.optString("language_code"))
            if (lang.isNotBlank() && !lang.startsWith("vi", ignoreCase = true)) continue
            val name = o.optString("displayName", o.optString("display_name")).ifBlank { id }
            val label = listOf(name, genderVi(o.optString("gender")), accentVi(o.optString("accent")))
                .filter { it.isNotBlank() }.joinToString(" • ")
            out.add(VoiceOpt(id, label))
        }
        out
    }
}

@Composable
fun AiVoiceSettings() {
    val ctx = LocalContext.current
    val sample = "Đã ghi chi 50 nghìn đồng, mục Ăn uống, ví Tiền mặt."
    fun pick(id: String, label: String) { Store.aiVoice = id; Store.aiVoiceLabel = label; Store.save(); Speaker.speak(ctx, sample) }

    Text("Giọng AI nam/nữ (bấm để nghe thử)", style = MaterialTheme.typography.bodySmall)
    AI_PREBUILT.forEach { v ->
        Radio(v.label, "Giọng có sẵn của Gemini, đọc được tiếng Việt", Store.aiVoice == v.name) { pick(v.name, v.label) }
    }
    Text("Giọng vùng miền (cho giọng có sẵn ở trên)", style = MaterialTheme.typography.bodySmall)
    Chips(listOf("Mặc định", "Miền Bắc", "Miền Nam"), Store.aiAccent) { Store.aiAccent = it; Store.save(); Speaker.speak(ctx, sample) }
    Text("Chất lượng", style = MaterialTheme.typography.bodySmall)
    Chips(listOf("Nhanh", "Chất lượng"), if (Store.aiTtsModel == TTS_MODEL_QUALITY) "Chất lượng" else "Nhanh") {
        Store.aiTtsModel = if (it == "Chất lượng") TTS_MODEL_QUALITY else TTS_MODEL_FAST
        Store.save(); Speaker.speak(ctx, sample)
    }
    Text("Thư viện giọng tiếng Việt của Gemini", style = MaterialTheme.typography.bodySmall)
    if (!Store.aiVoiceIsPrebuilt()) Text("Đang dùng: ${Store.aiVoiceLabel}", style = MaterialTheme.typography.bodySmall)
    OutlinedButton(onClick = { AiVoice.loadLibrary() }) {
        Text(if (AiVoice.libState == 1) "Đang tải…" else if (AiVoice.libState == 2) "Tải lại danh sách" else "Tải danh sách giọng")
    }
    when (AiVoice.libState) {
        2 -> if (AiVoice.lib.isEmpty()) Text("Thư viện chưa có giọng tiếng Việt nào cho tài khoản này.", style = MaterialTheme.typography.bodySmall)
        3 -> Text("Không tải được: ${AiVoice.libError}", style = MaterialTheme.typography.bodySmall)
        else -> {}
    }
    AiVoice.lib.forEach { v ->
        Radio(v.label, "Giọng gắn sẵn giới tính và vùng miền", Store.aiVoice == v.id()) { pick(v.name, v.label) }
    }
    Text(
        "Giọng AI cần mạng và dùng API key Gemini (có thể tính phí theo gói của bạn). Nếu lỗi, app tự đọc bằng giọng của máy. " +
            "Bắc/Nam cho giọng có sẵn được điều khiển bằng chỉ dẫn gửi cho AI nên có thể chưa thật chuẩn; " +
            "giọng trong thư viện có nhãn vùng miền thường ổn định hơn.",
        style = MaterialTheme.typography.bodySmall
    )
}

private fun VoiceOpt.id() = name
