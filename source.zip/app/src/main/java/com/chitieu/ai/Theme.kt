@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// ===== Bảng màu "Soft Minimal Premium" (sáng) và bản tối xám trắng =====
/** Đang dùng giao diện tối? (đọc state nên giao diện tự cập nhật khi đổi) */
val isDark: Boolean
    get() = when (Store.themeMode) {
        "dark" -> true
        "light" -> false
        else -> Store.systemDark
    }

private fun pick(light: Long, dark: Long): Color = Color(if (isDark) dark else light)

val Lavender: Color get() = pick(0xFFF8F5FA, 0xFF161719)     // nền chính
val Lilac: Color get() = pick(0xFFEDE6F2, 0xFF2E3035)        // card phụ
val Paper: Color get() = pick(0xFFFFFFFF, 0xFF232528)        // card chính
val Fresh: Color get() = pick(0xFF299B69, 0xFF34B27B)        // màu chủ đạo
val Coral: Color get() = pick(0xFFD95761, 0xFFEC7A83)        // chi tiêu
val Charcoal: Color get() = pick(0xFF292530, 0xFFF1F2F4)     // chữ chính
val Muted: Color get() = pick(0xFF857E91, 0xFF9EA2AB)        // chữ phụ
val FreshSoft: Color get() = pick(0xFFE3F4EB, 0xFF1E3A2F)
val CoralSoft: Color get() = pick(0xFFFBE9EB, 0xFF3E2629)
val Amber: Color get() = pick(0xFFE8A04A, 0xFFF2B35E)
val Blue: Color get() = pick(0xFF3F7FD6, 0xFF6BA6EA)           // chuyển ví
val BlueSoft: Color get() = pick(0xFFE4EEFB, 0xFF1F3048)
val UserBubble: Color get() = pick(0xFFDDD3F5, 0xFF3C3F46)
/** Chữ/biểu tượng đặt trên nền màu chủ đạo: luôn trắng. */
val OnAccent = Color.White

private fun appColors() = if (isDark) darkColorScheme(
    primary = Fresh, onPrimary = OnAccent, primaryContainer = FreshSoft, onPrimaryContainer = Charcoal,
    secondary = Fresh, onSecondary = OnAccent, secondaryContainer = Lilac, onSecondaryContainer = Charcoal,
    tertiary = Color(0xFFA48BE8),
    background = Lavender, onBackground = Charcoal,
    surface = Paper, onSurface = Charcoal, surfaceVariant = Lilac, onSurfaceVariant = Muted,
    surfaceTint = Paper,
    outline = Color(0xFF4A4D55), outlineVariant = Color(0xFF3A3C42),
    error = Coral, onError = OnAccent,
    surfaceContainerLowest = Paper, surfaceContainerLow = Lavender, surfaceContainer = Lilac,
    surfaceContainerHigh = Paper, surfaceContainerHighest = Lilac
) else lightColorScheme(
    primary = Fresh, onPrimary = OnAccent, primaryContainer = FreshSoft, onPrimaryContainer = Charcoal,
    secondary = Fresh, onSecondary = OnAccent, secondaryContainer = Lilac, onSecondaryContainer = Charcoal,
    tertiary = Color(0xFF8E6BDB),
    background = Lavender, onBackground = Charcoal,
    surface = Paper, onSurface = Charcoal, surfaceVariant = Lilac, onSurfaceVariant = Muted,
    surfaceTint = Paper,
    outline = Color(0xFFCFC6DA), outlineVariant = Color(0xFFE6DFEE),
    error = Coral, onError = OnAccent,
    surfaceContainerLowest = Paper, surfaceContainerLow = Lavender, surfaceContainer = Lilac,
    surfaceContainerHigh = Paper, surfaceContainerHighest = Lilac
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(14.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = appColors(), shapes = AppShapes, content = content)
}

// ===== Màu + biểu tượng theo mục =====
fun catColor(c: String): Color = when (c) {
    "Ăn uống" -> Color(0xFFF2994A)
    "Di chuyển" -> Color(0xFF8E6BDB)
    "Mua sắm" -> Color(0xFF4C8DDB)
    "Hóa đơn" -> Color(0xFF26A69A)
    "Giải trí" -> Color(0xFFE867A0)
    "Sức khỏe" -> Color(0xFFE5645F)
    "Giáo dục" -> Color(0xFF5C6BC0)
    "Nhà cửa" -> Color(0xFF3F8FE0)
    "Du lịch" -> Color(0xFF29B6D6)
    "Quà tặng" -> Color(0xFFE5575F)
    "Lương", "Thu nhập khác", "Cho vay", "Thu nợ" -> Fresh
    "Vay nợ", "Trả nợ" -> Coral
    "Chuyển ví" -> Color(0xFF4C8DDB)
    else -> Color(0xFF9E98A8)
}

fun catEmoji(c: String): String = when (c) {
    "Ăn uống" -> "🍴"
    "Di chuyển" -> "🚗"
    "Mua sắm" -> "🛍️"
    "Hóa đơn" -> "🧾"
    "Giải trí" -> "🎬"
    "Sức khỏe" -> "💊"
    "Giáo dục" -> "📚"
    "Nhà cửa" -> "🏠"
    "Du lịch" -> "✈️"
    "Quà tặng" -> "🎁"
    "Lương" -> "💰"
    "Thu nhập khác" -> "💵"
    "Chuyển ví" -> "🔁"
    "Cho vay" -> "🤝"
    "Vay nợ" -> "🏦"
    "Thu nợ", "Trả nợ" -> "💸"
    else -> "⭐"
}

/** 1.500.000 -> "1,5tr"; 45.000 -> "45k" (dùng cho nhãn trục biểu đồ). */
fun Long.shortVnd(): String = when {
    this >= 1_000_000L -> {
        val v = this / 1_000_000.0
        (if (v == Math.floor(v)) v.toLong().toString() else String.format(Locale.US, "%.1f", v)) + "tr"
    }
    this >= 1_000L -> (this / 1000).toString() + "k"
    else -> toString()
}

// ===== Thành phần dùng chung =====
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    color: Color = Paper,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    val m = if (onClick != null) modifier.clip(shape).clickable(onClick = onClick) else modifier
    Card(m, shape = shape, colors = CardDefaults.cardColors(containerColor = color), content = content)
}

@Composable
fun IconBubble(emoji: String, color: Color, size: Dp = 44.dp) {
    Box(Modifier.size(size).background(color.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
        Text(emoji, fontSize = (size.value * 0.46f).sp)
    }
}

@Composable
fun Bar(progress: Float, color: Color, modifier: Modifier = Modifier, height: Dp = 8.dp, track: Color = Lilac) {
    Box(modifier.fillMaxWidth().height(height).clip(CircleShape).background(track)) {
        Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(color))
    }
}

@Composable
fun Pill(text: String, color: Color, bg: Color = color.copy(alpha = 0.14f), modifier: Modifier = Modifier) {
    Text(
        text, modifier.background(bg, CircleShape).padding(horizontal = 12.dp, vertical = 5.dp),
        color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun PillTabs(
    options: List<String>, selected: Int, modifier: Modifier = Modifier,
    inactive: Color = Paper, onPick: (Int) -> Unit
) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            Text(
                o,
                Modifier.clip(CircleShape).background(if (on) Fresh else inactive).clickable { onPick(i) }
                    .padding(horizontal = 18.dp, vertical = 9.dp),
                color = if (on) OnAccent else Charcoal, fontSize = 14.sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1
            )
        }
    }
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(start = if (onBack != null) 4.dp else 20.dp, end = 20.dp, top = 14.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại") }
            Spacer(Modifier.width(4.dp))
        }
        Text(title, Modifier.weight(1f), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        trailing()
    }
}

@Composable
fun RoundBtn(onClick: () -> Unit, bg: Color = Fresh, size: Dp = 44.dp, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(bg).clickable(onClick = onClick), contentAlignment = Alignment.Center, content = content)
}

@Composable
fun TipCard(text: String, emoji: String = "🤖") {
    AppCard(Modifier.fillMaxWidth(), color = Lilac) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).background(Paper, CircleShape), contentAlignment = Alignment.Center) { Text(emoji, fontSize = 26.sp) }
            Spacer(Modifier.width(12.dp))
            Text(text, Modifier.weight(1f), fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
fun SumCard(label: String, value: String, color: Color, bg: Color, modifier: Modifier = Modifier) {
    Column(modifier.background(bg, RoundedCornerShape(18.dp)).padding(14.dp)) {
        Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.width(92.dp), color = Muted, fontSize = 14.sp)
        Text(
            value.ifBlank { "—" }, Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = 14.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

@Composable
fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 12.sp, color = Muted)
    }
}

// ===== Biểu đồ =====
@Composable
fun Donut(
    parts: List<Pair<Float, Color>>, modifier: Modifier = Modifier, stroke: Dp = 22.dp,
    content: @Composable BoxScope.() -> Unit = {}
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(stroke / 2)) {
            val total = parts.sumOf { it.first.toDouble() }.toFloat()
            val sw = stroke.toPx()
            if (total <= 0f) {
                drawArc(Lilac, 0f, 360f, false, style = Stroke(sw))
            } else {
                var start = -90f
                parts.forEach { (v, c) ->
                    val sweep = v / total * 360f
                    drawArc(c, start, (sweep - 2f).coerceAtLeast(0.5f), false, style = Stroke(sw))
                    start += sweep
                }
            }
        }
        content()
    }
}

@Composable
fun LineChart(a: List<Float>, b: List<Float>, ca: Color, cb: Color, maxV: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = a.size
        if (n < 2) return@Canvas
        val w = size.width
        val h = size.height
        for (i in 0..2) {
            val y = 3f + (h - 6f) * i / 2f
            drawLine(Lilac, Offset(0f, y), Offset(w, y), 2f)
        }
        fun yOf(x: Float) = h - (x / maxV).coerceIn(0f, 1f) * (h - 6f) - 3f
        fun curve(v: List<Float>): Path {
            val p = Path()
            v.forEachIndexed { i, x ->
                val px = w * i / (n - 1)
                val py = yOf(x)
                if (i == 0) p.moveTo(px, py) else {
                    val ppx = w * (i - 1) / (n - 1)
                    val ppy = yOf(v[i - 1])
                    val mx = (ppx + px) / 2f
                    p.cubicTo(mx, ppy, mx, py, px, py)
                }
            }
            return p
        }
        val fa = curve(a)
        fa.lineTo(w, h); fa.lineTo(0f, h); fa.close()
        drawPath(fa, ca.copy(alpha = 0.10f))
        val fb = curve(b)
        fb.lineTo(w, h); fb.lineTo(0f, h); fb.close()
        drawPath(fb, cb.copy(alpha = 0.10f))
        drawPath(curve(a), ca, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(curve(b), cb, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun Sparkline(v: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (v.size < 2) return@Canvas
        val mn = v.min()
        val mx = v.max()
        val rng = if (mx - mn > 0f) mx - mn else 1f
        val w = size.width
        val h = size.height
        val line = Path()
        val fill = Path()
        v.forEachIndexed { i, x ->
            val px = w * i / (v.size - 1)
            val py = h - ((x - mn) / rng) * (h * 0.8f) - h * 0.1f
            if (i == 0) { line.moveTo(px, py); fill.moveTo(px, h); fill.lineTo(px, py) } else { line.lineTo(px, py); fill.lineTo(px, py) }
        }
        fill.lineTo(w, h); fill.close()
        drawPath(fill, color.copy(alpha = 0.15f))
        drawPath(line, color, style = Stroke(4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun MicIcon(color: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.09f
        drawRoundRect(color, Offset(w * 0.36f, h * 0.06f), Size(w * 0.28f, h * 0.52f), CornerRadius(w * 0.14f))
        drawArc(color, 0f, 180f, false, Offset(w * 0.22f, h * 0.22f), Size(w * 0.56f, h * 0.46f), style = Stroke(sw, cap = StrokeCap.Round))
        drawLine(color, Offset(w * 0.5f, h * 0.68f), Offset(w * 0.5f, h * 0.88f), sw, StrokeCap.Round)
        drawLine(color, Offset(w * 0.34f, h * 0.9f), Offset(w * 0.66f, h * 0.9f), sw, StrokeCap.Round)
    }
}
