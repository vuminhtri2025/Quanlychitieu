package com.chitieu.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2E9E5B))) { App() }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("💬" to "Chat", "📒" to "Sổ GD", "📊" to "Thống kê", "🎯" to "Ngân sách", "⚙️" to "Cài đặt")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Text(t.first) }, label = { Text(t.second) })
            }
        }
    }) { pad ->
        Surface(Modifier.padding(pad)) {
            when (tab) {
                0 -> ChatScreen()
                1 -> HistoryScreen()
                2 -> StatsScreen()
                3 -> BudgetScreen()
                else -> SettingsScreen()
            }
        }
    }
}
