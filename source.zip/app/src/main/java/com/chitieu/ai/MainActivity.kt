package com.chitieu.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2E9E5B))) { App() }
        }
    }
}

@Composable
fun App() {
    val tabs = listOf("💬" to "Chat", "📒" to "Sổ GD", "📊" to "Thống kê", "🎯" to "Ngân sách", "⚙️" to "Cài đặt")
    val pager = rememberPagerState { tabs.size }
    val scope = rememberCoroutineScope()
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(selected = pager.currentPage == i,
                    onClick = { scope.launch { pager.animateScrollToPage(i) } },
                    icon = { Text(t.first) },
                    label = { Text(t.second, fontSize = 11.sp, maxLines = 1, softWrap = false) })
            }
        }
    }) { pad ->
        HorizontalPager(state = pager, modifier = Modifier.padding(pad), beyondViewportPageCount = tabs.size) { page ->
            Surface(Modifier.fillMaxSize()) {
                when (page) {
                    0 -> ChatScreen()
                    1 -> HistoryScreen()
                    2 -> StatsScreen()
                    3 -> BudgetScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}
