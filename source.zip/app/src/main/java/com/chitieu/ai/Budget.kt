@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

@Composable
fun BudgetScreen(onBack: (() -> Unit)? = null) {
    var edit by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    val spent = txsOfMonth(0).filter { !it.income && Store.cur(it.walletId) == "VND" }
        .groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
    val budgeted = CATEGORIES.filter { it !in INCOME_CATS && (Store.budgets[it] ?: 0L) > 0L }
    val others = CATEGORIES.filter { it !in INCOME_CATS && it !in budgeted }
    val totalLim = budgeted.sumOf { Store.budgets[it] ?: 0L }
    val totalSpent = budgeted.sumOf { spent[it] ?: 0L }
    val pct = if (totalLim > 0L) (totalSpent * 100 / totalLim).toInt() else 0
    val statusColor = when { pct > 100 -> Coral; pct >= 90 -> Amber; else -> Fresh }
    val statusText = when { pct > 100 -> "Vượt ngân sách"; pct >= 90 -> "Sắp hết hạn mức"; else -> "Trong giới hạn" }
    val over = budgeted.filter { (spent[it] ?: 0L) > (Store.budgets[it] ?: 0L) }
    val month = monthStart(0).get(Calendar.MONTH) + 1

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Ngân sách", onBack) {
            RoundBtn(onClick = { adding = true }) { Icon(Icons.Default.Add, contentDescription = "Thêm ngân sách", tint = Color.White) }
        }
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎯  Ngân sách tháng $month", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        if (budgeted.isNotEmpty()) Pill(statusText, statusColor)
                    }
                    if (budgeted.isEmpty()) {
                        Text("Chưa có ngân sách nào. Bấm dấu + để đặt hạn mức cho một danh mục.", color = Muted, fontSize = 14.sp)
                    } else {
                        Text(totalSpent.vnd(), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text("Đã sử dụng trong hạn mức ${totalLim.vnd()}", color = Muted, fontSize = 13.sp)
                        Bar(if (totalLim > 0L) totalSpent.toFloat() / totalLim else 0f, statusColor, height = 12.dp)
                        Row {
                            Text("$pct% đã sử dụng", color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(
                                if (totalLim >= totalSpent) "${(totalLim - totalSpent).vnd()} còn lại" else "Vượt ${(totalSpent - totalLim).vnd()}",
                                color = statusColor, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                            )
                        }
                        HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Lilac)
                        budgeted.forEach { c ->
                            val lim = Store.budgets[c] ?: 0L
                            val s = spent[c] ?: 0L
                            val exceeded = s > lim
                            Column(
                                Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                                    .clickable { edit = c }.padding(vertical = 6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(catEmoji(c) + "  " + c, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                    Text("${s.vnd()} / ${lim.vnd()}", fontSize = 14.sp)
                                }
                                Bar(s.toFloat() / lim, if (exceeded) Coral else catColor(c))
                                Text(
                                    if (exceeded) "${s * 100 / lim}% hạn mức • vượt ${(s - lim).vnd()}" else "${s * 100 / lim}% hạn mức",
                                    color = if (exceeded) Coral else Muted, fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
            if (others.isNotEmpty()) {
                Text("Chưa đặt hạn mức (chạm để đặt)", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    others.forEach { c ->
                        val s = spent[c] ?: 0L
                        Text(
                            catEmoji(c) + " " + c + (if (s > 0L) " • ${s.vnd()}" else ""),
                            Modifier.clip(CircleShape).background(Paper).clickable { edit = c }.padding(horizontal = 14.dp, vertical = 9.dp),
                            fontSize = 14.sp, maxLines = 1
                        )
                    }
                }
            }
            TipCard(
                when {
                    over.isNotEmpty() -> "Bạn đã vượt hạn mức ở: ${over.joinToString()}. Cân nhắc giảm chi tiêu nhé!"
                    budgeted.isEmpty() -> "Đặt hạn mức cho vài danh mục để mình nhắc bạn khi chi tiêu gần chạm trần nhé!"
                    else -> "Bạn đang chi tiêu khá tốt! Cố gắng giữ dưới 80% ngân sách nhé."
                },
                "💡"
            )
        }
    }
    edit?.let { c -> BudgetDialog(c) { edit = null } }
    if (adding) BudgetDialog(null) { adding = false }
}

@Composable
fun BudgetDialog(cat: String?, onClose: () -> Unit) {
    val choices = CATEGORIES.filter { it !in INCOME_CATS }
    var c by remember { mutableStateOf(cat ?: choices.firstOrNull { (Store.budgets[it] ?: 0L) <= 0L } ?: choices.first()) }
    var txt by remember { mutableStateOf((Store.budgets[c] ?: 0L).let { if (it > 0L) it.toString() else "" }) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (cat == null) "Thêm ngân sách" else "Hạn mức: $cat") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (cat == null) Pick(c, choices) { c = it; txt = (Store.budgets[it] ?: 0L).let { v -> if (v > 0L) v.toString() else "" } }
                OutlinedTextField(
                    txt, { txt = it.filter(Char::isDigit) }, label = { Text("Số tiền (đ)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = txt.toLongOrNull() ?: 0L
                if (v > 0L) Store.budgets[c] = v else Store.budgets.remove(c)
                Store.save(); onClose()
            }) { Text("Lưu") }
        },
        dismissButton = {
            Row {
                if (cat != null && (Store.budgets[cat] ?: 0L) > 0L) {
                    TextButton(onClick = { Store.budgets.remove(cat); Store.save(); onClose() }) { Text("Xóa hạn mức", color = Coral) }
                }
                TextButton(onClick = onClose) { Text("Hủy") }
            }
        }
    )
}
