package com.chitieu.ai

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import android.net.Uri
import android.os.Bundle
import android.widget.RemoteViews
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Vẽ nền widget: bo góc, gradient theo màu ví và hai vòng sáng mờ trang trí. */
object WidgetArt {
    fun bitmap(ctx: Context, mgr: AppWidgetManager, widgetId: Int, base: Int): Bitmap {
        val o = try { mgr.getAppWidgetOptions(widgetId) } catch (_: Exception) { null }
        val wDp = (o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 72) ?: 72).coerceIn(40, 400)
        val hDp = (o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 72) ?: 72).coerceIn(40, 400)
        val d = ctx.resources.displayMetrics.density
        val w = (wDp * d).toInt().coerceAtLeast(64)
        val h = (hDp * d).toInt().coerceAtLeast(64)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val r = 22f * d
        c.clipPath(Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) })
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            ColorUtils.blendARGB(base, 0xFFFFFFFF.toInt(), 0.14f), ColorUtils.blendARGB(base, 0xFF000000.toInt(), 0.22f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(rect, p)
        p.shader = null
        val m = minOf(w, h).toFloat()
        p.color = 0x26FFFFFF
        c.drawCircle(w * 0.98f, h * 0.02f, m * 0.62f, p)
        p.color = 0x14FFFFFF
        c.drawCircle(w * 0.04f, h * 1.02f, m * 0.5f, p)
        return bmp
    }
}

/**
 * Widget 1x1: mỗi widget gắn với một ví. Bấm vào -> mở thẳng cuộc trò chuyện của ví đó và bắt đầu nghe giọng nói.
 */
class VoiceWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        update(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val e = prefs(context).edit()
        appWidgetIds.forEach { e.remove("w$it") }
        e.apply()
    }

    companion object {
        const val ACTION_VOICE = "com.chitieu.ai.action.VOICE"
        const val EXTRA_WALLET = "wallet_id"
        const val EXTRA_AUTO = "auto_wallet"   // widget "tự chọn ví": AI tự hiểu ví và loại tiền từ lời nói

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("widgets", Context.MODE_PRIVATE)

        fun setWallet(ctx: Context, widgetId: Int, walletId: Long) {
            prefs(ctx).edit().putLong("w$widgetId", walletId).apply()
        }

        fun update(ctx: Context, mgr: AppWidgetManager, widgetId: Int) {
            Store.init(ctx.applicationContext)
            val wid = prefs(ctx).getLong("w$widgetId", 0L)
            // ví đã xóa hoặc chưa chọn -> dùng ví đầu tiên
            val w = Store.wallets.firstOrNull { it.id == wid } ?: Store.wallets.firstOrNull()
            val views = RemoteViews(ctx.packageName, R.layout.widget_voice)
            views.setTextViewText(R.id.widget_name, w?.name ?: "Ví")
            views.setImageViewBitmap(R.id.widget_bg, WidgetArt.bitmap(ctx, mgr, widgetId, w?.let { Store.walletColorInt(it.id) } ?: 0xFF299B69.toInt()))
            val intent = Intent(ctx, VoiceQuickActivity::class.java)
                .setAction(ACTION_VOICE)
                .setData(Uri.parse("chitieu://voice/$widgetId"))   // mỗi widget một PendingIntent riêng
                .putExtra(EXTRA_WALLET, w?.id ?: 0L)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = PendingIntent.getActivity(ctx, widgetId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            mgr.updateAppWidget(widgetId, views)
        }

        /** Cập nhật tên ví hiển thị trên mọi widget (gọi khi app xuống nền). */
        fun refreshAll(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, VoiceWidget::class.java))
                ids.forEach { update(ctx, mgr, it) }
                mgr.getAppWidgetIds(ComponentName(ctx, VoiceAutoWidget::class.java)).forEach { VoiceAutoWidget.update(ctx, mgr, it) }
            } catch (_: Exception) {}
        }
    }
}

/**
 * Widget "ra lệnh tự chọn ví": không gắn ví nào. Bấm vào là nghe giọng nói; người dùng nói kèm tên ví hoặc loại tiền
 * (vd "ăn trưa 120 nghìn ví Techcombank", "mua cơm 1500 yên") và AI tự hiểu ghi vào ví nào, tiền gì.
 */
class VoiceAutoWidget : AppWidgetProvider() {
    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        update(context, appWidgetManager, appWidgetId)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, appWidgetManager, id)
    }

    companion object {
        fun update(ctx: Context, mgr: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(ctx.packageName, R.layout.widget_voice)
            views.setTextViewText(R.id.widget_name, "Tự chọn ví")
            views.setImageViewBitmap(R.id.widget_bg, WidgetArt.bitmap(ctx, mgr, widgetId, 0xFF3F8FE0.toInt()))
            val intent = Intent(ctx, VoiceQuickActivity::class.java)
                .setAction(VoiceWidget.ACTION_VOICE)
                .setData(Uri.parse("chitieu://voice/auto/$widgetId"))
                .putExtra(VoiceWidget.EXTRA_AUTO, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = PendingIntent.getActivity(ctx, 100000 + widgetId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            mgr.updateAppWidget(widgetId, views)
        }
    }
}

/** Màn chọn ví hiện ra khi thêm widget vào màn hình chính. */
class VoiceWidgetConfig : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)   // thoát giữa chừng thì widget không được thêm
        val widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        Store.init(this)
        Store.systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        setContent {
            AppTheme {
                Column(
                    Modifier.fillMaxSize().background(Lavender).statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Chọn ví cho widget", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Bấm widget là hiện khung nghe giọng nói ngay trên màn hình chính, ghi vào ví này.", color = Muted, fontSize = 13.sp)
                    if (Store.wallets.isEmpty()) Text("Chưa có ví nào. Hãy mở app và tạo ví trước.", color = Coral)
                    Store.wallets.forEach { w ->
                        AppCard(Modifier.fillMaxWidth(), onClick = {
                            VoiceWidget.setWallet(this@VoiceWidgetConfig, widgetId, w.id)
                            VoiceWidget.update(this@VoiceWidgetConfig, AppWidgetManager.getInstance(this@VoiceWidgetConfig), widgetId)
                            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                            finish()
                        }) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("👛", fontSize = 22.sp)
                                Column(Modifier.weight(1f)) {
                                    Text(w.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
                                    Text(w.currency, color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Trang hướng dẫn + nút thêm widget trong Tài khoản. */
@Composable
fun WidgetSettings() {
    val ctx = LocalContext.current
    Section("Widget ra lệnh tự chọn ví") {
        Text(
            "Một widget cho mọi ví: bấm vào là khung nghe giọng nói hiện ngay trên màn hình chính (không phải mở app). Bạn nói kèm tên ví hoặc loại tiền, AI tự hiểu ghi vào ví nào và dùng tiền gì. " +
                "Ví dụ: \"ăn trưa 120 nghìn ví Techcombank\", \"mua cơm 1500 yên\", \"cà phê 50k tiền mặt\".",
            style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = {
            val mgr = AppWidgetManager.getInstance(ctx)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(ctx, VoiceAutoWidget::class.java), null, null)
            } else {
                Toast.makeText(ctx, "Nhấn giữ màn hình chính → Widget → \"Ra lệnh giọng nói (tự chọn ví)\"", Toast.LENGTH_LONG).show()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("➕ Thêm widget tự chọn ví") }
        Text(
            "Không nói tên ví thì AI chọn theo loại tiền bạn nói, rồi theo thói quen. Thẻ kết quả luôn hiện rõ ví đã chọn; " +
                "nếu nói tiền khác loại ví và chưa có tỉ giá, giao dịch sẽ chờ bạn xác nhận.",
            style = MaterialTheme.typography.bodySmall
        )
    }
    Section("Widget giọng nói 1x1 (gắn một ví)") {
        Text(
            "Mỗi widget gắn với một ví. Bấm vào widget là khung nghe giọng nói hiện ngay trên màn hình chính (không phải mở app), bạn nói xong là ghi vào ví đó. " +
                "Muốn nhiều ví thì thêm nhiều widget.",
            style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = {
            val mgr = AppWidgetManager.getInstance(ctx)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(ctx, VoiceWidget::class.java), null, null)
            } else {
                Toast.makeText(ctx, "Nhấn giữ màn hình chính → Widget → \"Giọng nói theo ví\"", Toast.LENGTH_LONG).show()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("➕ Thêm widget vào màn hình chính") }
        Text(
            "Nếu nút không hiện hộp thoại, hãy nhấn giữ màn hình chính → Widget → \"Giọng nói theo ví\" (Chi Tiêu AI) rồi kéo ra, chọn ví. " +
                "Đổi chế độ nhận giọng nói ở Tài khoản → Giọng nói.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
