package com.chitieu.ai

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.widget.RemoteViews
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Widget 1x1: mỗi widget gắn với một ví. Bấm vào -> mở thẳng cuộc trò chuyện của ví đó và bắt đầu nghe giọng nói.
 */
class VoiceWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, appWidgetManager, id)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val e = prefs(context).edit()
        appWidgetIds.forEach { e.remove("w$it") }
        e.apply()
    }

    companion object {
        const val ACTION_VOICE = "com.chitieu.ai.action.VOICE"
        const val EXTRA_WALLET = "wallet_id"

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("widgets", Context.MODE_PRIVATE)

        fun setWallet(ctx: Context, widgetId: Int, walletId: Long) {
            prefs(ctx).edit().putLong("w$widgetId", walletId).apply()
        }

        fun update(ctx: Context, mgr: AppWidgetManager, widgetId: Int) {
            Store.init(ctx.applicationContext)
            val wid = prefs(ctx).getLong("w$widgetId", 0L)
            // ví đã xóa hoặc chưa chọn -> dùng ví đầu tiên
            val w = Store.wallets.firstOrNull { it.id == wid } ?: Store.wallets.firstOrNull()
            val views = RemoteViews(ctx.packageName, R.layout.widget_voice)
            views.setTextViewText(R.id.widget_name, w?.name ?: "Ví")
            val intent = Intent(ctx, MainActivity::class.java)
                .setAction(ACTION_VOICE)
                .setData(Uri.parse("chitieu://voice/$widgetId"))   // mỗi widget một PendingIntent riêng
                .putExtra(EXTRA_WALLET, w?.id ?: 0L)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = PendingIntent.getActivity(ctx, widgetId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            mgr.updateAppWidget(widgetId, views)
        }

        /** Cập nhật tên ví hiển thị trên mọi widget (gọi khi app xuống nền). */
        fun refreshAll(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, VoiceWidget::class.java))
                ids.forEach { update(ctx, mgr, it) }
            } catch (_: Exception) {}
        }
    }
}

/** Màn chọn ví hiện ra khi thêm widget vào màn hình chính. */
class VoiceWidgetConfig : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)   // thoát giữa chừng thì widget không được thêm
        val widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        Store.init(this)
        Store.systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        setContent {
            AppTheme {
                Column(
                    Modifier.fillMaxSize().background(Lavender).statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Chọn ví cho widget", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Bấm widget sẽ mở chat của ví này và nghe giọng nói ngay.", color = Muted, fontSize = 13.sp)
                    if (Store.wallets.isEmpty()) Text("Chưa có ví nào. Hãy mở app và tạo ví trước.", color = Coral)
                    Store.wallets.forEach { w ->
                        AppCard(Modifier.fillMaxWidth(), onClick = {
                            VoiceWidget.setWallet(this@VoiceWidgetConfig, widgetId, w.id)
                            VoiceWidget.update(this@VoiceWidgetConfig, AppWidgetManager.getInstance(this@VoiceWidgetConfig), widgetId)
                            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                            finish()
                        }) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("👛", fontSize = 22.sp)
                                Column(Modifier.weight(1f)) {
                                    Text(w.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
                                    Text(w.currency, color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Trang hướng dẫn + nút thêm widget trong Tài khoản. */
@Composable
fun WidgetSettings() {
    val ctx = LocalContext.current
    Section("Widget giọng nói 1x1") {
        Text(
            "Mỗi widget gắn với một ví. Bấm vào widget, app mở thẳng chat của ví đó và bắt đầu nghe bạn nói để ghi giao dịch. " +
                "Muốn nhiều ví thì thêm nhiều widget.",
            style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = {
            val mgr = AppWidgetManager.getInstance(ctx)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(ctx, VoiceWidget::class.java), null, null)
            } else {
                Toast.makeText(ctx, "Nhấn giữ màn hình chính → Widget → \"Giọng nói theo ví\"", Toast.LENGTH_LONG).show()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("➕ Thêm widget vào màn hình chính") }
        Text(
            "Nếu nút không hiện hộp thoại, hãy nhấn giữ màn hình chính → Widget → \"Giọng nói theo ví\" (Chi Tiêu AI) rồi kéo ra, chọn ví. " +
                "Đổi chế độ nhận giọng nói ở Tài khoản → Giọng nói.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
