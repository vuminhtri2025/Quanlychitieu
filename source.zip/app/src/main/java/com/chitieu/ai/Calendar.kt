@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Mốc thời gian của ngày [dayStart] (00:00) nhưng giữ giờ:phút hiện tại — dùng làm giờ mặc định khi thêm giao dịch. */
fun timeOnDay(dayStart: Long): Long {
    val now = Calendar.getInstance()
    return Calendar.getInstance().apply {
        timeInMillis = dayStart
        set(Calendar.HOUR_OF_DAY, now.get(Calendar.HOUR_OF_DAY))
        set(Calendar.MINUTE, now.get(Calendar.MINUTE))
    }.timeInMillis
}

@Composable
private fun DayCell(d: Int, exp: Long, inc: Long, isToday: Boolean, isSel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(52.dp).padding(1.dp).clip(RoundedCornerShape(12.dp))
            .background(if (isSel) FreshSoft else Color.Transparent)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(26.dp).then(if (isToday) Modifier.background(Fresh, CircleShape) else Modifier),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "$d", fontSize = 14.sp, color = if (isToday) OnAccent else Charcoal,
                fontWeight = if (isToday || isSel) FontWeight.Bold else FontWeight.Normal
            )
        }
        when {
            exp > 0L -> Text(exp.shortVnd(), fontSize = 9.sp, color = Coral, maxLines = 1)
            inc > 0L -> Text("+" + inc.shortVnd(), fontSize = 9.sp, color = Fresh, maxLines = 1)
            else -> Spacer(Modifier.height(11.dp))
        }
    }
}

/** Lịch tháng: mỗi ngày hiện tổng chi (đỏ) hoặc tổng thu (xanh); chạm vào ngày để xem / thêm giao dịch. */
@Composable
fun MonthCalendar(off: Int, exp: LongArray, inc: LongArray, selected: Int, onDay: (Int) -> Unit) {
    val first = monthStart(off)
    val days = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val lead = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7        // thứ Hai là cột đầu
    val rows = (lead + days + 6) / 7
    val today = Calendar.getInstance()
    val todayD = if (today.get(Calendar.YEAR) == first.get(Calendar.YEAR) && today.get(Calendar.MONTH) == first.get(Calendar.MONTH))
        today.get(Calendar.DAY_OF_MONTH) else -1
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(Modifier.fillMaxWidth()) {
                listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN").forEach {
                    Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val d = r * 7 + c - lead + 1
                        if (d < 1 || d > days) Spacer(Modifier.weight(1f).height(52.dp))
                        else DayCell(d, exp[d], inc[d], d == todayD, d == selected, Modifier.weight(1f)) { onDay(d) }
                    }
                }
            }
            Text(
                "Chạm vào một ngày để xem và thêm giao dịch", color = Muted, fontSize = 12.sp,
                modifier = Modifier.padding(start = 4.dp, top = 4.dp)
            )
        }
    }
}

/** Hộp thoại của một ngày: danh sách giao dịch trong ngày + nút thêm giao dịch. */
@Composable
fun DayDialog(dayStart: Long, list: List<Tx>, signed: Boolean, onAdd: () -> Unit, onEdit: (Tx) -> Unit, onClose: () -> Unit) {
    val title = remember(dayStart) { SimpleDateFormat("EEEE, dd/MM/yyyy", Locale("vi")).format(Date(dayStart)) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title.replaceFirstChar { it.uppercase() }, fontSize = 18.sp) },
        text = {
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (list.isEmpty()) Text("Chưa có giao dịch nào trong ngày này.", color = Muted)
                list.forEach { t -> TxRow(t, signed) { onEdit(t) } }
            }
        },
        confirmButton = { Button(onClick = onAdd) { Text("＋ Thêm giao dịch") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Đóng") } }
    )
}

/** Thêm giao dịch thu/chi thủ công (không qua chat) với giờ mặc định [time]. */
@Composable
fun AddTxDialog(time: Long, defaultWallet: Long, onClose: () -> Unit) {
    val defExpense = CATEGORIES.first { it !in INCOME_CATS }
    var amount by remember { mutableStateOf("") }
    var income by remember { mutableStateOf(false) }
    var wid by remember { mutableLongStateOf(defaultWallet) }
    var cat by remember { mutableStateOf(defExpense) }
    var note by remember { mutableStateOf("") }
    var t by remember { mutableLongStateOf(time) }
    var report by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Thêm giao dịch") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    amount, { amount = it.filter(Char::isDigit); err = "" }, label = { Text("Số tiền") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false; cat = defExpense }, label = { Text("Chi") })
                    FilterChip(selected = income, onClick = { income = true; cat = INCOME_CATS.first() }, label = { Text("Thu") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pick(Store.walletName(wid), Store.wallets.map { it.name }) { n -> Store.wallets.firstOrNull { it.name == n }?.let { wid = it.id } }
                    Pick(cat, if (income) INCOME_CATS.toList() else CATEGORIES.filter { it !in INCOME_CATS }) { cat = it }
                }
                DateTimeRow(t) { t = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                ReportSwitch(report) { report = it }
                if (err.isNotEmpty()) Text(err, color = Coral, fontSize = 13.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.toLongOrNull() ?: 0L
                if (a <= 0L) err = "Nhập số tiền lớn hơn 0"
                else { Store.add(Tx(System.nanoTime(), a, income, wid, cat, note.trim(), t, 0L, 0L, report)); onClose() }
            }) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } }
    )
}
