package com.chitieu.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

val CATEGORIES = listOf("Ăn uống", "Di chuyển", "Mua sắm", "Hóa đơn", "Giải trí", "Sức khỏe",
    "Giáo dục", "Nhà cửa", "Du lịch", "Quà tặng", "Lương", "Thu nhập khác", "Khác")
val INCOME_CATS = setOf("Lương", "Thu nhập khác")

val PERSONAS = linkedMapOf(
    "Thân thiện" to "ấm áp, gần gũi, hay động viên, dùng emoji vừa phải",
    "Mỉa mai" to "mỉa mai, châm biếm duyên dáng khi người dùng tiêu tiền hoang phí, nhưng vẫn ghi chép chính xác",
    "Nghiêm khắc" to "như người mẹ nghiêm khắc, hay nhắc nhở tiết kiệm, càu nhàu nhẹ nhưng thương con",
    "Hài hước" to "vui nhộn, pha trò, chơi chữ, ví von hài hước",
    "Chuyên gia" to "chuyên nghiệp, ngắn gọn, đưa nhận xét tài chính thực tế",
    "Dễ thương" to "đáng yêu, nũng nịu, xưng em gọi anh/chị, nhiều emoji cute"
)

data class Tx(val id: Long, val amount: Long, val income: Boolean, val wallet: String,
              val category: String, val note: String, val time: Long)

class Pending(amount: Long, income: Boolean, wallet: String, category: String, note: String, time: Long) {
    var amount by mutableLongStateOf(amount)
    var income by mutableStateOf(income)
    var wallet by mutableStateOf(wallet)
    var category by mutableStateOf(category)
    var note by mutableStateOf(note)
    var time by mutableLongStateOf(time)
    var saved by mutableStateOf(false)
    var dismissed by mutableStateOf(false)
}

class Msg(val fromUser: Boolean, val text: String, val pending: List<Pending> = emptyList())

fun Long.vnd(): String = String.format(Locale.US, "%,d", this).replace(',', '.') + "đ"

fun monthStart(off: Int): Calendar = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, off)
}

fun txsOfMonth(off: Int): List<Tx> {
    val s = monthStart(off)
    val e = (s.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
    return Store.txs.filter { it.time >= s.timeInMillis && it.time < e.timeInMillis }
}

object Store {
    private lateinit var sp: SharedPreferences
    val txs = mutableStateListOf<Tx>()
    val wallets = mutableStateListOf<String>()
    val budgets = mutableStateMapOf<String, Long>()
    val chat = mutableStateListOf<Msg>()
    var apiKey by mutableStateOf("")
    var aiName by mutableStateOf("Mimi")
    var persona by mutableStateOf("Thân thiện")
    var model by mutableStateOf("gemini-2.5-flash")

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("chitieu", Context.MODE_PRIVATE)
        apiKey = sp.getString("key", "") ?: ""
        aiName = sp.getString("name", "Mimi") ?: "Mimi"
        persona = sp.getString("persona", "Thân thiện") ?: "Thân thiện"
        model = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        val a = JSONArray(sp.getString("txs", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            txs.add(Tx(o.getLong("id"), o.getLong("amount"), o.getBoolean("income"), o.getString("wallet"),
                o.getString("category"), o.getString("note"), o.getLong("time")))
        }
        val w = JSONArray(sp.getString("wallets", "[\"Tiền mặt\",\"Ngân hàng\",\"Ví MoMo\"]"))
        for (i in 0 until w.length()) wallets.add(w.getString(i))
        val b = JSONObject(sp.getString("budgets", "{}"))
        for (k in b.keys()) budgets[k] = b.getLong(k)
        chat.add(Msg(false, "Chào bạn! Mình là $aiName 👋 Cứ nhắn hoặc nói khoản chi tiêu, ví dụ: \"sáng nay 8 giờ ăn phở 50k bằng tiền mặt\", mình sẽ ghi lại giúp."))
    }

    fun add(t: Tx) { txs.add(t); save() }

    fun save() {
        val a = JSONArray()
        txs.forEach { a.put(JSONObject().put("id", it.id).put("amount", it.amount).put("income", it.income)
            .put("wallet", it.wallet).put("category", it.category).put("note", it.note).put("time", it.time)) }
        val b = JSONObject(); budgets.forEach { (k, v) -> b.put(k, v) }
        sp.edit().putString("txs", a.toString()).putString("wallets", JSONArray(wallets.toList()).toString())
            .putString("budgets", b.toString()).putString("key", apiKey).putString("name", aiName)
            .putString("persona", persona).putString("model", model).apply()
    }
}
