package com.chitieu.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val CATEGORIES = listOf("Ăn uống", "Di chuyển", "Mua sắm", "Hóa đơn", "Giải trí", "Sức khỏe",
    "Giáo dục", "Nhà cửa", "Du lịch", "Quà tặng", "Lương", "Thu nhập khác", "Khác")
val INCOME_CATS = setOf("Lương", "Thu nhập khác")
val CURRENCIES = linkedMapOf("VND" to "đ", "USD" to "\$", "EUR" to "€", "JPY" to "¥", "KRW" to "₩", "GBP" to "£", "THB" to "฿")

val PERSONAS = linkedMapOf(
    "Thân thiện" to "ấm áp, gần gũi, hay động viên, dùng emoji vừa phải",
    "Mỉa mai" to "mỉa mai, châm biếm duyên dáng khi người dùng tiêu tiền hoang phí, nhưng vẫn ghi chép chính xác",
    "Nghiêm khắc" to "như người mẹ nghiêm khắc, hay nhắc nhở tiết kiệm, càu nhàu nhẹ nhưng thương con",
    "Hài hước" to "vui nhộn, pha trò, chơi chữ, ví von hài hước",
    "Chuyên gia" to "chuyên nghiệp, ngắn gọn, đưa nhận xét tài chính thực tế",
    "Dễ thương" to "đáng yêu, nũng nịu, xưng em gọi anh/chị, nhiều emoji cute"
)

data class Wallet(val id: Long, val name: String, val currency: String)

/** Bảng màu cho ví: mỗi ví một màu riêng (dùng cho ảnh đại diện trong app và widget). */
val WALLET_PALETTE = intArrayOf(
    0xFF299B69.toInt(), 0xFF4C8DDB.toInt(), 0xFFF2994A.toInt(), 0xFF8E6BDB.toInt(), 0xFFE867A0.toInt(),
    0xFF26A69A.toInt(), 0xFFE5645F.toInt(), 0xFFD4A72C.toInt(), 0xFF607D8B.toInt(), 0xFF29B6F6.toInt()
)

/** Cuộc trò chuyện tổng: không gắn ví nào, AI tự chọn ví theo nội dung câu lệnh. */
const val TOTAL_ID = -1L
val TOTAL_WALLET = Wallet(TOTAL_ID, "Trò chuyện tổng", "VND")

data class Tx(val id: Long, val amount: Long, val income: Boolean, val walletId: Long,
              val category: String, val note: String, val time: Long, val debtId: Long = 0L,
              val transferId: Long = 0L, val report: Boolean = true, val photo: String = "")  // report=false: không tính vào báo cáo tổng

// Khoản vay/nợ. lend=false: mình đi vay (mình nợ); lend=true: mình cho vay (người khác nợ mình)
data class Debt(val id: Long, val person: String, val lend: Boolean, val principal: Long, val cur: String,
                val time: Long, val due: Long, val note: String)

class Pending(amount: Long, income: Boolean, walletId: Long, category: String, note: String, time: Long,
              kind: String = "tx", person: String = "", due: Long = 0L,
              toWalletId: Long = 0L, report: Boolean = true) {
    var kind by mutableStateOf(kind)   // tx | borrow | lend | repay | collect
    var person by mutableStateOf(person)
    var due by mutableLongStateOf(due)
    var error by mutableStateOf("")
    var toWalletId by mutableLongStateOf(toWalletId)
    var report by mutableStateOf(report)
    var conf by mutableFloatStateOf(0f)      // độ tin cậy tính từ lịch sử
    var why by mutableStateOf("")
    var auto = false                          // đủ tự tin để tự lưu
    var autoSaved by mutableStateOf(false)
    var txId by mutableLongStateOf(0L)
    var amount by mutableLongStateOf(amount)
    var income by mutableStateOf(income)
    var walletId by mutableLongStateOf(walletId)
    var category by mutableStateOf(category)
    var note by mutableStateOf(note)
    var time by mutableLongStateOf(time)
    var saved by mutableStateOf(false)
    var dismissed by mutableStateOf(false)
}

val KIND_LABELS = listOf("Chi tiêu", "Thu nhập", "Chuyển ví", "Vay", "Cho vay", "Trả nợ", "Thu nợ")
fun Pending.label() = when (kind) {
    "borrow" -> "Vay"; "lend" -> "Cho vay"; "repay" -> "Trả nợ"; "collect" -> "Thu nợ"; "transfer" -> "Chuyển ví"
    else -> if (income) "Thu nhập" else "Chi tiêu"
}
fun Pending.isIncome() = when (kind) { "borrow", "collect" -> true; "lend", "repay" -> false; else -> income }
fun Pending.setLabel(l: String) {
    if (l == "Chuyển ví") report = false else if (kind == "transfer") report = true
    when (l) {
        "Chi tiêu" -> { kind = "tx"; income = false }
        "Thu nhập" -> { kind = "tx"; income = true }
        "Chuyển ví" -> {
            kind = "transfer"
            if (!Store.canTransfer(walletId, toWalletId)) toWalletId = Store.defaultTo(walletId)
        }
        "Vay" -> kind = "borrow"
        "Cho vay" -> kind = "lend"
        "Trả nợ" -> kind = "repay"
        else -> kind = "collect"
    }
}

/** Model mặc định. Google đang giới hạn công suất dòng 2.5 (hay báo 503), nên dùng dòng mới làm mặc định. */
const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
/** Các model dự phòng, thử lần lượt khi model chính quá tải hoặc không dùng được. */
val FALLBACK_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-2.5-flash-lite")

class Msg(val fromUser: Boolean, text: String, val pending: List<Pending> = emptyList()) {
    var text by mutableStateOf(text)
    var typing by mutableStateOf(false)
    var retry: (() -> Unit)? = null   // có giá trị với tin báo lỗi: hiện nút "Thử lại"
}

fun Long.vnd(): String = String.format(Locale.US, "%,d", this).replace(',', '.') + "đ"
fun Long.money(cur: String): String =
    if (cur == "VND") vnd() else (CURRENCIES[cur] ?: cur) + String.format(Locale.US, "%,d", this)
fun Tx.fmt(): String = amount.money(Store.cur(walletId))
fun sumByCur(l: List<Tx>): Map<String, Long> =
    l.groupBy { Store.cur(it.walletId) }.mapValues { e -> e.value.sumOf { it.amount } }
fun Map<String, Long>.show(): String =
    if (isEmpty()) "0đ" else entries.joinToString(" + ") { it.value.money(it.key) }

fun monthStart(off: Int): Calendar = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, off)
}

// Mặc định bỏ qua giao dịch vay/nợ (không tính là thu/chi); withDebt=true để hiện trong sổ
fun txsOfMonth(off: Int, withDebt: Boolean = false): List<Tx> {
    val s = monthStart(off)
    val e = (s.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
    return Store.txs.filter { it.time >= s.timeInMillis && it.time < e.timeInMillis && (withDebt || (it.debtId == 0L && it.report)) }
}

object Store {
    private lateinit var sp: SharedPreferences
    val txs = mutableStateListOf<Tx>()
    val wallets = mutableStateListOf<Wallet>()
    val debts = mutableStateListOf<Debt>()
    val budgets = mutableStateMapOf<String, Long>()
    val chats = HashMap<Long, MutableList<Msg>>()   // mỗi ví một cuộc trò chuyện
    var chatWallet by mutableLongStateOf(0L)        // 0 = đang ở danh sách ví; khác 0 = đang mở chat của ví đó
    var voiceLaunch by mutableStateOf(false)      // true = vừa mở từ widget, ChatRoom cần bật mic ngay
    val busy = mutableStateListOf<Long>()            // các ví đang chờ AI trả lời
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    var apiKey by mutableStateOf("")
    var groqKey by mutableStateOf("")              // AI dự phòng: Groq (miễn phí)
    var groqModel by mutableStateOf(Groq.DEFAULT_MODEL)
    var fallbackOn by mutableStateOf(true)         // tự dùng Groq khi Gemini lỗi
    val extras = listOf(ExtraCfg(), ExtraCfg())     // AI dự phòng thứ 2 và thứ 3 (kiểu OpenAI)
    fun hasAi() = apiKey.isNotBlank() || groqKey.isNotBlank() || extras.any { it.ready() }
    var aiName by mutableStateOf("Mimi")
    var persona by mutableStateOf("Thân thiện")
    var model by mutableStateOf(DEFAULT_MODEL)
    /** Tên model đã chuẩn hóa để gọi API: bỏ khoảng trắng và tiền tố "models/"; sai định dạng/để trống thì dùng mặc định. */
    fun modelId(): String {
        val m = model.trim().removePrefix("models/").replace(Regex("\\s+"), "")
        return if (Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$").matches(m)) m else DEFAULT_MODEL
    }

    /** Danh sách model thử lần lượt: model đã chọn, rồi tối đa 2 model dự phòng. */
    fun modelChain(): List<String> = (listOf(modelId()) + FALLBACK_MODELS).distinct().take(3)
    var userName by mutableStateOf("")
    var replyLen by mutableStateOf("Vừa")
    var temp by mutableFloatStateOf(0.5f)
    var typeEffect by mutableStateOf(true)
    var typeMs by mutableIntStateOf(3000)
    var maxRecSec by mutableIntStateOf(60)
    var themeMode by mutableStateOf("system")   // "system" | "light" | "dark"
    var systemDark by mutableStateOf(false)     // hệ thống đang ở chế độ tối (MainActivity cập nhật)
    // Chế độ du lịch
    var travelOn by mutableStateOf(false)
    var travelName by mutableStateOf("")
    var travelCur by mutableStateOf("USD")
    var travelRate by mutableDoubleStateOf(25400.0)   // 1 đơn vị ngoại tệ = ? VND
    var travelStart by mutableLongStateOf(0L)
    var travelEnd by mutableLongStateOf(0L)
    var autoSave by mutableStateOf(true)
    var autoThreshold by mutableFloatStateOf(0.85f)
    var autoMax by mutableLongStateOf(2_000_000L)
    var autoMinData by mutableIntStateOf(10)
    var notifOn by mutableStateOf(false)           // quét thông báo ngân hàng/ví bằng AI
    var notifWalletId by mutableLongStateOf(0L)    // 0 = AI tự chọn ví theo app gửi thông báo
    val notifLog = mutableStateListOf<String>()    // nhật ký quét gần đây (mới nhất ở đầu)
    val notifQueue = mutableStateListOf<QItem>()   // thông báo chưa quét được (mất mạng), chờ thử lại
    private val wcolors = HashMap<Long, Int>()   // id ví -> vị trí màu trong WALLET_PALETTE (lưu lại để màu không đổi)

    /** Màu của ví: chọn màu ít được dùng nhất trong bảng màu ở lần đầu, rồi giữ nguyên mãi. */
    fun walletColorInt(id: Long): Int = synchronized(wcolors) {
        var i = wcolors[id]
        if (i == null) {
            val counts = IntArray(WALLET_PALETTE.size)
            wallets.forEach { w -> wcolors[w.id]?.let { counts[it % counts.size]++ } }
            i = counts.indices.minByOrNull { counts[it] } ?: 0
            wcolors[id] = i
            sp.edit().putString("wcolors", wcolors.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
        }
        WALLET_PALETTE[i % WALLET_PALETTE.size]
    }
    val reviewIds = mutableStateListOf<Long>()     // giao dịch tự quét từ thông báo, chờ người dùng kiểm tra
    var showReview by mutableStateOf(false)        // true = đang hiện hộp thoại kiểm tra (đặt khi mở app)
    var notifMode by mutableStateOf("all")         // "all" = quét mọi app trừ app bị tắt; "selected" = chỉ app được bật
    val notifAllow = mutableStateListOf<String>()  // app được bật (khi notifMode = selected)
    val notifBlock = mutableStateListOf<String>()  // app bị tắt (khi notifMode = all)
    val notifSeen = mutableStateListOf<String>()   // app từng gửi thông báo dạng giao dịch (để gợi ý)
    var voiceReply by mutableStateOf(false)        // đọc phản hồi khi nhập bằng giọng nói
    var ttsMode by mutableStateOf("short")         // "short" = xác nhận ngắn; "ai" = đọc lời nhắn của AI
    var ttsSpeed by mutableStateOf("Vừa")          // Chậm | Vừa | Nhanh
    var ttsPitch by mutableStateOf("Vừa")          // Trầm | Vừa | Cao
    var ttsVoice by mutableStateOf("")             // tên giọng chọn trong máy; rỗng = mặc định
    var ttsEngine by mutableStateOf("device")      // "device" = giọng của máy; "gemini" = giọng AI Gemini
    var aiVoice by mutableStateOf("Kore")          // id giọng Gemini (dựng sẵn hoặc trong thư viện)
    var aiVoiceLabel by mutableStateOf("Nữ • Kore")
    var aiAccent by mutableStateOf("Mặc định")     // Mặc định | Miền Bắc | Miền Nam
    var aiTtsModel by mutableStateOf(TTS_MODEL_FAST)
    fun aiVoiceIsPrebuilt() = AI_PREBUILT.any { it.name == aiVoice }
    var voiceMode by mutableStateOf("gemini")   // "gemini" = ghi âm gửi Gemini nghe; "system" = nhận diện của máy

    fun walletName(id: Long) = wallets.firstOrNull { it.id == id }?.name ?: "(ví đã xóa)"
    fun cur(id: Long) = wallets.firstOrNull { it.id == id }?.currency ?: "VND"
    fun balance(w: Wallet) = txs.filter { it.walletId == w.id }.sumOf { if (it.income) it.amount else -it.amount }

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("chitieu", Context.MODE_PRIVATE)
        apiKey = sp.getString("key", "") ?: ""
        groqKey = sp.getString("gkey", "") ?: ""
        groqModel = sp.getString("gmodel", Groq.DEFAULT_MODEL) ?: Groq.DEFAULT_MODEL
        fallbackOn = sp.getBoolean("gfallback", true)
        extras.forEachIndexed { i, x ->
            x.preset = sp.getString("x${i}p", CUSTOM_PRESET) ?: CUSTOM_PRESET
            x.url = sp.getString("x${i}u", "") ?: ""
            x.key = sp.getString("x${i}k", "") ?: ""
            x.model = sp.getString("x${i}m", "") ?: ""
        }
        aiName = sp.getString("name", "Mimi") ?: "Mimi"
        persona = sp.getString("persona", "Thân thiện") ?: "Thân thiện"
        model = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        if (!sp.getBoolean("model_mig2", false)) {   // chuyển một lần từ model mặc định cũ (hay quá tải) sang mặc định mới
            if (model == "gemini-2.5-flash") model = DEFAULT_MODEL
            sp.edit().putBoolean("model_mig2", true).putString("model", model).apply()
        }
        voiceMode = sp.getString("vmode", "gemini") ?: "gemini"
        voiceReply = sp.getBoolean("vreply", false)
        ttsMode = sp.getString("vreplymode", "short") ?: "short"
        ttsSpeed = sp.getString("vrate", "Vừa") ?: "Vừa"
        ttsPitch = sp.getString("vpitch", "Vừa") ?: "Vừa"
        ttsVoice = sp.getString("vvoice", "") ?: ""
        ttsEngine = sp.getString("vengine", "device") ?: "device"
        aiVoice = sp.getString("aivoice", "Kore") ?: "Kore"
        aiVoiceLabel = sp.getString("aivlabel", "Nữ • Kore") ?: "Nữ • Kore"
        aiAccent = sp.getString("aiaccent", "Mặc định") ?: "Mặc định"
        aiTtsModel = sp.getString("aimodel", TTS_MODEL_FAST) ?: TTS_MODEL_FAST
        userName = sp.getString("uname", "") ?: ""
        replyLen = sp.getString("rlen", "Vừa") ?: "Vừa"
        temp = sp.getFloat("temp", 0.5f)
        typeEffect = sp.getBoolean("fx", true)
        typeMs = sp.getInt("fxms", 3000)
        maxRecSec = sp.getInt("recsec", 60)
        themeMode = sp.getString("theme", "system") ?: "system"
        travelOn = sp.getBoolean("trOn", false)
        travelName = sp.getString("trName", "") ?: ""
        travelCur = sp.getString("trCur", "USD") ?: "USD"
        travelRate = sp.getString("trRate", null)?.toDoubleOrNull() ?: 25400.0
        travelStart = sp.getLong("trStart", 0L)
        travelEnd = sp.getLong("trEnd", 0L)
        autoSave = sp.getBoolean("autosave", true)
        autoThreshold = sp.getFloat("autothr", 0.85f)
        autoMax = sp.getLong("automax", 2_000_000L)
        autoMinData = sp.getInt("automin", 10)
        notifOn = sp.getBoolean("notifOn", false)
        notifWalletId = sp.getLong("notifWallet", 0L)
        (sp.getString("wcolors", "") ?: "").split(",").forEach { e ->
            val kv = e.split(":")
            if (kv.size == 2) { val k = kv[0].toLongOrNull(); val v = kv[1].toIntOrNull(); if (k != null && v != null) wcolors[k] = v }
        }
        notifMode = sp.getString("nmode", "all") ?: "all"
        sp.getStringSet("reviewIds", emptySet())?.mapNotNull { it.toLongOrNull() }?.let { reviewIds.addAll(it) }
        sp.getStringSet("nallow", emptySet())?.let { notifAllow.addAll(it) }
        sp.getStringSet("nblock", emptySet())?.let { notifBlock.addAll(it) }
        sp.getStringSet("nseen", emptySet())?.let { notifSeen.addAll(it) }
        try {
            val nl = JSONArray(sp.getString("nlog", "[]"))
            for (i in 0 until nl.length()) notifLog.add(nl.getString(i))
        } catch (_: Exception) {}
        try {
            val q = JSONArray(sp.getString("nqueue", "[]"))
            for (k in 0 until q.length()) {
                val o = q.getJSONObject(k)
                notifQueue.add(QItem(o.getString("pkg"), o.optString("app", o.getString("pkg")), o.optString("title"), o.getString("text"),
                    o.getLong("time"), o.optInt("tries", 0), o.optLong("added", System.currentTimeMillis())))
            }
        } catch (_: Exception) {}
        // ví: bản cũ lưu mảng tên (String), bản mới lưu object {id,name,cur}
        val w = JSONArray(sp.getString("wallets", "[]"))
        for (i in 0 until w.length()) {
            val e = w.get(i)
            if (e is JSONObject) wallets.add(Wallet(e.getLong("id"), e.getString("name"), e.optString("cur", "VND")))
            else wallets.add(Wallet(i + 1L, e.toString(), "VND"))
        }
        if (wallets.isEmpty()) listOf("Tiền mặt", "Ngân hàng", "Ví MoMo").forEachIndexed { i, n -> wallets.add(Wallet(i + 1L, n, "VND")) }
        val a = JSONArray(sp.getString("txs", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val wid = if (o.has("walletId")) o.getLong("walletId")
                else wallets.firstOrNull { it.name == o.optString("wallet") }?.id ?: wallets[0].id
            txs.add(Tx(o.getLong("id"), o.getLong("amount"), o.getBoolean("income"), wid,
                o.getString("category"), o.getString("note"), o.getLong("time"), o.optLong("debtId", 0L), o.optLong("transferId", 0L), o.optBoolean("report", true), o.optString("photo")))
        }
        val dj = JSONArray(sp.getString("debts", "[]"))
        for (i in 0 until dj.length()) {
            val o = dj.getJSONObject(i)
            debts.add(Debt(o.getLong("id"), o.getString("person"), o.getBoolean("lend"), o.getLong("principal"),
                o.optString("cur", "VND"), o.getLong("time"), o.optLong("due", 0L), o.optString("note")))
        }
        val b = JSONObject(sp.getString("budgets", "{}"))
        for (k in b.keys()) budgets[k] = b.getLong(k)
        val cj = JSONObject(sp.getString("chats", "{}"))
        for (k in cj.keys()) {
            val id = k.toLongOrNull() ?: continue
            if (id != TOTAL_ID && wallets.none { it.id == id }) continue
            val arr = cj.getJSONArray(k)
            val l = mutableStateListOf<Msg>()
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); l.add(Msg(o.getBoolean("u"), o.getString("t"))) }
            if (l.isNotEmpty()) chats[id] = l
        }
    }

    fun welcome(wid: Long): Msg {
        val hi = "Chào ${if (userName.isBlank()) "bạn" else userName.trim()}! 👋\n"
        return if (wid == TOTAL_ID) Msg(false, hi + "Đây là trò chuyện tổng: bạn cứ nói kèm tên ví hoặc loại tiền, mình tự ghi vào đúng ví nhé.\n(Ví dụ: \"ăn trưa 120k ví Techcombank\", \"mua cơm 1500 yên\")")
        else Msg(false, hi + "Hôm nay mình giúp bạn quản lý tiền bạc nhé. Bạn muốn ghi lại khoản chi nào?\n(Ví: ${walletName(wid)} — ví dụ: \"sáng nay ăn phở 45k\")")
    }

    fun chatOf(wid: Long): MutableList<Msg> = chats.getOrPut(wid) { mutableStateListOf(welcome(wid)) }

    /** wid == null: xóa tất cả cuộc trò chuyện; ngược lại chỉ xóa trang chat của ví đó. */
    fun resetChat(wid: Long? = null) {
        val ids = if (wid != null) listOf(wid) else chats.keys.toList()
        ids.forEach { id -> val l = chatOf(id); l.clear(); l.add(welcome(id)) }
        saveChats()
    }

    fun saveChats() {
        val o = JSONObject()
        chats.forEach { (id, l) ->
            if (wallets.none { it.id == id }) return@forEach
            val a = JSONArray()
            l.takeLast(40).forEach { a.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
            o.put(id.toString(), a)
        }
        sp.edit().putString("chats", o.toString()).apply()
    }

    fun add(t: Tx) { txs.add(t); save() }
    fun updateTx(t: Tx) { val i = txs.indexOfFirst { it.id == t.id }; if (i >= 0) { txs[i] = t; save() } }

    // moveTo != null: chuyển giao dịch sang ví khác; null: xóa luôn giao dịch của ví
    fun deleteWallet(id: Long, moveTo: Long?) {
        if (moveTo != null) { for (i in txs.indices) if (txs[i].walletId == id) txs[i] = txs[i].copy(walletId = moveTo) }
        else {
            val dead = debts.filter { d -> txs.any { it.id == d.id && it.walletId == id } }.map { it.id }.toSet()
            val tdead = txs.filter { it.walletId == id && it.transferId != 0L }.map { it.transferId }.toSet()
            txs.removeAll { it.walletId == id || it.debtId in dead || it.transferId in tdead }
            debts.removeAll { it.id in dead }
        }
        wallets.removeAll { it.id == id }
        chats.remove(id)
        save(); saveChats()
    }

    // ---- Chuyển ví: 2 dòng (ra/vào) cùng transferId; chỉ cho phép hai ví khác nhau, cùng đơn vị tiền
    fun canTransfer(from: Long, to: Long) =
        from != to && wallets.any { it.id == from } && wallets.any { it.id == to } && cur(from) == cur(to)
    fun defaultTo(from: Long) = wallets.firstOrNull { it.id != from && it.currency == cur(from) }?.id ?: 0L

    fun addTransfer(from: Long, to: Long, amount: Long, time: Long, note: String, report: Boolean, tid: Long = System.nanoTime()) {
        txs.add(Tx(tid, amount, false, from, "Chuyển ví", note, time, 0L, tid, report))
        txs.add(Tx(tid + 1, amount, true, to, "Chuyển ví", note, time, 0L, tid, report))
        save()
    }
    fun deleteTransfer(tid: Long) { txs.removeAll { it.transferId == tid }; save() }

    // ---- Vay / nợ: gốc và các lần trả đều là Tx có debtId, nên số dư ví luôn đúng
    fun paid(d: Debt) = txs.filter { it.debtId == d.id && it.id != d.id }.sumOf { it.amount }
    fun remaining(d: Debt) = d.principal - paid(d)

    fun addDebt(d: Debt, walletId: Long) {
        debts.add(d)
        txs.add(Tx(d.id, d.principal, !d.lend, walletId, if (d.lend) "Cho vay" else "Vay nợ",
            listOf(d.person, d.note).filter { it.isNotBlank() }.joinToString(" – "), d.time, d.id))
        save()
    }

    fun addPayment(d: Debt, amount: Long, walletId: Long, time: Long, note: String) {
        txs.add(Tx(System.nanoTime(), amount, d.lend, walletId, if (d.lend) "Thu nợ" else "Trả nợ", note.ifBlank { d.person }, time, d.id))
        save()
    }

    fun deleteDebt(d: Debt) { txs.removeAll { it.debtId == d.id }; debts.removeAll { it.id == d.id }; save() }

    /** Lưu thẻ xem trước từ chat. Trả về thông báo lỗi, null nếu thành công. */
    fun savePending(p: Pending): String? {
        when (p.kind) {
            "tx" -> {
                val t = Tx(System.nanoTime(), p.amount, p.income, p.walletId, p.category, p.note, p.time, 0L, 0L, p.report)
                add(t); p.txId = t.id
            }
            "transfer" -> {
                if (!canTransfer(p.walletId, p.toWalletId)) return "Chỉ chuyển giữa hai ví khác nhau và cùng đơn vị tiền"
                addTransfer(p.walletId, p.toWalletId, p.amount, p.time, p.note, p.report)
            }
            "borrow", "lend" -> {
                if (p.person.isBlank()) return "Cần nhập tên người"
                addDebt(Debt(System.nanoTime(), p.person.trim(), p.kind == "lend", p.amount, cur(p.walletId), p.time, p.due, p.note), p.walletId)
            }
            else -> {
                val lend = p.kind == "collect"
                val name = p.person.trim()
                val d = debts.firstOrNull { it.lend == lend && remaining(it) > 0 && name.isNotEmpty() &&
                    (it.person.contains(name, true) || name.contains(it.person, true)) }
                    ?: return "Không thấy khoản ${if (lend) "cho vay" else "đang nợ"} nào với \"$name\". Hãy sửa tên hoặc chọn loại Vay/Cho vay."
                if (cur(p.walletId) != d.cur) return "Ví này khác đơn vị tiền với khoản nợ (${d.cur})"
                addPayment(d, minOf(p.amount, remaining(d)), p.walletId, p.time, p.note)
            }
        }
        return null
    }

    /** Ghi một dòng vào nhật ký quét thông báo (gọi trên luồng chính). */
    fun logNotif(msg: String) {
        notifLog.add(0, SimpleDateFormat("HH:mm dd/MM", Locale.US).format(Date()) + "  " + msg)
        while (notifLog.size > 30) notifLog.removeAt(notifLog.lastIndex)
        saveNotifLog()
    }
    fun saveNotifQueue() {
        val q = JSONArray()
        notifQueue.forEach {
            q.put(JSONObject().put("pkg", it.pkg).put("app", it.app).put("title", it.title).put("text", it.text)
                .put("time", it.time).put("tries", it.tries).put("added", it.added))
        }
        sp.edit().putString("nqueue", q.toString()).apply()
    }
    fun clearNotifLog() { notifLog.clear(); saveNotifLog() }
    private fun saveNotifLog() { sp.edit().putString("nlog", JSONArray(notifLog.toList()).toString()).apply() }

    // --- Lưu dữ liệu: phần nặng (giao dịch, ví, nợ, ngân sách) chụp nhanh rồi ghi ở luồng nền,
    //     gộp nhiều lần lưu liên tiếp thành một -> không giật khi gõ/chỉnh nhiều và không tốn pin ghi đĩa.
    private class Heavy(val txs: List<Tx>, val wallets: List<Wallet>, val debts: List<Debt>, val budgets: Map<String, Long>)
    private val ioExec = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val savePending = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var heavy: Heavy? = null

    fun save() {
        heavy = Heavy(txs.toList(), wallets.toList(), debts.toList(), budgets.toMap())
        if (savePending.compareAndSet(false, true)) ioExec.execute { writeHeavy() }
        sp.edit().putString("key", apiKey).putString("gkey", groqKey).putString("gmodel", groqModel).putBoolean("gfallback", fallbackOn).putString("x0p", extras[0].preset).putString("x0u", extras[0].url).putString("x0k", extras[0].key).putString("x0m", extras[0].model).putString("x1p", extras[1].preset).putString("x1u", extras[1].url).putString("x1k", extras[1].key).putString("x1m", extras[1].model).putString("name", aiName)
            .putString("persona", persona).putString("model", model).putString("vmode", voiceMode).putBoolean("vreply", voiceReply).putString("vreplymode", ttsMode).putString("vrate", ttsSpeed).putString("vpitch", ttsPitch).putString("vvoice", ttsVoice).putString("vengine", ttsEngine).putString("aivoice", aiVoice).putString("aivlabel", aiVoiceLabel)
            .putString("aiaccent", aiAccent).putString("aimodel", aiTtsModel)
            .putString("uname", userName).putString("rlen", replyLen).putFloat("temp", temp)
            .putString("theme", themeMode).putBoolean("trOn", travelOn).putString("trName", travelName).putString("trCur", travelCur)
            .putString("trRate", travelRate.toString()).putLong("trStart", travelStart).putLong("trEnd", travelEnd).putBoolean("fx", typeEffect).putInt("fxms", typeMs).putInt("recsec", maxRecSec)
            .putBoolean("notifOn", notifOn).putLong("notifWallet", notifWalletId)
            .putStringSet("reviewIds", reviewIds.map { it.toString() }.toSet())
            .putString("nmode", notifMode).putStringSet("nallow", notifAllow.toSet()).putStringSet("nblock", notifBlock.toSet()).putStringSet("nseen", notifSeen.toSet())
            .putBoolean("autosave", autoSave).putFloat("autothr", autoThreshold).putLong("automax", autoMax).putInt("automin", autoMinData).apply()
    }

    private fun writeHeavy() {
        savePending.set(false)
        val h = heavy ?: return
        val a = JSONArray()
        h.txs.forEach { a.put(JSONObject().put("id", it.id).put("amount", it.amount).put("income", it.income)
            .put("walletId", it.walletId).put("category", it.category).put("note", it.note).put("time", it.time).put("debtId", it.debtId).put("transferId", it.transferId).put("report", it.report).put("photo", it.photo)) }
        val w = JSONArray()
        h.wallets.forEach { w.put(JSONObject().put("id", it.id).put("name", it.name).put("cur", it.currency)) }
        val dj = JSONArray()
        h.debts.forEach { dj.put(JSONObject().put("id", it.id).put("person", it.person).put("lend", it.lend).put("principal", it.principal)
            .put("cur", it.cur).put("time", it.time).put("due", it.due).put("note", it.note)) }
        val b = JSONObject(); h.budgets.forEach { (k, v) -> b.put(k, v) }
        sp.edit().putString("txs", a.toString()).putString("wallets", w.toString())
            .putString("debts", dj.toString()).putString("budgets", b.toString()).apply()
    }

    /** Ghi ngay phần đang chờ (gọi khi app rời màn hình để chắc chắn không mất dữ liệu). */
    fun flush() { if (savePending.get()) writeHeavy() }
}
