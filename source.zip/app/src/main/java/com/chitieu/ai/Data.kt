package com.chitieu.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

val CATEGORIES = listOf("Ăn uống", "Di chuyển", "Mua sắm", "Hóa đơn", "Giải trí", "Sức khỏe",
    "Giáo dục", "Nhà cửa", "Du lịch", "Quà tặng", "Lương", "Thu nhập khác", "Khác")
val INCOME_CATS = setOf("Lương", "Thu nhập khác")
val CURRENCIES = linkedMapOf("VND" to "đ", "USD" to "\$", "EUR" to "€", "JPY" to "¥", "KRW" to "₩", "GBP" to "£", "THB" to "฿")

val PERSONAS = linkedMapOf(
    "Thân thiện" to "ấm áp, gần gũi, hay động viên, dùng emoji vừa phải",
    "Mỉa mai" to "mỉa mai, châm biếm duyên dáng khi người dùng tiêu tiền hoang phí, nhưng vẫn ghi chép chính xác",
    "Nghiêm khắc" to "như người mẹ nghiêm khắc, hay nhắc nhở tiết kiệm, càu nhàu nhẹ nhưng thương con",
    "Hài hước" to "vui nhộn, pha trò, chơi chữ, ví von hài hước",
    "Chuyên gia" to "chuyên nghiệp, ngắn gọn, đưa nhận xét tài chính thực tế",
    "Dễ thương" to "đáng yêu, nũng nịu, xưng em gọi anh/chị, nhiều emoji cute"
)

data class Wallet(val id: Long, val name: String, val currency: String)

data class Tx(val id: Long, val amount: Long, val income: Boolean, val walletId: Long,
              val category: String, val note: String, val time: Long)

class Pending(amount: Long, income: Boolean, walletId: Long, category: String, note: String, time: Long) {
    var amount by mutableLongStateOf(amount)
    var income by mutableStateOf(income)
    var walletId by mutableLongStateOf(walletId)
    var category by mutableStateOf(category)
    var note by mutableStateOf(note)
    var time by mutableLongStateOf(time)
    var saved by mutableStateOf(false)
    var dismissed by mutableStateOf(false)
}

class Msg(val fromUser: Boolean, val text: String, val pending: List<Pending> = emptyList())

fun Long.vnd(): String = String.format(Locale.US, "%,d", this).replace(',', '.') + "đ"
fun Long.money(cur: String): String =
    if (cur == "VND") vnd() else (CURRENCIES[cur] ?: cur) + String.format(Locale.US, "%,d", this)
fun Tx.fmt(): String = amount.money(Store.cur(walletId))
fun sumByCur(l: List<Tx>): Map<String, Long> =
    l.groupBy { Store.cur(it.walletId) }.mapValues { e -> e.value.sumOf { it.amount } }
fun Map<String, Long>.show(): String =
    if (isEmpty()) "0đ" else entries.joinToString(" + ") { it.value.money(it.key) }

fun monthStart(off: Int): Calendar = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, off)
}

fun txsOfMonth(off: Int): List<Tx> {
    val s = monthStart(off)
    val e = (s.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
    return Store.txs.filter { it.time >= s.timeInMillis && it.time < e.timeInMillis }
}

object Store {
    private lateinit var sp: SharedPreferences
    val txs = mutableStateListOf<Tx>()
    val wallets = mutableStateListOf<Wallet>()
    val budgets = mutableStateMapOf<String, Long>()
    val chat = mutableStateListOf<Msg>()
    var apiKey by mutableStateOf("")
    var aiName by mutableStateOf("Mimi")
    var persona by mutableStateOf("Thân thiện")
    var model by mutableStateOf("gemini-2.5-flash")

    fun walletName(id: Long) = wallets.firstOrNull { it.id == id }?.name ?: "(ví đã xóa)"
    fun cur(id: Long) = wallets.firstOrNull { it.id == id }?.currency ?: "VND"
    fun balance(w: Wallet) = txs.filter { it.walletId == w.id }.sumOf { if (it.income) it.amount else -it.amount }

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("chitieu", Context.MODE_PRIVATE)
        apiKey = sp.getString("key", "") ?: ""
        aiName = sp.getString("name", "Mimi") ?: "Mimi"
        persona = sp.getString("persona", "Thân thiện") ?: "Thân thiện"
        model = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        // ví: bản cũ lưu mảng tên (String), bản mới lưu object {id,name,cur}
        val w = JSONArray(sp.getString("wallets", "[]"))
        for (i in 0 until w.length()) {
            val e = w.get(i)
            if (e is JSONObject) wallets.add(Wallet(e.getLong("id"), e.getString("name"), e.optString("cur", "VND")))
            else wallets.add(Wallet(i + 1L, e.toString(), "VND"))
        }
        if (wallets.isEmpty()) listOf("Tiền mặt", "Ngân hàng", "Ví MoMo").forEachIndexed { i, n -> wallets.add(Wallet(i + 1L, n, "VND")) }
        val a = JSONArray(sp.getString("txs", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val wid = if (o.has("walletId")) o.getLong("walletId")
                else wallets.firstOrNull { it.name == o.optString("wallet") }?.id ?: wallets[0].id
            txs.add(Tx(o.getLong("id"), o.getLong("amount"), o.getBoolean("income"), wid,
                o.getString("category"), o.getString("note"), o.getLong("time")))
        }
        val b = JSONObject(sp.getString("budgets", "{}"))
        for (k in b.keys()) budgets[k] = b.getLong(k)
        chat.add(Msg(false, "Chào bạn! Mình là $aiName 👋 Cứ nhắn hoặc nói khoản chi tiêu, ví dụ: \"sáng nay 8 giờ ăn phở 50k bằng tiền mặt\", mình sẽ ghi lại giúp."))
    }

    fun add(t: Tx) { txs.add(t); save() }
    fun updateTx(t: Tx) { val i = txs.indexOfFirst { it.id == t.id }; if (i >= 0) { txs[i] = t; save() } }

    // moveTo != null: chuyển giao dịch sang ví khác; null: xóa luôn giao dịch của ví
    fun deleteWallet(id: Long, moveTo: Long?) {
        if (moveTo != null) { for (i in txs.indices) if (txs[i].walletId == id) txs[i] = txs[i].copy(walletId = moveTo) }
        else txs.removeAll { it.walletId == id }
        wallets.removeAll { it.id == id }
        save()
    }

    fun save() {
        val a = JSONArray()
        txs.forEach { a.put(JSONObject().put("id", it.id).put("amount", it.amount).put("income", it.income)
            .put("walletId", it.walletId).put("category", it.category).put("note", it.note).put("time", it.time)) }
        val w = JSONArray()
        wallets.forEach { w.put(JSONObject().put("id", it.id).put("name", it.name).put("cur", it.currency)) }
        val b = JSONObject(); budgets.forEach { (k, v) -> b.put(k, v) }
        sp.edit().putString("txs", a.toString()).putString("wallets", w.toString())
            .putString("budgets", b.toString()).putString("key", apiKey).putString("name", aiName)
            .putString("persona", persona).putString("model", model).apply()
    }
}
