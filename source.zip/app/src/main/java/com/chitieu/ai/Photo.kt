package com.chitieu.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.InputStream

/** Ảnh hóa đơn của giao dịch: lưu thu nhỏ (JPEG) trong bộ nhớ riêng của app. */
object Receipts {
    private fun dir(ctx: Context) = File(ctx.filesDir, "receipts").apply { mkdirs() }
    fun file(ctx: Context, name: String) = File(dir(ctx), name)

    fun delete(ctx: Context, name: String) {
        if (name.isBlank()) return
        try { file(ctx, name).delete() } catch (_: Exception) {}
    }

    /** Tệp tạm cho máy ảnh ghi vào (trong cache) và Uri để đưa cho ứng dụng máy ảnh. */
    fun newCapture(ctx: Context): Pair<File, Uri> {
        val d = File(ctx.cacheDir, "receipts").apply { mkdirs() }
        val f = File(d, "cap_" + System.currentTimeMillis() + ".jpg")
        return Pair(f, FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f))
    }

    private fun rotation(stream: InputStream): Int = try {
        when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (_: Exception) { 0 }

    /** Đọc ảnh từ nguồn, thu nhỏ (cạnh dài tối đa 1600px), xoay đúng chiều rồi lưu. Trả về tên tệp, null nếu lỗi. */
    fun save(ctx: Context, open: () -> InputStream?): String? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 3200) sample *= 2
            var bmp = open()?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) } ?: return null
            val rot = open()?.use { rotation(it) } ?: 0
            val longest = maxOf(bmp.width, bmp.height)
            if (longest > 1600) {
                val s = 1600f / longest
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            }
            if (rot != 0) {
                val m = Matrix().apply { postRotate(rot.toFloat()) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val name = "r_" + System.nanoTime() + ".jpg"
            file(ctx, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            return name
        } catch (_: Exception) {
            return null
        } catch (_: OutOfMemoryError) {
            return null
        }
    }

    fun load(ctx: Context, name: String, maxSide: Int): ImageBitmap? {
        try {
            val f = file(ctx, name)
            if (!f.exists()) return null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > maxSide) s *= 2
            return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
        } catch (_: Exception) {
            return null
        } catch (_: OutOfMemoryError) {
            return null
        }
    }

    /** Dọn ảnh không còn giao dịch nào dùng và ảnh chụp tạm trong cache. Gọi khi mở app. */
    fun cleanup(ctx: Context) {
        try {
            File(ctx.cacheDir, "receipts").deleteRecursively()
            val used = Store.txs.map { it.photo }.filter { it.isNotBlank() }.toSet()
            dir(ctx).listFiles()?.forEach { if (it.name !in used) it.delete() }
        } catch (_: Exception) {}
    }
}

/** Phần "Ảnh hóa đơn" trong hộp thoại sửa giao dịch: chụp, chọn từ thư viện, xem, xóa. */
@Composable
fun ReceiptPicker(photo: String, onChange: (String) -> Unit) {
    val ctx = LocalContext.current
    var view by remember { mutableStateOf(false) }
    var capFile by remember { mutableStateOf<File?>(null) }
    val img = remember(photo) { if (photo.isBlank()) null else Receipts.load(ctx, photo, 700) }

    fun importPhoto(open: () -> InputStream?, after: () -> Unit = {}) {
        Store.scope.launch {
            val name = withContext(Dispatchers.IO) { Receipts.save(ctx, open) }
            after()
            if (name != null) onChange(name) else Toast.makeText(ctx, "Không đọc được ảnh", Toast.LENGTH_SHORT).show()
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) importPhoto({ ctx.contentResolver.openInputStream(uri) })
    }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = capFile
        if (ok && f != null) importPhoto({ FileInputStream(f) }, { f.delete() }) else f?.delete()
    }

    Text("🧾 Ảnh hóa đơn", style = MaterialTheme.typography.bodySmall)
    if (img != null) {
        Image(
            bitmap = img, contentDescription = "Ảnh hóa đơn", contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().heightIn(max = 160.dp).clip(RoundedCornerShape(12.dp)).clickable { view = true }
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = {
            try {
                val (f, uri) = Receipts.newCapture(ctx)
                capFile = f
                cam.launch(uri)
            } catch (_: Exception) { Toast.makeText(ctx, "Không mở được máy ảnh", Toast.LENGTH_SHORT).show() }
        }) { Text(if (photo.isBlank()) "📷 Chụp" else "📷 Chụp lại", maxLines = 1, softWrap = false) }
        OutlinedButton(onClick = {
            pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) { Text("🖼 Chọn ảnh", maxLines = 1, softWrap = false) }
        if (photo.isNotBlank()) TextButton(onClick = { onChange("") }) { Text("🗑", color = Coral) }
    }
    if (view && photo.isNotBlank()) ReceiptViewer(photo) { view = false }
}

/** Xem ảnh hóa đơn toàn màn hình, có thể phóng to/kéo bằng hai ngón. */
@Composable
fun ReceiptViewer(name: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val img = remember(name) { Receipts.load(ctx, name, 2000) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (img != null) {
                Image(
                    bitmap = img, contentDescription = "Ảnh hóa đơn", contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                offset = if (scale == 1f) Offset.Zero else offset + pan
                            }
                        }
                        .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
                )
            } else {
                Text("Không mở được ảnh", color = Color.White, modifier = Modifier.align(Alignment.Center))
            }
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Đóng", tint = Color.White)
            }
        }
    }
}
