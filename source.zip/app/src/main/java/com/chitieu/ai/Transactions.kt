@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

/** Tab Giao dịch: gộp thống kê (tổng Thu/Chi, donut, dòng tiền) và sổ giao dịch trong một trang cuộn. */
@Composable
fun TransactionsScreen() {
    var range by remember { mutableIntStateOf(0) }      // 0 = theo tháng, 1 = 6 tháng gần nhất
    var off by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(0) }
    var showAllCats by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    var transferring by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    val offs = if (range == 0) listOf(off) else (-5..0).toList()
    // số liệu báo cáo (không tính chuyển ví / giao dịch tắt báo cáo)
    val m = offs.flatMap { txsOfMonth(it) }
    val thu = sumByCur(m.filter { it.income })
    val chiAll = sumByCur(m.filter { !it.income })
    val net = (thu.keys + chiAll.keys).associateWith { (thu[it] ?: 0L) - (chiAll[it] ?: 0L) }
    val chi = m.filter { !it.income && Store.cur(it.walletId) == "VND" }
    val total = chi.sumOf { it.amount }
    val byCat = chi.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }

    // dòng tiền (VND): lũy kế theo ngày (1 tháng) hoặc tổng theo tháng (6 tháng)
    val vndIds = Store.wallets.filter { it.currency == "VND" }.map { it.id }.toSet()
    val a = ArrayList<Float>()
    val b = ArrayList<Float>()
    val labels: List<String>
    val flowTitle: String
    if (range == 0) {
        val days = if (off == 0) Calendar.getInstance().get(Calendar.DAY_OF_MONTH) else monthStart(off).getActualMaximum(Calendar.DAY_OF_MONTH)
        val tin = LongArray(days + 1)
        val tout = LongArray(days + 1)
        m.filter { it.walletId in vndIds }.forEach { t ->
            val d = Calendar.getInstance().apply { timeInMillis = t.time }.get(Calendar.DAY_OF_MONTH)
            if (d in 1..days) { if (t.income) tin[d] += t.amount else tout[d] += t.amount }
        }
        var ci = 0L
        var co = 0L
        for (d in 1..days) { ci += tin[d]; co += tout[d]; a.add(ci.toFloat()); b.add(co.toFloat()) }
        labels = listOf(1, 1 + (days - 1) / 4, 1 + (days - 1) / 2, 1 + 3 * (days - 1) / 4, days).distinct().map { it.toString() }
        flowTitle = "Dòng tiền trong tháng (lũy kế)"
    } else {
        offs.forEach { o ->
            val mm = txsOfMonth(o).filter { it.walletId in vndIds }
            a.add(mm.filter { it.income }.sumOf { it.amount }.toFloat())
            b.add(mm.filter { !it.income }.sumOf { it.amount }.toFloat())
        }
        labels = offs.map { "T" + (monthStart(it).get(Calendar.MONTH) + 1) }
        flowTitle = "Dòng tiền theo tháng"
    }
    val maxV = maxOf(a.maxOrNull() ?: 0f, b.maxOrNull() ?: 0f).coerceAtLeast(1f)

    // danh sách giao dịch (có chuyển ví, mỗi lần chuyển chỉ hiện một dòng)
    val all = offs.flatMap { txsOfMonth(it, true) }.filter { !(it.transferId != 0L && it.income) }
    val list = when (filter) {
        1 -> all.filter { it.income && it.transferId == 0L }
        2 -> all.filter { !it.income && it.transferId == 0L }
        3 -> all.filter { it.transferId != 0L }
        else -> all
    }.sortedByDescending { it.time }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Giao dịch") {
            RoundBtn(onClick = { transferring = true }, bg = Lilac) { Text("🔁", fontSize = 20.sp) }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PillTabs(listOf("Theo tháng", "6 tháng"), range) { range = it } }
            item {
                if (range == 0) MonthBar(off) { off = it }
                else Text("6 tháng gần nhất", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp))
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SumCard("Thu", "+" + thu.show(), Fresh, FreshSoft, Modifier.weight(1f))
                        SumCard("Chi", "-" + chiAll.show(), Coral, CoralSoft, Modifier.weight(1f))
                    }
                    Text("Còn lại: " + net.show(), color = if (net.values.sum() >= 0L) Fresh else Coral, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 4.dp))
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Chi tiêu theo danh mục (ví VND)", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        CategoryDonut(topCats(chi, 4), total, "Chi tiêu")
                        if (byCat.size > 1) {
                            Text(
                                if (showAllCats) "Ẩn chi tiết ▴" else "Chi tiết theo mục ▾",
                                color = Fresh, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                                modifier = Modifier.clickable { showAllCats = !showAllCats }
                            )
                            if (showAllCats) {
                                byCat.forEach { (k, v) ->
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(catEmoji(k) + "  " + k, Modifier.weight(1f), fontSize = 14.sp)
                                            Text("${v.vnd()} (${if (total > 0L) v * 100 / total else 0}%)", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        }
                                        Bar(if (total > 0L) v.toFloat() / total else 0f, catColor(k))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(flowTitle, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            LegendDot(Fresh, "Thu")
                            Spacer(Modifier.width(10.dp))
                            LegendDot(Coral, "Chi")
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth().height(150.dp)) {
                            Column(Modifier.fillMaxHeight().padding(end = 8.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Text(maxV.toLong().shortVnd(), fontSize = 11.sp, color = Muted)
                                Text((maxV / 2).toLong().shortVnd(), fontSize = 11.sp, color = Muted)
                                Text("0", fontSize = 11.sp, color = Muted)
                            }
                            LineChart(a, b, Fresh, Coral, maxV, Modifier.weight(1f).fillMaxHeight())
                        }
                        Row(Modifier.fillMaxWidth().padding(start = 36.dp, top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            labels.forEach { Text(it, fontSize = 11.sp, color = Muted) }
                        }
                    }
                }
            }
            item { Text("Danh sách giao dịch", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp)) }
            item { PillTabs(listOf("Tất cả", "Thu", "Chi", "Chuyển"), filter) { filter = it } }
            if (list.isEmpty()) item { Text("Chưa có giao dịch.", color = Muted, modifier = Modifier.padding(16.dp)) }
            items(list, key = { it.id }) { t ->
                TxRow(t) {
                    if (t.debtId == 0L) editing = t
                    else Toast.makeText(ctx, "Khoản vay/nợ: sửa trong Tài khoản → Sổ nợ", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    editing?.let { if (it.transferId != 0L) TransferDialog(it) { editing = null } else EditTxDialog(it) { editing = null } }
    if (transferring) TransferDialog(null) { transferring = false }
}
