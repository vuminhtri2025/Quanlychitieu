@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.Manifest
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.text.input.VisualTransformation
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val RED = Coral
private val GREEN = Fresh


@Composable
fun Pick(value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("$value ▾") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false }) }
        }
    }
}

@Composable
fun DateTimeRow(time: Long, onChange: (Long) -> Unit) {
    val ctx = LocalContext.current
    val cal = Calendar.getInstance().apply { timeInMillis = time }
    Row {
        TextButton(onClick = {
            DatePickerDialog(ctx, { _, y, m, d ->
                onChange(Calendar.getInstance().apply { timeInMillis = time; set(y, m, d) }.timeInMillis)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }) { Text("📅 " + SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(time))) }
        TextButton(onClick = {
            TimePickerDialog(ctx, { _, h, mi ->
                onChange(Calendar.getInstance().apply { timeInMillis = time; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, mi) }.timeInMillis)
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }) { Text("🕒 " + SimpleDateFormat("HH:mm", Locale.US).format(Date(time))) }
    }
}

@Composable
fun EditTxDialog(t: Tx, onClose: () -> Unit) {
    var amount by remember { mutableStateOf(t.amount.toString()) }
    var income by remember { mutableStateOf(t.income) }
    var wid by remember { mutableLongStateOf(t.walletId) }
    var cat by remember { mutableStateOf(t.category) }
    var note by remember { mutableStateOf(t.note) }
    var time by remember { mutableLongStateOf(t.time) }
    var report by remember { mutableStateOf(t.report) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Sửa giao dịch") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false }, label = { Text("Chi") })
                    FilterChip(selected = income, onClick = { income = true }, label = { Text("Thu") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pick(Store.walletName(wid), Store.wallets.map { it.name }) { n -> Store.wallets.firstOrNull { it.name == n }?.let { wid = it.id } }
                    Pick(cat, CATEGORIES) { cat = it }
                }
                DateTimeRow(time) { time = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                ReportSwitch(report) { report = it }
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = amount.toLongOrNull() ?: 0L
            if (a > 0) { Store.updateTx(t.copy(amount = a, income = income, walletId = wid, category = cat, note = note, time = time, report = report)); onClose() }
        }) { Text("Lưu") } },
        dismissButton = { Row {
            TextButton(onClick = { Store.txs.removeAll { it.id == t.id }; Store.save(); onClose() }) { Text("Xóa", color = RED) }
            TextButton(onClick = onClose) { Text("Hủy") }
        } })
}

@Composable
fun WalletDialog(w: Wallet?, onClose: () -> Unit) {
    var name by remember { mutableStateOf(w?.name ?: "") }
    var cur by remember { mutableStateOf(w?.currency ?: "VND") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (w == null) "Thêm ví" else "Sửa ví") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Tên ví") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Đơn vị tiền: "); Pick(cur, CURRENCIES.keys.toList()) { cur = it } }
                if (err.isNotEmpty()) Text(err, color = RED)
            }
        },
        confirmButton = { TextButton(onClick = {
            val n = name.trim()
            if (n.isEmpty()) err = "Tên ví không được để trống"
            else if (Store.wallets.any { it.name.equals(n, true) && it.id != w?.id }) err = "Tên ví đã tồn tại"
            else {
                if (w == null) Store.wallets.add(Wallet(System.currentTimeMillis(), n, cur))
                else { val i = Store.wallets.indexOfFirst { it.id == w.id }; if (i >= 0) Store.wallets[i] = w.copy(name = n, currency = cur) }
                Store.save(); onClose()
            }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun DeleteWalletDialog(w: Wallet, onClose: () -> Unit) {
    val n = Store.txs.count { it.walletId == w.id }
    val others = Store.wallets.filter { it.id != w.id }
    var target by remember { mutableLongStateOf(others.first().id) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Xóa ví \"${w.name}\"") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (n == 0) Text("Ví chưa có giao dịch nào.") else {
                    Text("Ví có $n giao dịch. Chuyển chúng sang ví:")
                    Pick(Store.walletName(target), others.map { it.name }) { nm -> others.firstOrNull { it.name == nm }?.let { target = it.id } }
                }
            }
        },
        confirmButton = { TextButton(onClick = { Store.deleteWallet(w.id, if (n == 0) null else target); onClose() }) {
            Text(if (n == 0) "Xóa ví" else "Chuyển & xóa ví") } },
        dismissButton = { Column {
            if (n > 0) TextButton(onClick = { Store.deleteWallet(w.id, null); onClose() }) { Text("Xóa cả giao dịch", color = RED) }
            TextButton(onClick = onClose) { Text("Hủy") }
        } })
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun Chips(options: List<String>, selected: String, onPick: (String) -> Unit) {
    PillTabs(options, options.indexOf(selected), inactive = Lilac) { onPick(options[it]) }
}

@Composable
fun Radio(label: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Column { Text(label, fontWeight = FontWeight.Medium); if (desc.isNotEmpty()) Text(desc, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun AiSettings() {
    Section("Nhân vật") {
        OutlinedTextField(Store.aiName, { Store.aiName = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("Tên AI") }, singleLine = true)
        OutlinedTextField(Store.userName, { Store.userName = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("AI gọi bạn là") }, singleLine = true)
    }
    Section("Tính cách") {
        PERSONAS.forEach { (k, v) -> Radio(k, v, Store.persona == k) { Store.persona = k; Store.save() } }
    }
    Section("Cách trả lời") {
        Text("Độ dài")
        Chips(listOf("Ngắn", "Vừa", "Chi tiết"), Store.replyLen) { Store.replyLen = it; Store.save() }
        Text("Độ sáng tạo: " + String.format(Locale.US, "%.1f", Store.temp))
        Slider(Store.temp, { Store.temp = it }, valueRange = 0f..1f, onValueChangeFinished = { Store.save() })
    }
}

@Composable
fun KeySettings() {
    var show by remember { mutableStateOf(false) }
    Section("API key Google AI Studio") {
        OutlinedTextField(Store.apiKey, { Store.apiKey = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation())
        TextButton(onClick = { show = !show }) { Text(if (show) "🙈 Ẩn key" else "👁 Hiện key") }
        Text("Key chỉ lưu trên máy này. Lấy key tại aistudio.google.com.", style = MaterialTheme.typography.bodySmall)
    }
    Section("Model") {
        OutlinedTextField(Store.model, { Store.model = it.trim(); Store.save() }, Modifier.fillMaxWidth(), label = { Text("Tên model") }, singleLine = true)
        Chips(listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro"), Store.model) { Store.model = it; Store.save() }
    }
}

@Composable
fun VoiceSettings() {
    Section("Cách nhập giọng nói") {
        Radio("Ghi âm rồi gửi Gemini nghe", "Khuyên dùng: Gemini nghe và hiểu thẳng", Store.voiceMode == "gemini") { Store.voiceMode = "gemini"; Store.save() }
        Radio("Nhận diện giọng nói của máy", "Dùng bộ nhận diện Google có sẵn trên máy", Store.voiceMode == "system") { Store.voiceMode = "system"; Store.save() }
    }
    Section("Ghi âm tối đa (giây)") {
        Chips(listOf("30", "60", "120"), Store.maxRecSec.toString()) { Store.maxRecSec = it.toInt(); Store.save() }
    }
    Section("Khi mic không hoạt động") {
        Text("Nếu ghi âm không thu được tiếng, thử đổi sang \"Nhận diện giọng nói của máy\" ở trên (hoặc ngược lại).", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun FxSettings() {
    Section("Chữ hiện dần khi AI trả lời") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Bật hiệu ứng", Modifier.weight(1f))
            Switch(Store.typeEffect, { Store.typeEffect = it; Store.save() })
        }
        Text("Thời gian hiện hết một tin nhắn dài (giây)")
        Chips(listOf("2", "3", "5"), (Store.typeMs / 1000).toString()) { Store.typeMs = it.toInt() * 1000; Store.save() }
    }
}

@Composable
fun WalletSettings() {
    var editW by remember { mutableStateOf<Wallet?>(null) }
    var delW by remember { mutableStateOf<Wallet?>(null) }
    var adding by remember { mutableStateOf(false) }
    Section("Danh sách ví") {
        Store.wallets.toList().forEach { w ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(w.name, fontWeight = FontWeight.Medium)
                    Text("${w.currency} • ${Store.balance(w).money(w.currency)}", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { editW = w }) { Text("✏️") }
                if (Store.wallets.size > 1) TextButton(onClick = { delW = w }) { Text("🗑") }
            }
        }
        Button(onClick = { adding = true }) { Text("➕ Thêm ví") }
    }
    editW?.let { WalletDialog(it) { editW = null } }
    if (adding) WalletDialog(null) { adding = false }
    delW?.let { DeleteWalletDialog(it) { delW = null } }
}

@Composable
fun DataSettings() {
    val ctx = LocalContext.current
    Section("Xuất dữ liệu") {
        Text("${Store.txs.size} giao dịch", style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val csv = "Thời gian,Loại,Số tiền,Đơn vị,Ví,Mục,Ghi chú\n" + Store.txs.sortedBy { it.time }.joinToString("\n") {
                "${f.format(Date(it.time))},${if (it.income) "Thu" else "Chi"},${it.amount},${Store.cur(it.walletId)},${Store.walletName(it.walletId)},${it.category},\"${it.note.replace("\"", "\"\"")}\""
            }
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, csv), "Xuất CSV"))
        }) { Text("📤 Xuất CSV") }
    }
    Section("Cuộc trò chuyện") {
        OutlinedButton(onClick = { Store.resetChat() }) { Text("🧹 Xóa tất cả cuộc trò chuyện") }
    }
}

@Composable
fun DueRow(due: Long, onChange: (Long) -> Unit) {
    val ctx = LocalContext.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = {
            val c = Calendar.getInstance().apply { if (due > 0) timeInMillis = due }
            DatePickerDialog(ctx, { _, y, m, d ->
                onChange(Calendar.getInstance().apply { set(y, m, d, 23, 59, 59) }.timeInMillis)
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }) { Text("📆 Hạn trả: " + if (due > 0) SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(due)) else "chưa đặt") }
        if (due > 0) TextButton(onClick = { onChange(0L) }) { Text("✕") }
    }
}

fun sumDebt(l: List<Debt>): Map<String, Long> = l.groupBy { it.cur }.mapValues { e -> e.value.sumOf { Store.remaining(it) } }

@Composable
fun PayDialog(d: Debt, onClose: () -> Unit) {
    val rem = Store.remaining(d)
    val ws = Store.wallets.filter { it.currency == d.cur }
    var amount by remember { mutableStateOf(rem.toString()) }
    var wid by remember { mutableLongStateOf(ws.firstOrNull()?.id ?: 0L) }
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (d.lend) "Thu nợ từ ${d.person}" else "Trả nợ cho ${d.person}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (ws.isEmpty()) Text("Chưa có ví nào dùng đơn vị ${d.cur}. Hãy thêm ví trong Cài đặt.", color = RED) else {
                    Text("Còn lại: ${rem.money(d.cur)}")
                    OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Pick(Store.walletName(wid), ws.map { it.name }) { n -> ws.firstOrNull { it.name == n }?.let { wid = it.id } }
                    DateTimeRow(time) { time = it }
                    OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                }
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = (amount.toLongOrNull() ?: 0L).coerceAtMost(rem)
            if (a > 0 && wid != 0L) { Store.addPayment(d, a, wid, time, note); onClose() }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun DebtDialog(d: Debt?, onClose: () -> Unit) {
    var lend by remember { mutableStateOf(d?.lend ?: false) }
    var person by remember { mutableStateOf(d?.person ?: "") }
    var amount by remember { mutableStateOf("") }
    var wid by remember { mutableLongStateOf(Store.wallets.first().id) }
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var due by remember { mutableLongStateOf(d?.due ?: 0L) }
    var note by remember { mutableStateOf(d?.note ?: "") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (d == null) "Thêm khoản nợ" else "Sửa khoản nợ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (d == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !lend, onClick = { lend = false }, label = { Text("Mình vay") })
                        FilterChip(selected = lend, onClick = { lend = true }, label = { Text("Cho vay") })
                    }
                }
                OutlinedTextField(person, { person = it }, label = { Text("Tên người") }, singleLine = true)
                if (d == null) {
                    OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Pick(Store.walletName(wid), Store.wallets.map { it.name }) { n -> Store.wallets.firstOrNull { it.name == n }?.let { wid = it.id } }
                    DateTimeRow(time) { time = it }
                }
                DueRow(due) { due = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                if (err.isNotEmpty()) Text(err, color = RED)
            }
        },
        confirmButton = { TextButton(onClick = {
            val p = person.trim()
            val a = amount.toLongOrNull() ?: 0L
            if (p.isEmpty()) err = "Nhập tên người"
            else if (d == null) {
                if (a <= 0) err = "Nhập số tiền"
                else { Store.addDebt(Debt(System.nanoTime(), p, lend, a, Store.cur(wid), time, due, note), wid); onClose() }
            } else {
                val i = Store.debts.indexOfFirst { it.id == d.id }
                if (i >= 0) Store.debts[i] = d.copy(person = p, due = due, note = note)
                Store.save(); onClose()
            }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun ReportSwitch(on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = on, onCheckedChange = onChange)
        Text("  Tính vào báo cáo tổng", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun TransferDialog(t: Tx?, onClose: () -> Unit) {
    val inLeg = t?.let { x -> Store.txs.firstOrNull { it.transferId == x.transferId && it.income } }
    var amount by remember { mutableStateOf(t?.amount?.toString() ?: "") }
    var from by remember { mutableLongStateOf(t?.walletId ?: Store.wallets.first().id) }
    var to by remember { mutableLongStateOf(inLeg?.walletId ?: Store.defaultTo(from)) }
    var time by remember { mutableLongStateOf(t?.time ?: System.currentTimeMillis()) }
    var note by remember { mutableStateOf(t?.note ?: "") }
    var report by remember { mutableStateOf(t?.report ?: false) }
    var err by remember { mutableStateOf("") }
    val opts = Store.wallets.filter { it.id != from && it.currency == Store.cur(from) }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (t == null) "Chuyển tiền giữa ví" else "Sửa chuyển ví") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền (${Store.cur(from)})") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Pick("Từ: " + Store.walletName(from), Store.wallets.map { it.name }) { n ->
                    Store.wallets.firstOrNull { it.name == n }?.let { from = it.id; if (!Store.canTransfer(from, to)) to = Store.defaultTo(from) }
                }
                if (opts.isEmpty()) Text("Không có ví nào khác cùng đơn vị tiền (${Store.cur(from)}).", color = RED)
                else Pick("Đến: " + (Store.wallets.firstOrNull { it.id == to }?.name ?: "chọn ví"), opts.map { it.name }) { n ->
                    opts.firstOrNull { it.name == n }?.let { to = it.id }
                }
                DateTimeRow(time) { time = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                ReportSwitch(report) { report = it }
                if (err.isNotEmpty()) Text(err, color = RED)
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = amount.toLongOrNull() ?: 0L
            if (a <= 0) err = "Nhập số tiền"
            else if (!Store.canTransfer(from, to)) err = "Chọn hai ví khác nhau và cùng đơn vị tiền"
            else {
                if (t != null) Store.deleteTransfer(t.transferId)
                Store.addTransfer(from, to, a, time, note, report, t?.transferId ?: System.nanoTime())
                onClose()
            }
        }) { Text("Lưu") } },
        dismissButton = { Row {
            if (t != null) TextButton(onClick = { Store.deleteTransfer(t.transferId); onClose() }) { Text("Xóa", color = RED) }
            TextButton(onClick = onClose) { Text("Hủy") }
        } })
}

@Composable
fun AutoSettings() {
    val n = Auto.learned()
    val caps = linkedMapOf("500k" to 500_000L, "1tr" to 1_000_000L, "2tr" to 2_000_000L, "5tr" to 5_000_000L, "10tr" to 10_000_000L)
    Section("Mức hiểu biết của AI") {
        Text("AI đã học từ $n giao dịch — ${Auto.level(n)}", fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { (n / 100f).coerceAtMost(1f) }, Modifier.fillMaxWidth())
        Text("Càng nhiều giao dịch, AI càng nhận ra thói quen (khoản hay gặp, ví hay dùng, số tiền thường thấy) và càng dám tự lưu.", style = MaterialTheme.typography.bodySmall)
    }
    Section("Tự động lưu") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Cho phép AI tự lưu", Modifier.weight(1f))
            Switch(Store.autoSave, { Store.autoSave = it; Store.save() })
        }
        Text("Độ tự tin tối thiểu: ${(Store.autoThreshold * 100).toInt()}%")
        Slider(Store.autoThreshold, { Store.autoThreshold = it }, valueRange = 0.6f..0.99f, onValueChangeFinished = { Store.save() })
        Text("Chỉ tự lưu khoản không quá")
        Chips(caps.keys.toList(), caps.entries.firstOrNull { it.value == Store.autoMax }?.key ?: "") { Store.autoMax = caps[it] ?: Store.autoMax; Store.save() }
        Text("Bắt đầu tự lưu khi đã học ít nhất (giao dịch)")
        Chips(listOf("10", "20", "50"), Store.autoMinData.toString()) { Store.autoMinData = it.toInt(); Store.save() }
    }
    Section("Luôn cần bạn xác nhận") {
        Text("Vay/nợ, trả nợ, chuyển ví, ví khác VND, khoản vượt hạn mức và khoản AI chưa đủ tự tin. Mọi khoản tự lưu đều có nút Hoàn tác và Sửa ngay trong khung chat.", style = MaterialTheme.typography.bodySmall)
    }
}
