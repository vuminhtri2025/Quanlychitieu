@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

/** Tab Chat: Store.chatWallet == 0 (hoặc ví không còn) -> trang chủ; ngược lại -> cuộc trò chuyện của ví đó. */
@Composable
fun ChatScreen(active: Boolean = true) {
    val w = if (Store.chatWallet == TOTAL_ID) TOTAL_WALLET else Store.wallets.firstOrNull { it.id == Store.chatWallet }
    if (w == null) HomeScreen() else ChatRoom(w, active)
}

// ---------------------------------------------------------------- Trang chủ

fun vndBalance(): Long = Store.wallets.filter { it.currency == "VND" }.sumOf { Store.balance(it) }

/** Số dư VND cuối mỗi ngày trong [days] ngày gần nhất (để vẽ đường nhỏ). */
fun balanceSeries(days: Int): List<Float> {
    val vnd = Store.wallets.filter { it.currency == "VND" }.map { it.id }.toSet()
    val tx = Store.txs.filter { it.walletId in vnd }
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.DAY_OF_YEAR, -(days - 1))
    val start = c.timeInMillis
    var bal = tx.filter { it.time < start }.sumOf { if (it.income) it.amount else -it.amount }
    val day = 86_400_000L
    val out = ArrayList<Float>()
    for (i in 0 until days) {
        val from = start + i * day
        val to = from + day
        bal += tx.filter { it.time >= from && it.time < to }.sumOf { if (it.income) it.amount else -it.amount }
        out.add(bal.toFloat())
    }
    return out
}

/** % thay đổi tài sản VND so với đầu tháng; null nếu chưa có mốc so sánh. */
fun assetDelta(): Int? {
    val vnd = Store.wallets.filter { it.currency == "VND" }.map { it.id }.toSet()
    val ms = monthStart(0).timeInMillis
    val prev = Store.txs.filter { it.walletId in vnd && it.time < ms }.sumOf { if (it.income) it.amount else -it.amount }
    if (prev <= 0L) return null
    return ((vndBalance() - prev) * 100 / prev).toInt()
}

fun topCats(chi: List<Tx>, keep: Int = 4): List<Pair<String, Long>> {
    val by = chi.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
    val top = by.take(keep).map { it.key to it.value }.toMutableList()
    val rest = by.drop(keep).sumOf { it.value }
    if (rest > 0L) {
        val i = top.indexOfFirst { it.first == "Khác" }
        if (i >= 0) top[i] = "Khác" to (top[i].second + rest) else top.add("Khác" to rest)
    }
    return top
}

@Composable
fun CategoryDonut(
    items: List<Pair<String, Long>>, total: Long, centerLabel: String = "Tổng chi",
    fmt: (Long) -> String = { it.vnd() }
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Donut(items.map { it.second.toFloat() to catColor(it.first) }, Modifier.size(140.dp), 20.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(fmt(total), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                Text(centerLabel, color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (items.isEmpty()) Text("Chưa có khoản chi nào", color = Muted, fontSize = 14.sp)
            items.forEach { (n, v) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(catEmoji(n), fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(n, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                    Text("${if (total > 0) v * 100 / total else 0}%", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, color: Color, emoji: String, modifier: Modifier = Modifier) {
    AppCard(modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(emoji, color, 32.dp)
                Spacer(Modifier.width(8.dp))
                Text(label, color = Muted, fontSize = 13.sp)
            }
            Text(value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
fun HomeScreen() {
    val total = Store.wallets.groupBy { it.currency }.mapValues { e -> e.value.sumOf { Store.balance(it) } }
    val m = txsOfMonth(0)
    val thu = sumByCur(m.filter { it.income })
    val chi = sumByCur(m.filter { !it.income })
    val series = balanceSeries(30)
    val delta = assetDelta()
    val name = Store.userName.trim()
    val ini = name.firstOrNull()?.uppercase() ?: "🙂"
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(Lilac, CircleShape), contentAlignment = Alignment.Center) {
                Text(ini, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Fresh)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Xin chào,", color = Muted, fontSize = 14.sp)
                Text(if (name.isEmpty()) "bạn 👋" else "$name 👋", fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
        if (Store.travelOn) {
            AppCard(Modifier.fillMaxWidth(), color = FreshSoft) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("✈️", fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Đang du lịch" + if (Store.travelName.isNotBlank()) " • ${Store.travelName.trim()}" else "",
                            fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "1 ${Store.travelCur} = ${Travel.fmtForeign(Store.travelRate)}đ • nhắn số tiền ngoại tệ, app tự quy đổi",
                            color = Muted, fontSize = 12.sp
                        )
                    }
                }
            }
        }
        AppCard(Modifier.fillMaxWidth(), color = Lilac) {
            Box(Modifier.fillMaxWidth()) {
                Sparkline(series, Fresh, Modifier.align(Alignment.BottomEnd).fillMaxWidth(0.5f).height(80.dp))
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Tổng tài sản", color = Muted, fontSize = 14.sp)
                    Text(total.show(), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    if (delta != null) {
                        Text(
                            (if (delta >= 0) "▲ +$delta%" else "▼ $delta%") + " so với đầu tháng",
                            color = if (delta >= 0) Fresh else Coral, fontSize = 13.sp, fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Thu nhập", "+" + thu.show(), Fresh, "⬇️", Modifier.weight(1f))
            StatCard("Chi tiêu", "-" + chi.show(), Coral, "⬆️", Modifier.weight(1f))
        }
        Text("Trò chuyện theo ví", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp))
        AppCard(Modifier.fillMaxWidth()) {
            run {
                val lastT = Store.chats[TOTAL_ID]?.takeIf { it.size > 1 }?.lastOrNull()
                val previewT = when {
                    TOTAL_ID in Store.busy -> "${Store.aiName} đang nghĩ…"
                    lastT == null -> "Nói kèm tên ví hoặc loại tiền, AI tự chọn ví"
                    else -> (if (lastT.fromUser) "Bạn: " else "") + lastT.text.replace('\n', ' ')
                }
                Row(
                    Modifier.fillMaxWidth().clickable { Store.chatWallet = TOTAL_ID }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(46.dp).background(Color(0xFF3F8FE0), CircleShape), contentAlignment = Alignment.Center) { Text("🌐", fontSize = 22.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Trò chuyện tổng", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.width(8.dp))
                            Text(total.show(), fontWeight = FontWeight.Medium, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(previewT, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                HorizontalDivider(Modifier.padding(start = 74.dp), color = Lilac)
            }
            Store.wallets.toList().forEachIndexed { i, w ->
                val bal = Store.balance(w)
                val last = Store.chats[w.id]?.takeIf { it.size > 1 }?.lastOrNull()
                val preview = when {
                    w.id in Store.busy -> "${Store.aiName} đang nghĩ…"
                    last == null -> "Chạm để bắt đầu trò chuyện"
                    else -> (if (last.fromUser) "Bạn: " else "") + last.text.replace('\n', ' ')
                }
                val wi = w.name.trim().let { if (it.isEmpty()) "?" else String(Character.toChars(it.codePointAt(0))).uppercase() }
                Row(
                    Modifier.fillMaxWidth().clickable { Store.chatWallet = w.id }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(46.dp).background(Color(Store.walletColorInt(w.id)), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text(wi, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(w.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.width(8.dp))
                            Text(bal.money(w.currency), fontWeight = FontWeight.Medium, color = if (bal < 0) Coral else Charcoal, fontSize = 14.sp)
                        }
                        Text(preview, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (i < Store.wallets.size - 1) HorizontalDivider(Modifier.padding(start = 74.dp), color = Lilac)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ---------------------------------------------------------------- Phòng chat

@Composable
fun BubbleText(m: Msg) {
    var shown by remember { mutableIntStateOf(if (m.typing) 0 else m.text.length) }
    LaunchedEffect(m) {
        if (m.typing) {
            val n = m.text.length
            val ms = (n * 50L).coerceIn(800L, Store.typeMs.toLong()).toInt()
            try {
                Animatable(0f).animateTo(1f, tween(ms, easing = LinearEasing)) { shown = (value * n).toInt() }
            } finally { m.typing = false }
        }
    }
    val txt = if (m.typing) buildAnnotatedString {
        append(m.text.take(shown))
        withStyle(SpanStyle(color = Color.Transparent)) { append(m.text.drop(shown)) }
    } else AnnotatedString(m.text)
    Text(txt, Modifier.padding(horizontal = 14.dp, vertical = 11.dp), color = Charcoal, fontSize = 15.sp, lineHeight = 22.sp)
}

@Composable
private fun QuickChips(onVoice: () -> Unit, onAsk: (String) -> Unit) {
    val items = listOf(
        "🎤  Ghi nhanh chi tiêu bằng giọng nói" to { onVoice() },
        "📊  Xem báo cáo chi tiêu" to { onAsk("Cho mình xem báo cáo chi tiêu tháng này") },
        "💡  Tư vấn tiết kiệm" to { onAsk("Tư vấn giúp mình cách tiết kiệm dựa trên chi tiêu tháng này") }
    )
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { (label, act) ->
            Text(
                label,
                Modifier.clip(CircleShape).background(Paper).clickable { act() }.padding(horizontal = 20.dp, vertical = 12.dp),
                fontSize = 14.sp, fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun RecordingOverlay(onStop: () -> Unit, onCancel: () -> Unit) {
    var secs by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1000); secs++ } }
    val tr = rememberInfiniteTransition(label = "wave")
    val phase by tr.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase")
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color(0xFF17141D))) {
            IconButton(onClick = onCancel, modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Hủy", tint = Color.White)
            }
            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Đang ghi âm...", color = Color.White, fontSize = 22.sp)
                Spacer(Modifier.height(40.dp))
                Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                    val n = 41
                    val gap = size.width / n
                    val bw = gap * 0.45f
                    for (i in 0 until n) {
                        val env = 1f - kotlin.math.abs(i - n / 2) / (n / 2f)
                        val a = kotlin.math.sin(phase * 2f + i * 0.55f) * 0.5f + 0.5f
                        val h = size.height * (0.12f + 0.88f * env * a)
                        drawRoundRect(
                            if (i % 2 == 0) Fresh else Color(0xFF9B7FE8),
                            Offset(i * gap + gap / 2f - bw / 2f, (size.height - h) / 2f), Size(bw, h), CornerRadius(bw / 2f)
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text(String.format(Locale.US, "%02d:%02d", secs / 60, secs % 60), color = Color.White, fontSize = 44.sp)
                Spacer(Modifier.height(40.dp))
                Box(
                    Modifier.size(104.dp).border(2.dp, Fresh.copy(alpha = 0.5f), CircleShape).padding(10.dp)
                        .clip(CircleShape).background(Fresh).clickable { onStop() },
                    contentAlignment = Alignment.Center
                ) { Box(Modifier.size(30.dp).background(Color.White, RoundedCornerShape(8.dp))) }
            }
            Text(
                "Nói: “Ăn trưa 120.000đ”", Modifier.align(Alignment.BottomCenter).padding(32.dp),
                color = Color(0xFFB9B2C6), fontSize = 14.sp
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatRoom(w: Wallet, active: Boolean) {
    val ctx = LocalContext.current
    val wid = w.id
    val chat = Store.chatOf(wid)
    val maxBubble = (LocalConfiguration.current.screenWidthDp * 0.8f).dp
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val busy = wid in Store.busy
    BackHandler(enabled = active) { Store.chatWallet = 0L }
    var recording by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var copyMenu by remember { mutableStateOf<Msg?>(null) }
    fun copyText(s: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.setPrimaryClip(ClipData.newPlainText("Tin nhắn", s))
        Toast.makeText(ctx, "Đã sao chép", Toast.LENGTH_SHORT).show()
    }
    val recorder = remember { Recorder() }
    val needKey = "Bạn chưa nhập API key. Vào Tài khoản → Trợ lý AI, dán key Gemini (Google AI Studio) hoặc key Groq nhé."

    fun say(t: String) { chat.add(Msg(false, t)) }
    // Chạy trên scope của app: rời khỏi phòng chat khi AI đang trả lời thì câu trả lời vẫn được lưu vào ví đó
    fun run(m: Msg, audio: ByteArray?, voice: Boolean = false) {
        Store.busy.add(wid)
        Store.scope.launch {
            try {
                val r = Gemini.ask(chat, wid, audio)
                if (audio != null) m.text = "🎤 " + r.heard.ifBlank { "(không nghe rõ)" }
                r.items.forEach { if (it.auto && Store.savePending(it) == null) { it.saved = true; it.autoSaved = true } }
                chat.add(Msg(false, r.reply, r.items).also { it.typing = Store.typeEffect })
                if (Store.apiKey.isNotBlank() && r.usedModel.isNotEmpty() && r.usedModel != Store.modelId())
                    Toast.makeText(ctx, "Gemini đang bận, đã dùng ${r.usedModel}", Toast.LENGTH_SHORT).show()
                // nhập bằng giọng nói + bật phản hồi giọng nói -> đọc xác nhận
                if (Store.voiceReply && (voice || audio != null)) runCatching { Speaker.speak(ctx, Speaker.compose(r)) }
            } catch (e: Exception) {
                // báo lỗi kèm nút "Thử lại" gửi lại đúng tin vừa rồi
                val em = Msg(false, "⚠️ ${e.message}")
                em.retry = { if (!Store.busy.contains(wid)) { chat.remove(em); run(m, audio, voice) } }
                chat.add(em)
            } finally {
                Store.busy.remove(wid)
                Store.saveChats()
            }
        }
    }
    fun send(t: String, voice: Boolean = false) {
        if (t.isBlank() || busy) return
        if (!Store.hasAi()) { say(needKey); return }
        if (!voice) Speaker.stop()   // gõ tay: không phản hồi giọng nói, và dừng câu đang đọc dở
        val m = Msg(true, t); chat.add(m); input = ""; run(m, null, voice)
    }
    fun stopRec() {
        if (!recording) return
        recording = false
        val pcm = recorder.stop()
        if (!hasSound(pcm)) { say("Không thu được âm thanh (mic có thể đang bị app khác chặn). Thử đổi chế độ trong Tài khoản → Giọng nói."); return }
        if (!Store.hasAi()) { say(needKey); return }
        val m = Msg(true, "🎤 đang nghe…"); chat.add(m); run(m, wav(pcm))
    }
    fun cancelRec() {
        if (!recording) return
        recording = false
        recorder.stop()
    }
    fun startRec() {
        Speaker.stop()
        try { recorder.start(); recording = true } catch (e: Exception) { say("⚠️ Không mở được mic: ${e.message}. Thử đổi chế độ trong Tài khoản → Giọng nói.") }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else say("Bạn chưa cấp quyền micro cho app.")
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it, true) }
    }
    fun onMic() {
        if (busy) return
        Speaker.stop()
        if (Store.voiceMode == "system") {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            try { voice.launch(i) } catch (e: ActivityNotFoundException) {
                Toast.makeText(ctx, "Máy chưa có dịch vụ nhận diện giọng nói", Toast.LENGTH_SHORT).show()
            }
        } else if (recording) stopRec()
        else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    // mở từ widget: bật mic ngay khi vào phòng chat (đợi giao diện ổn định một chút)
    LaunchedEffect(Store.voiceLaunch, active) {
        if (Store.voiceLaunch && active) {
            Store.voiceLaunch = false
            delay(400)
            onMic()
        }
    }
    LaunchedEffect(chat.size, busy, wid) { list.animateScrollToItem(chat.size) }
    LaunchedEffect(chat.size, busy) { if (!busy) Store.saveChats() }
    val last = chat.lastOrNull()
    LaunchedEffect(last, last?.typing) { while (last?.typing == true) { list.scrollToItem(chat.size); delay(200) } }
    LaunchedEffect(recording) { if (recording) { delay(Store.maxRecSec * 1000L); stopRec() } }
    // rời phòng chat khi đang ghi âm thì dừng mic, không gửi
    DisposableEffect(Unit) { onDispose { if (recording) { recording = false; recorder.stop() } } }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ---- Đầu trang: Mimi + trạng thái
            Row(
                Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { Store.chatWallet = 0L }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại") }
                Box(Modifier.size(46.dp).background(Lilac, CircleShape), contentAlignment = Alignment.Center) { Text("🤖", fontSize = 22.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(Store.aiName, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.width(8.dp))
                        Pill(w.name, Charcoal, Lilac, Modifier.weight(1f, fill = false))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(if (busy) Amber else Fresh, CircleShape))
                        Spacer(Modifier.width(6.dp))
                        Text(if (busy) "Đang suy nghĩ…" else "Đang hoạt động", color = if (busy) Amber else Fresh, fontSize = 13.sp)
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Tùy chọn") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    "Số dư: " + if (wid == TOTAL_ID) Store.wallets.groupBy { it.currency }.mapValues { e -> e.value.sumOf { Store.balance(it) } }.show()
                                    else Store.balance(w).money(w.currency)
                                )
                            },
                            onClick = { menu = false }, enabled = false
                        )
                        DropdownMenuItem(text = { Text("🧹 Xóa cuộc trò chuyện") }, onClick = { Store.resetChat(wid); menu = false })
                    }
                }
            }
            HorizontalDivider(color = Lilac)
            // ---- Tin nhắn
            LazyColumn(
                Modifier.weight(1f).padding(horizontal = 16.dp), state = list,
                contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(chat) { m ->
                    val align = if (m.fromUser) Alignment.End else Alignment.Start
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = align, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box {
                            Surface(
                                color = if (m.fromUser) UserBubble else Lilac,
                                shape = RoundedCornerShape(
                                    topStart = 20.dp, topEnd = 20.dp,
                                    bottomStart = if (m.fromUser) 20.dp else 6.dp, bottomEnd = if (m.fromUser) 6.dp else 20.dp
                                ),
                                // ấn giữ một tin nhắn để sao chép
                                modifier = Modifier.widthIn(max = maxBubble).combinedClickable(onClick = {}, onLongClick = { copyMenu = m })
                            ) { BubbleText(m) }
                            DropdownMenu(expanded = copyMenu === m, onDismissRequest = { copyMenu = null }) {
                                DropdownMenuItem(text = { Text("📋 Sao chép") }, onClick = { copyText(m.text); copyMenu = null })
                            }
                        }
                        if (!m.typing) m.pending.forEach { PendingCard(it) }
                        m.retry?.let { rt -> TextButton(onClick = rt) { Text("🔄 Thử lại") } }
                    }
                }
                if (chat.size <= 1 && !busy) item { QuickChips(onVoice = { onMic() }, onAsk = { send(it) }) }
                item {
                    if (busy) Text("${Store.aiName} đang nghĩ…", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
                    else Spacer(Modifier.height(2.dp))
                }
            }
            // ---- Ô nhập
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    input, { input = it }, Modifier.weight(1f),
                    placeholder = { Text("Nhập nội dung...", color = Muted) }, maxLines = 3,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Lilac, unfocusedContainerColor = Lilac,
                        focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent
                    )
                )
                Spacer(Modifier.width(8.dp))
                RoundBtn(onClick = { onMic() }, bg = Lilac, size = 48.dp) { MicIcon(Fresh, Modifier.size(22.dp)) }
                Spacer(Modifier.width(8.dp))
                RoundBtn(onClick = { send(input) }, bg = if (busy) Muted else Fresh, size = 48.dp) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Gửi", tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
        }
        if (recording) RecordingOverlay(onStop = { stopRec() }, onCancel = { cancelRec() })
    }
}
