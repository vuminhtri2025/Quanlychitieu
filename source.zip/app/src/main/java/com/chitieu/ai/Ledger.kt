@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MonthBar(off: Int, onChange: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Paper, RoundedCornerShape(18.dp)).padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { onChange(off - 1) }) { Text("◀", color = Muted) }
        Text(SimpleDateFormat("'Tháng' MM/yyyy", Locale.US).format(monthStart(off).time), fontWeight = FontWeight.SemiBold)
        IconButton(onClick = { onChange(off + 1) }, enabled = off < 0) { Text("▶", color = if (off < 0) Charcoal else Lilac) }
    }
}

@Composable
fun TxRow(t: Tx, signed: Boolean = false, onClick: () -> Unit) {
    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    val isT = t.transferId != 0L
    val legOut = if (isT) Store.txs.firstOrNull { it.transferId == t.transferId && !it.income } else null
    val legIn = if (isT) Store.txs.firstOrNull { it.transferId == t.transferId && it.income } else null
    val title = if (isT) "Chuyển ví" else t.category
    val wallet = if (isT) "${Store.walletName(legOut?.walletId ?: 0L)} → ${Store.walletName(legIn?.walletId ?: 0L)}" else Store.walletName(t.walletId)
    val sub = df.format(Date(t.time)) + " • " + wallet +
        (if (t.note.isNotBlank()) " • ${t.note}" else "") +
        (if (!t.report && t.debtId == 0L) " • không tính báo cáo" else "")
    val showSign = !isT || signed
    val color = if (isT && !signed) Blue else if (t.income) Fresh else Coral
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBubble(catEmoji(t.category), catColor(t.category))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(sub, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                if (showSign) (if (t.income) "+" else "-") + t.fmt() else t.fmt(),
                color = color, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, softWrap = false
            )
        }
    }
}
