@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MonthBar(off: Int, onChange: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Paper, RoundedCornerShape(18.dp)).padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { onChange(off - 1) }) { Text("◀", color = Muted) }
        Text(SimpleDateFormat("'Tháng' MM/yyyy", Locale.US).format(monthStart(off).time), fontWeight = FontWeight.SemiBold)
        IconButton(onClick = { onChange(off + 1) }, enabled = off < 0) { Text("▶", color = if (off < 0) Charcoal else Lilac) }
    }
}

@Composable
fun TxRow(t: Tx, onClick: () -> Unit) {
    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    val isT = t.transferId != 0L
    val toName = if (isT) Store.walletName(Store.txs.firstOrNull { it.transferId == t.transferId && it.income }?.walletId ?: 0L) else ""
    val title = if (isT) "Chuyển ví" else t.category
    val wallet = if (isT) "${Store.walletName(t.walletId)} → $toName" else Store.walletName(t.walletId)
    val sub = df.format(Date(t.time)) + " • " + wallet +
        (if (t.note.isNotBlank()) " • ${t.note}" else "") +
        (if (!t.report && t.debtId == 0L) " • không tính báo cáo" else "")
    val color = if (isT) Muted else if (t.income) Fresh else Coral
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBubble(catEmoji(t.category), catColor(t.category))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(sub, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                if (isT) t.fmt() else (if (t.income) "+" else "-") + t.fmt(),
                color = color, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, softWrap = false
            )
        }
    }
}

@Composable
fun HistoryScreen() {
    var off by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    var transferring by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val all = txsOfMonth(off, true).filter { !(it.transferId != 0L && it.income) }
    val list = when (filter) {
        1 -> all.filter { it.income && it.transferId == 0L }
        2 -> all.filter { !it.income && it.transferId == 0L }
        3 -> all.filter { it.transferId != 0L }
        else -> all
    }.sortedByDescending { it.time }
    val rep = txsOfMonth(off)
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Sổ giao dịch") {
            RoundBtn(onClick = { transferring = true }, bg = Lilac) { Text("🔁", fontSize = 20.sp) }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { PillTabs(listOf("Tất cả", "Thu", "Chi", "Chuyển"), filter) { filter = it } }
            item { MonthBar(off) { off = it } }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SumCard("Thu", "+" + sumByCur(rep.filter { it.income }).show(), Fresh, FreshSoft, Modifier.weight(1f))
                    SumCard("Chi", "-" + sumByCur(rep.filter { !it.income }).show(), Coral, CoralSoft, Modifier.weight(1f))
                }
            }
            if (list.isEmpty()) item { Text("Chưa có giao dịch.", color = Muted, modifier = Modifier.padding(16.dp)) }
            items(list, key = { it.id }) { t ->
                TxRow(t) {
                    if (t.debtId == 0L) editing = t
                    else Toast.makeText(ctx, "Khoản vay/nợ: sửa trong tab Nợ", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    editing?.let { if (it.transferId != 0L) TransferDialog(it) { editing = null } else EditTxDialog(it) { editing = null } }
    if (transferring) TransferDialog(null) { transferring = false }
}
