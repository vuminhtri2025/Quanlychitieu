package com.chitieu.ai

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Số giao dịch tự quét từ thông báo đang chờ người dùng xác nhận. */
fun pendingReviewCount(): Int = Store.reviewIds.count { id -> Store.txs.any { it.id == id } }

/**
 * Trang "Chờ xác nhận" trong Tài khoản: liệt kê các giao dịch AI quét từ thông báo để bạn
 * kiểm tra và xác nhận từng giao dịch một (✔ đúng / ✏️ sửa, thêm ảnh hóa đơn / 🗑 xóa).
 */
@Composable
fun ReviewSettings() {
    val items = Store.reviewIds.mapNotNull { id -> Store.txs.firstOrNull { it.id == id } }
    var editing by remember { mutableStateOf<Tx?>(null) }

    // dọn các giao dịch đã bị xóa ở nơi khác
    LaunchedEffect(Store.reviewIds.size, Store.txs.size) {
        val valid = Store.txs.map { it.id }.toSet()
        if (Store.reviewIds.any { it !in valid }) { Store.reviewIds.removeAll { it !in valid }; Store.save() }
    }

    Section("Giao dịch chờ xác nhận (${items.size})") {
        Text(
            "Đây là các giao dịch AI quét từ thông báo ngân hàng/ví. Hãy kiểm tra số tiền, mục, ví rồi xác nhận từng giao dịch. " +
                "Giao dịch chưa xác nhận vẫn được tính vào số dư.",
            style = MaterialTheme.typography.bodySmall
        )
        if (items.isEmpty()) Text("✅ Không có giao dịch nào đang chờ xác nhận.")
        else OutlinedButton(onClick = { Store.reviewIds.clear(); Store.save() }) { Text("✔ Xác nhận tất cả (${items.size})") }
    }
    items.forEach { t -> ReviewCard(t, onEdit = { editing = t }) }

    editing?.let { t ->
        // mở xem/sửa xong coi như đã kiểm tra
        EditTxDialog(t) { Store.reviewIds.remove(t.id); Store.save(); editing = null }
    }
}

@Composable
private fun ReviewCard(t: Tx, onEdit: () -> Unit) {
    val df = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US) }
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                (if (t.income) "+" else "-") + t.fmt(), color = if (t.income) Fresh else Coral,
                fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                catEmoji(t.category) + " " + t.category + " • " + Store.walletName(t.walletId) + if (t.photo.isNotBlank()) "  🧾" else "",
                fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(df.format(Date(t.time)), color = Muted, fontSize = 12.sp, lineHeight = 16.sp)
            if (t.note.isNotBlank()) Text(t.note.trim(), fontSize = 13.sp, lineHeight = 18.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { Store.reviewIds.remove(t.id); Store.save() }) { Text("✔ Xác nhận", maxLines = 1, softWrap = false) }
                TextButton(onClick = onEdit) { Text("✏️ Sửa", maxLines = 1, softWrap = false) }
                TextButton(onClick = { Store.txs.remove(t); Store.reviewIds.remove(t.id); Store.save() }) {
                    Text("🗑 Xóa", color = Coral, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}
