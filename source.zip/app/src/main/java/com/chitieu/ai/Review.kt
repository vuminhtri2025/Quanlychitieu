package com.chitieu.ai

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Hộp thoại hiện khi mở app: liệt kê các giao dịch do AI tự quét từ thông báo để bạn kiểm tra lại
 * (đúng / sửa / xóa). Giao dịch chưa kiểm tra sẽ được nhắc lại ở lần mở app sau.
 */
@Composable
fun ReviewDialog() {
    if (!Store.showReview) return
    val items = Store.reviewIds.mapNotNull { id -> Store.txs.firstOrNull { it.id == id } }
    var editing by remember { mutableStateOf<Tx?>(null) }

    // dọn các giao dịch đã bị xóa ở nơi khác; hết việc thì tự đóng
    LaunchedEffect(Store.reviewIds.size, Store.txs.size) {
        val valid = Store.txs.map { it.id }.toSet()
        if (Store.reviewIds.any { it !in valid }) { Store.reviewIds.removeAll { it !in valid }; Store.save() }
        if (Store.reviewIds.isEmpty()) Store.showReview = false
    }
    if (items.isEmpty()) return

    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    AlertDialog(
        onDismissRequest = { Store.showReview = false },
        title = { Text("🔔 Kiểm tra giao dịch tự quét (${items.size})") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Các giao dịch này do AI đọc từ thông báo ngân hàng/ví. Hãy kiểm tra số tiền, mục và ví đã đúng chưa.",
                    style = MaterialTheme.typography.bodySmall
                )
                items.forEach { t ->
                    AppCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                (if (t.income) "+" else "-") + t.fmt(), color = if (t.income) Fresh else Coral,
                                fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                catEmoji(t.category) + " " + t.category + " • " + Store.walletName(t.walletId),
                                fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                (if (t.note.isNotBlank()) t.note.trim() + " • " else "") + df.format(Date(t.time)),
                                color = Muted, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { Store.reviewIds.remove(t.id); Store.save() }) { Text("✔ Đúng", maxLines = 1, softWrap = false) }
                                TextButton(onClick = { editing = t }) { Text("✏️ Sửa", maxLines = 1, softWrap = false) }
                                TextButton(onClick = { Store.txs.remove(t); Store.reviewIds.remove(t.id); Store.save() }) {
                                    Text("🗑 Xóa", color = Coral, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { Store.reviewIds.clear(); Store.save(); Store.showReview = false }) { Text("✔ Xác nhận tất cả") }
        },
        dismissButton = { TextButton(onClick = { Store.showReview = false }) { Text("Để sau") } }
    )
    editing?.let { t ->
        EditTxDialog(t) { Store.reviewIds.remove(t.id); Store.save(); editing = null }   // đã mở xem/sửa = đã kiểm tra
    }
}
