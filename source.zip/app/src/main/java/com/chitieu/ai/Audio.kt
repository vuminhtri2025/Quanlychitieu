package com.chitieu.ai

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

const val RATE = 16000

/** Ghi âm PCM 16kHz mono để gửi thẳng cho Gemini nghe. */
class Recorder {
    private val buf = ByteArrayOutputStream()
    @Volatile private var on = false
    /** Biên độ lớn nhất của đoạn âm thanh vừa thu (0..32767), dùng để tự dừng khi nói xong. */
    @Volatile var level = 0
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start() {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192))
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); error("micro đang bị chặn hoặc bị app khác chiếm") }
        buf.reset()
        r.startRecording()
        on = true
        thread = Thread {
            val b = ByteArray(4096)
            while (on) {
                val n = r.read(b, 0, b.size)
                if (n > 0) {
                    synchronized(buf) { buf.write(b, 0, n) }
                    var peak = 0
                    var k = 0
                    while (k + 1 < n) {
                        val s = ((b[k + 1].toInt() shl 8) or (b[k].toInt() and 0xFF)).toShort().toInt()
                        val v = if (s < 0) -s else s
                        if (v > peak) peak = v
                        k += 2
                    }
                    level = peak
                } else if (n < 0) break
            }
            try { r.stop() } catch (_: Exception) {}
            r.release()
        }.also { it.start() }
    }

    fun stop(): ByteArray {
        on = false
        thread?.join(1500)
        return synchronized(buf) { buf.toByteArray() }
    }
}

/** Mic bị chặn thường trả về toàn số 0 (im lặng). */
fun hasSound(pcm: ByteArray): Boolean {
    if (pcm.size < RATE) return false
    val bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
    var peak = 0
    while (bb.remaining() >= 2) { val v = abs(bb.short.toInt()); if (v > peak) peak = v }
    return peak > 300
}

fun wav(pcm: ByteArray): ByteArray {
    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
    h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray()).put("fmt ".toByteArray())
        .putInt(16).putShort(1).putShort(1).putInt(RATE).putInt(RATE * 2).putShort(2).putShort(16)
        .put("data".toByteArray()).putInt(pcm.size)
    return h.array() + pcm
}
