package com.chitieu.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Một giọng đọc tiếng Việt có trên máy. */
class VoiceOpt(val name: String, val label: String)

/** Đọc phản hồi bằng giọng nói (Text-to-Speech của máy, tiếng Việt). */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var queued: String? = null
    private var warned = false

    /** Danh sách giọng tiếng Việt của máy (hiện trong Cài đặt). */
    var voices by mutableStateOf<List<VoiceOpt>>(emptyList())
        private set
    /** 0 = đang tải, 1 = đã có danh sách, 2 = máy không có giọng tiếng Việt. */
    var voicesState by mutableStateOf(0)
        private set

    // Giải phóng bộ đọc khi không dùng 60 giây (bộ đọc là một dịch vụ riêng, giữ mãi sẽ tốn RAM/pin)
    private val handler = Handler(Looper.getMainLooper())
    private val idle = Runnable {
        val e = tts
        if (e != null && e.isSpeaking) touch() else { try { e?.shutdown() } catch (_: Exception) {}; tts = null; ready = false }
    }
    private fun touch() { handler.removeCallbacks(idle); handler.postDelayed(idle, 60_000L) }

    private val URL = Regex("""https?://\S+""")
    private val NOISE = Regex("""[\p{So}\p{Sk}\u200d\ufe0f*_#`~>|\[\]{}]+""")
    private val SPACES = Regex("""\s+""")

    fun speedValue() = when (Store.ttsSpeed) { "Chậm" -> 0.85f; "Nhanh" -> 1.25f; else -> 1.0f }
    fun pitchValue() = when (Store.ttsPitch) { "Trầm" -> 0.8f; "Cao" -> 1.25f; else -> 1.0f }

    /** Bỏ emoji, markdown, link để máy đọc tự nhiên; cắt gọn nếu quá dài. */
    fun clean(s: String): String {
        var t = NOISE.replace(URL.replace(s, " "), " ")
        t = SPACES.replace(t, " ").trim()
        if (t.length > 500) {
            val cut = t.take(500)
            val end = maxOf(cut.lastIndexOf('.'), cut.lastIndexOf('!'), cut.lastIndexOf('?'))
            t = if (end > 100) cut.take(end + 1) else cut
        }
        return t
    }

    /** Khởi tạo bộ đọc (nếu chưa) và nạp danh sách giọng. Gọi trên luồng chính. */
    fun prepare(ctx: Context) {
        if (tts != null) return
        val app = ctx.applicationContext
        tts = TextToSpeech(app) { status ->
            val e = tts
            if (status == TextToSpeech.SUCCESS && e != null) {
                val r = e.setLanguage(Locale("vi", "VN"))
                ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
            if (ready && e != null) {
                loadVoices(e)
                queued?.let { say(e, it) }
            } else {
                e?.shutdown()
                tts = null
                ready = false
                voices = emptyList()
                voicesState = 2
                if (queued != null && !warned) {
                    warned = true
                    Toast.makeText(
                        app,
                        "Máy chưa có giọng đọc tiếng Việt. Vào Cài đặt → Chuyển văn bản thành giọng nói để chọn/tải giọng Việt.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            queued = null
        }
    }

    private fun loadVoices(e: TextToSpeech) {
        val list = try {
            e.voices?.filter { it.locale.language == "vi" }?.sortedBy { it.name } ?: emptyList()
        } catch (_: Exception) { emptyList() }
        voices = list.mapIndexed { i, v ->
            val code = v.name.substringAfter("-x-", v.name).substringBefore("-")
            VoiceOpt(v.name, "Giọng ${i + 1} • $code" + if (v.isNetworkConnectionRequired) " • cần mạng" else "")
        }
        voicesState = 1
        touch()
    }

    /** Đọc đoạn văn bản (gọi trên luồng chính). Lần đầu máy cần vài trăm ms để khởi tạo giọng đọc. */
    fun speak(ctx: Context, text: String) {
        val t = clean(text)
        if (t.isBlank()) return
        // giọng AI Gemini (nam/nữ, Bắc/Nam); lỗi thì tự quay về giọng của máy
        if (Store.ttsEngine == "gemini" && Store.apiKey.isNotBlank()) {
            AiVoice.speak(ctx, t) { speakDevice(ctx, t) }
            return
        }
        speakDevice(ctx, t)
    }

    private fun speakDevice(ctx: Context, t: String) {
        val engine = tts
        if (engine != null && ready) { say(engine, t); return }
        queued = t
        if (engine == null) prepare(ctx)   // nếu đang khởi tạo thì câu này sẽ được đọc khi xong
    }

    private fun say(e: TextToSpeech, t: String) {
        try {
            val want = Store.ttsVoice
            val v = if (want.isBlank()) null else e.voices?.firstOrNull { it.name == want }
            if (v != null) e.setVoice(v) else e.setLanguage(Locale("vi", "VN"))   // setLanguage = về giọng mặc định
        } catch (_: Exception) { }
        e.setSpeechRate(speedValue())
        e.setPitch(pitchValue())
        e.speak(t, TextToSpeech.QUEUE_FLUSH, null, "chitieu")
        touch()
    }

    /** Dừng đọc (vd khi người dùng bắt đầu nói tiếp). */
    fun stop() {
        queued = null
        AiVoice.stop()
        try { tts?.stop() } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ nội dung được đọc

    /** Số tiền đọc theo kiểu người Việt: "1 triệu 250 nghìn đồng". */
    fun spokenMoney(amount: Long, cur: String): String {
        if (cur != "VND") return "$amount $cur"
        if (amount <= 0L) return "0 đồng"
        var r = amount
        val parts = ArrayList<String>()
        val ty = r / 1_000_000_000L; r %= 1_000_000_000L
        val tr = r / 1_000_000L; r %= 1_000_000L
        val ng = r / 1_000L; r %= 1_000L
        if (ty > 0) parts.add("$ty tỷ")
        if (tr > 0) parts.add("$tr triệu")
        if (ng > 0) parts.add("$ng nghìn")
        if (r > 0) parts.add("$r")
        return parts.joinToString(" ") + " đồng"
    }

    private fun describe(p: Pending): String {
        val money = spokenMoney(p.amount, Store.cur(p.walletId))
        val wallet = Store.walletName(p.walletId)
        val who = p.person.trim()
        val body = when (p.kind) {
            "transfer" -> "chuyển $money từ ví $wallet sang ví ${Store.walletName(p.toWalletId)}"
            "borrow" -> "vay ${if (who.isNotEmpty()) "$who " else ""}$money, ví $wallet"
            "lend" -> "cho ${if (who.isNotEmpty()) "$who " else ""}vay $money, ví $wallet"
            "repay" -> "trả nợ ${if (who.isNotEmpty()) "$who " else ""}$money, ví $wallet"
            "collect" -> "thu nợ ${if (who.isNotEmpty()) "$who " else ""}$money, ví $wallet"
            else -> "${if (p.income) "thu" else "chi"} $money, mục ${p.category}, ví $wallet"
        }
        return if (p.saved) "Đã ghi $body" else "Mình hiểu là $body. Bạn kiểm tra rồi bấm lưu nhé"
    }

    /** Chọn nội dung đọc theo cài đặt: xác nhận ngắn (mặc định), lời nhắn của AI, hoặc cả hai. */
    fun compose(r: Gemini.Result): String {
        if (Store.ttsMode == "ai" || r.items.isEmpty()) return r.reply
        val shown = r.items.take(3).joinToString(". ") { describe(it) }
        val more = r.items.size - 3
        val confirm = if (more > 0) "$shown. Và $more giao dịch khác." else "$shown."
        return if (Store.ttsMode == "both") r.reply.trim() + " " + confirm else confirm
    }
}
