package com.chitieu.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * AI dự phòng khi Gemini lỗi: Groq (API tương thích OpenAI, có gói miễn phí).
 * - Giọng nói: Whisper large-v3-turbo chép thành chữ.
 * - Hiểu câu và tách giao dịch: model Llama (chế độ JSON).
 */
object Groq {
    const val DEFAULT_MODEL = "llama-3.3-70b-versatile"
    private const val STT_MODEL = "whisper-large-v3-turbo"
    private const val BASE = "https://api.groq.com/openai/v1"
    private val BACKUP_MODELS = listOf("llama-3.1-8b-instant")

    /** Tên model đã chuẩn hóa; sai định dạng/để trống thì dùng mặc định. */
    fun modelId(): String {
        val m = Store.groqModel.trim()
        return if (Regex("^[A-Za-z0-9][A-Za-z0-9._/-]{0,80}$").matches(m)) m else DEFAULT_MODEL
    }

    private fun chain() = (listOf(modelId()) + BACKUP_MODELS).distinct()

    private fun errText(code: Int, raw: String): String {
        val parsed = try { JSONObject(raw).getJSONObject("error").optString("message") } catch (_: Exception) { "" }
        val msg = parsed.ifBlank { raw.take(160) }.trim()
        val hint = when {
            code == 401 -> " Kiểm tra lại Groq API key."
            code == 429 -> " Đã hết hạn mức miễn phí hoặc gọi quá nhanh."
            else -> ""
        }
        return "Groq $code: ${msg.take(140)}.$hint".replace("..", ".")
    }

    private fun open(path: String): HttpURLConnection {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Authorization", "Bearer " + Store.groqKey.trim())
        c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        return c
    }

    private fun read(c: HttpURLConnection): Pair<Int, String> {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
        return Pair(code, stream.bufferedReader().use { it.readText() })
    }

    private fun postJson(path: String, body: JSONObject): Pair<Int, String> {
        val c = open(path)
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        return read(c)
    }

    private fun postMultipart(path: String, fields: Map<String, String>, fileName: String, mime: String, bytes: ByteArray): Pair<Int, String> {
        val boundary = "----chitieu" + System.currentTimeMillis()
        val c = open(path)
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { out ->
            fields.forEach { (k, v) ->
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n".toByteArray())
            }
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$fileName\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
            out.write(bytes)
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        return read(c)
    }

    /** Hỏi model chữ ở chế độ JSON, trả về chuỗi JSON. Tự thử lại khi lỗi tạm thời và đổi sang model nhẹ dự phòng. */
    suspend fun chatJson(system: String, msgs: List<Pair<String, String>>, temperature: Double): String = withContext(Dispatchers.IO) {
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        var lastErr: Exception = IllegalStateException("Không gọi được Groq")
        for (model in chain()) {
            for (attempt in 0 until 2) {
                try {
                    val body = JSONObject().put("model", model).put("messages", arr)
                        .put("temperature", temperature.coerceIn(0.0, 1.5))
                        .put("response_format", JSONObject().put("type", "json_object"))
                    val (code, resp) = postJson("/chat/completions", body)
                    if (code in 200..299) {
                        return@withContext JSONObject(resp).getJSONArray("choices").getJSONObject(0)
                            .getJSONObject("message").getString("content")
                    }
                    lastErr = ApiException(code, errText(code, resp))
                    val transient = code == 408 || code == 429 || code >= 500
                    if (transient) { if (attempt == 0) delay(1500L); continue }
                    if (code == 404 || (code == 400 && resp.contains("model", true))) break   // model không còn -> model kế
                    throw lastErr
                } catch (e: IOException) {
                    lastErr = e
                    if (attempt == 0) delay(1500L)
                }
            }
        }
        throw lastErr
    }

    /** Whisper chép giọng nói tiếng Việt (file WAV) thành chữ. [hint] giúp nghe đúng tên ví và cách nói tiền. */
    suspend fun transcribe(wav: ByteArray, hint: String): String = withContext(Dispatchers.IO) {
        var lastErr: Exception = IllegalStateException("Không gọi được Groq")
        for (attempt in 0 until 2) {
            try {
                val (code, resp) = postMultipart(
                    "/audio/transcriptions",
                    mapOf("model" to STT_MODEL, "language" to "vi", "response_format" to "json", "temperature" to "0", "prompt" to hint.take(400)),
                    "voice.wav", "audio/wav", wav
                )
                if (code in 200..299) return@withContext JSONObject(resp).optString("text").trim()
                lastErr = ApiException(code, errText(code, resp))
                val transient = code == 408 || code == 429 || code >= 500
                if (!transient) throw lastErr
                if (attempt == 0) delay(1500L)
            } catch (e: IOException) {
                lastErr = e
                if (attempt == 0) delay(1500L)
            }
        }
        throw lastErr
    }
}
