package com.chitieu.app.data

/** Du lieu mac dinh lan dau mo app (nhom giong anh mau). */
suspend fun seedIfNeeded(dao: AppDao) {
    if (dao.walletCount() == 0) {
        dao.insertWallet(Wallet(name = "Tiền Mặt"))
        dao.insertWallet(Wallet(name = "Techcom Bank"))
    }
    if (dao.categoryCount() == 0) {
        suspend fun group(name: String, type: String, kids: List<String>) {
            val id = dao.insertCategory(Category(name = name, type = type))
            for (k in kids) {
                dao.insertCategory(Category(name = k, parentId = id, type = type))
            }
        }
        group(
            "1. Chi tiêu chung gia đình", T.EXPENSE,
            listOf(
                "1.1. Phí quản lý chung cư",
                "1.2. Tiền trả nợ chung cư",
                "1.3. Ăn uống",
                "1.4. Điện, nước, internet",
                "1.5. Đi lại, xăng xe"
            )
        )
        group("2. Chi tiêu của vợ", T.EXPENSE, emptyList())
        group(
            "3. Chi tiêu cá nhân", T.EXPENSE,
            listOf("3.1. Tiền cắt tóc", "3.2. Đồ chơi, sở thích", "3.3. Cà phê, ăn ngoài")
        )
        group("4. Chi phí phát sinh", T.EXPENSE, emptyList())
        group("5. Tiết kiệm và đầu tư", T.EXPENSE, emptyList())

        group("Lương", T.INCOME, emptyList())
        group("Thưởng", T.INCOME, emptyList())
        group("Thu nhập khác", T.INCOME, emptyList())

        group("Đi vay", T.LOAN_IN, emptyList())
        group("Thu nợ", T.LOAN_IN, emptyList())
        group("Cho vay", T.LOAN_OUT, emptyList())
        group("Trả nợ", T.LOAN_OUT, emptyList())
    }
}
