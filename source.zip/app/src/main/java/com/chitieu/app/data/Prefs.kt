package com.chitieu.app.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("chitieu_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) { sp.edit().putString("api_key", v).apply() }

    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { sp.edit().putString("model", v).apply() }

    var userName: String
        get() = sp.getString("user_name", "Tôi") ?: "Tôi"
        set(v) { sp.edit().putString("user_name", v).apply() }

    var hideBalance: Boolean
        get() = sp.getBoolean("hide_balance", false)
        set(v) { sp.edit().putBoolean("hide_balance", v).apply() }
}
