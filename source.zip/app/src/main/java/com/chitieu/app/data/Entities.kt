package com.chitieu.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Cac loai giao dich / nhom. */
object T {
    const val EXPENSE = "EXPENSE"
    const val INCOME = "INCOME"
    const val LOAN_IN = "LOAN_IN"   // di vay, thu no (tien vao)
    const val LOAN_OUT = "LOAN_OUT" // cho vay, tra no (tien ra)

    fun isIn(type: String): Boolean = type == INCOME || type == LOAN_IN
}

@Entity(tableName = "wallets")
data class Wallet(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val initialBalance: Long = 0
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long? = null,
    val type: String
)

@Entity(tableName = "transactions")
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val walletId: Long,
    val categoryId: Long,
    val amount: Long,
    val type: String,
    val note: String = "",
    val date: Long
)

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryId: Long,
    val amount: Long
)
