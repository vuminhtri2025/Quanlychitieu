package com.chitieu.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.chitieu.app.data.T
import java.util.Calendar

@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController, onAi: () -> Unit) {
    val wallets by vm.wallets.collectAsState()
    val txns by vm.txns.collectAsState()
    val cats by vm.categories.collectAsState()
    val ctx = LocalContext.current

    val total = remember(wallets, txns) { wallets.sumOf { walletBalance(it, txns) } }
    val month = monthRef(0)
    val monthTx = txns.filter { it.date >= month.start && it.date < month.end }
    val spent = monthTx.filter { it.type == T.EXPENSE }.sumOf { it.amount }
    val income = monthTx.filter { T.isIn(it.type) }.sumOf { it.amount }
    val byId = cats.associateBy { it.id }
    val groups = monthTx.filter { it.type == T.EXPENSE }
        .groupBy { t -> byId[t.categoryId]?.let { c -> topCategory(c, byId).name } ?: "Khác" }
        .map { it.key to it.value.sumOf { t -> t.amount } }
        .sortedByDescending { it.second }
        .take(4)
    val dayNow = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tong so du
        item {
            Row(verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (vm.hideBalance) "••••••••" else moneyD(total),
                            fontSize = 36.sp, fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { vm.toggleHide() }) {
                            Icon(
                                if (vm.hideBalance) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = "Ẩn/hiện số dư"
                            )
                        }
                    }
                    Text("Tổng số dư", color = Muted, fontSize = 18.sp)
                }
                IconButton(onClick = { nav.navigate("search") }) {
                    Icon(Icons.Filled.Search, contentDescription = "Tìm kiếm")
                }
                IconButton(onClick = {
                    Toast.makeText(ctx, "Chưa có thông báo mới", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(Icons.Filled.Notifications, contentDescription = "Thông báo")
                }
            }
        }
        // Vi cua toi
        item {
            AppCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ví của tôi", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Xem tất cả", color = Green, fontSize = 18.sp,
                        modifier = Modifier.clickable { nav.navigate("wallets") }
                    )
                }
                Spacer(Modifier.height(12.dp))
                for (w in wallets) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WalletIcon(50.dp)
                        Spacer(Modifier.width(16.dp))
                        Text(w.name, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        Text(
                            if (vm.hideBalance) "•••" else moneyD(walletBalance(w, txns)),
                            fontSize = 20.sp
                        )
                    }
                }
            }
        }
        // Money Insider
        item { SectionHeader("Money Insider") }
        item {
            AppCard {
                Text("Chi tiêu tháng này", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Tổng đã chi  ", color = Muted, fontSize = 18.sp)
                    Text(money(spent), color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Trung bình " + money(spent / dayNow.coerceAtLeast(1)) + " /ngày",
                    color = Muted, fontSize = 16.sp
                )
                Spacer(Modifier.height(12.dp))
                if (groups.isEmpty()) {
                    Text("Chưa có khoản chi nào trong tháng này.", color = Muted, fontSize = 16.sp)
                } else {
                    val max = groups.first().second.coerceAtLeast(1)
                    for (g in groups) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(g.first, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1)
                            Text(money(g.second), fontSize = 16.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { g.second.toFloat() / max.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(6.dp),
                            color = Red, trackColor = BarBg
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                }
                Button(
                    onClick = { nav.navigate("txns") },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F3326), contentColor = Green)
                ) { Text("Xu hướng chi tiêu", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            }
        }
        // Them bang AI / giong noi
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color(0xFFFFC107))
                    Spacer(Modifier.width(10.dp))
                    Text("Thêm giao dịch bằng AI", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Nói hoặc gõ: “Hôm nay ăn phở 50k, đổ xăng 100k trả tiền mặt”",
                    color = Muted, fontSize = 16.sp
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onAi,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White)
                ) { Text("Nói / nhập ngay", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            }
        }
        // Bao cao thang nay
        item { SectionHeader("Báo cáo tháng này", "Xem báo cáo") { nav.navigate("txns") } }
        item {
            AppCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tổng đã chi", color = Muted, fontSize = 18.sp)
                        Text(money(spent), color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tổng thu", color = Muted, fontSize = 18.sp)
                        Text(money(income), color = Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BarBg))
                Spacer(Modifier.height(8.dp))
                Text(
                    "Chênh lệch: " + money(income - spent),
                    modifier = Modifier.fillMaxWidth(), fontSize = 18.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
