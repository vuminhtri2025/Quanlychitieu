package com.chitieu.app.ui

import com.chitieu.app.data.Category
import com.chitieu.app.data.T
import com.chitieu.app.data.Txn
import com.chitieu.app.data.Wallet
import java.util.Calendar
import java.util.Locale

fun money(v: Long): String {
    val s = String.format(Locale.US, "%,d", Math.abs(v))
    return if (v < 0) "-$s" else s
}

fun moneyD(v: Long): String = money(v) + " đ"

fun startOfDay(ms: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

class MonthRef(val year: Int, val month: Int) { // month: 0..11
    val label: String get() = String.format(Locale.US, "%02d/%d", month + 1, year)
    val start: Long
        get() {
            val c = Calendar.getInstance()
            c.clear()
            c.set(year, month, 1, 0, 0, 0)
            return c.timeInMillis
        }
    val end: Long
        get() {
            val c = Calendar.getInstance()
            c.clear()
            c.set(year, month, 1, 0, 0, 0)
            c.add(Calendar.MONTH, 1)
            return c.timeInMillis
        }
}

/** offset = 0: thang nay, -1: thang truoc, ... */
fun monthRef(offset: Int): MonthRef {
    val c = Calendar.getInstance()
    c.set(Calendar.DAY_OF_MONTH, 1)
    c.add(Calendar.MONTH, offset)
    return MonthRef(c.get(Calendar.YEAR), c.get(Calendar.MONTH))
}

fun dayOfMonth(ms: Long): Int {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    return c.get(Calendar.DAY_OF_MONTH)
}

fun weekdayVi(ms: Long): String {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    return when (c.get(Calendar.DAY_OF_WEEK)) {
        Calendar.MONDAY -> "Thứ Hai"
        Calendar.TUESDAY -> "Thứ Ba"
        Calendar.WEDNESDAY -> "Thứ Tư"
        Calendar.THURSDAY -> "Thứ Năm"
        Calendar.FRIDAY -> "Thứ Sáu"
        Calendar.SATURDAY -> "Thứ Bảy"
        else -> "Chủ Nhật"
    }
}

fun monthYearVi(ms: Long): String {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    return "tháng ${c.get(Calendar.MONTH) + 1} ${c.get(Calendar.YEAR)}"
}

fun dateVi(ms: Long): String {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    return String.format(
        Locale.US, "%02d/%02d/%d",
        c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR)
    )
}

fun timeVi(ms: Long): String {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    return String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
}

fun signedAmount(t: Txn): Long = if (T.isIn(t.type)) t.amount else -t.amount

fun walletBalance(w: Wallet, txns: List<Txn>): Long =
    w.initialBalance + txns.filter { it.walletId == w.id }.sumOf { signedAmount(it) }

/** Nhom goc (cha) cua mot nhom. */
fun topCategory(c: Category, byId: Map<Long, Category>): Category {
    val p = c.parentId
    return if (p != null) (byId[p] ?: c) else c
}
