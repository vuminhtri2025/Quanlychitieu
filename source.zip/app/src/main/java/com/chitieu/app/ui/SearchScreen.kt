package com.chitieu.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun SearchScreen(vm: AppViewModel, nav: NavController) {
    val txns by vm.txns.collectAsState()
    val cats by vm.categories.collectAsState()
    val wallets by vm.wallets.collectAsState()
    val byId = remember(cats) { cats.associateBy { it.id } }
    val walletById = remember(wallets) { wallets.associateBy { it.id } }
    var q by remember { mutableStateOf("") }

    val result = if (q.isBlank()) {
        emptyList()
    } else {
        txns.filter { t ->
            t.note.contains(q, ignoreCase = true) ||
                (byId[t.categoryId]?.name ?: "").contains(q, ignoreCase = true) ||
                t.amount.toString() == q.trim()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = "Tìm kiếm", onBack = { nav.popBackStack() })
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            label = { Text("Ghi chú, nhóm hoặc số tiền") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(result, key = { it.id }) { t ->
                TxnRow(t, byId[t.categoryId], walletById[t.walletId]) {
                    nav.navigate("add?id=" + t.id)
                }
            }
        }
    }
}
