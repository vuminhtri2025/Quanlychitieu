package com.chitieu.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

private val mainRoutes = listOf("home", "txns", "budget", "account")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    var showMenu by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            if (route in mainRoutes) {
                BottomBar(
                    route = route,
                    onNav = { r -> goTab(nav, r) },
                    onPlus = { showMenu = true }
                )
            }
        }
    ) { pad ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(pad)
        ) {
            composable("home") { HomeScreen(vm, nav) { showAi = true } }
            composable("txns") { TransactionsScreen(vm, nav) }
            composable("budget") { BudgetScreen(vm) }
            composable("account") { AccountScreen(vm, nav) { showAi = true } }
            composable("wallets") { WalletsScreen(vm, nav) }
            composable("categories") { CategoriesScreen(vm) { nav.popBackStack() } }
            composable("settings") { SettingsScreen(vm, nav) }
            composable("search") { SearchScreen(vm, nav) }
            composable(
                "add?id={id}",
                arguments = listOf(navArgument("id") {
                    type = NavType.LongType
                    defaultValue = -1L
                })
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: -1L
                AddTxnScreen(vm, nav, id) { showAi = true }
            }
        }
    }

    if (showMenu) {
        ModalBottomSheet(
            onDismissRequest = { showMenu = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CardBg
        ) {
            Column(modifier = Modifier.padding(bottom = 24.dp)) {
                SheetItem(Icons.Filled.Edit, "Thêm giao dịch thủ công") {
                    showMenu = false
                    nav.navigate("add?id=-1")
                }
                SheetItem(Icons.Filled.AutoAwesome, "Thêm bằng AI / giọng nói") {
                    showMenu = false
                    showAi = true
                }
            }
        }
    }

    if (showAi) {
        AiSheet(
            vm = vm,
            onDismiss = { showAi = false },
            onOpenSettings = {
                showAi = false
                nav.navigate("settings")
            }
        )
    }
}

private fun goTab(nav: NavController, route: String) {
    nav.navigate(route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun SheetItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green)
        Spacer(Modifier.width(18.dp))
        Text(label, fontSize = 19.sp)
    }
}

@Composable
private fun BottomBar(route: String?, onNav: (String) -> Unit, onPlus: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().height(100.dp).background(Bg)) {
        NavigationBar(
            containerColor = BarBg,
            tonalElevation = 0.dp,
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            NavItem(route == "home", "Tổng quan", Icons.Filled.Home) { onNav("home") }
            NavItem(route == "txns", "Sổ giao dịch", Icons.Filled.AccountBalanceWallet) { onNav("txns") }
            NavigationBarItem(
                selected = false,
                onClick = {},
                enabled = false,
                icon = { Spacer(Modifier.size(24.dp)) },
                label = { Text(" ", fontSize = 12.sp) }
            )
            NavItem(route == "budget", "Ngân sách", Icons.Filled.Savings) { onNav("budget") }
            NavItem(route == "account", "Tài khoản", Icons.Filled.Person) { onNav("account") }
        }
        FloatingActionButton(
            onClick = onPlus,
            shape = CircleShape,
            containerColor = Green,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.TopCenter).size(66.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Thêm", modifier = Modifier.size(34.dp))
        }
    }
}

@Composable
private fun RowScope.NavItem(selected: Boolean, label: String, icon: ImageVector, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label, fontSize = 12.sp, maxLines = 1) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Color.White,
            selectedTextColor = Color.White,
            unselectedIconColor = Muted,
            unselectedTextColor = Muted,
            indicatorColor = Color.Transparent
        )
    )
}
