package com.chitieu.app.ai

import android.util.Base64
import com.chitieu.app.data.Category
import com.chitieu.app.data.Wallet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Goi Google AI Studio (Gemini API) bang REST de phan tich giong noi / van ban thanh giao dich. */
object GeminiClient {

    data class Item(
        val amount: Long,
        val categoryId: Long?,
        val walletId: Long?,
        val note: String,
        val daysAgo: Int,
        val time: String?
    )

    data class ParseResult(val transcript: String, val items: List<Item>)

    private suspend fun call(apiKey: String, model: String, body: JSONObject): String =
        withContext(Dispatchers.IO) {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent")
            val conn = url.openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 90000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.setRequestProperty("x-goog-api-key", apiKey.trim())
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val msg = try {
                        JSONObject(text).getJSONObject("error").getString("message")
                    } catch (e: Exception) {
                        text.take(300)
                    }
                    throw IOException("HTTP $code: $msg")
                }
                text
            } finally {
                conn.disconnect()
            }
        }

    private fun extractText(resp: String): String {
        val root = JSONObject(resp)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            throw IOException("Gemini không trả về kết quả (có thể bị chặn nội dung).")
        }
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw IOException("Gemini trả về rỗng.")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text", ""))
        }
        return sb.toString()
    }

    private fun textPart(t: String): JSONObject = JSONObject().put("text", t)

    /** Kiem tra API key / model. */
    suspend fun ping(apiKey: String, model: String): String {
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(textPart("Trả lời đúng một từ: OK")))
                )
            )
        return extractText(call(apiKey, model, body)).trim()
    }

    suspend fun parse(
        apiKey: String,
        model: String,
        categories: List<Category>,
        wallets: List<Wallet>,
        text: String?,
        wav: ByteArray?
    ): ParseResult {
        val today = SimpleDateFormat("yyyy-MM-dd (EEEE)", Locale("vi")).format(Date())
        val catLines = categories.joinToString("\n") { c -> "${c.id} | ${c.type} | ${c.name}" }
        val walletLines = wallets.joinToString("\n") { w -> "${w.id} | ${w.name}" }

        val system = StringBuilder()
        system.append("Bạn là trợ lý nhập liệu cho app quản lý chi tiêu cá nhân (tiền Việt Nam đồng).\n")
        system.append("Nhiệm vụ: nghe/đọc câu lệnh của người dùng (tiếng Việt) và trích xuất các giao dịch.\n")
        system.append("Quy tắc:\n")
        system.append("- amount: số nguyên VND, luôn dương. 'k', 'nghìn', 'ngàn' = x1.000; 'tr', 'triệu', 'củ' = x1.000.000; 'tỷ' = x1.000.000.000; 'năm chục' = 50.000; 'một triệu rưỡi' = 1.500.000.\n")
        system.append("- category_id: chọn id phù hợp nhất trong danh sách nhóm bên dưới (ưu tiên nhóm con cụ thể nếu có). Chi tiêu -> loại EXPENSE, thu nhập -> INCOME, vay/nợ -> LOAN_IN/LOAN_OUT.\n")
        system.append("- wallet_id: id ví nếu người dùng nói rõ (tiền mặt, techcom, ngân hàng...), nếu không nói thì để null.\n")
        system.append("- days_ago: 0 = hôm nay, 1 = hôm qua, 2 = hôm kia, v.v.\n")
        system.append("- time: giờ giao dịch dạng 24h \"HH:mm\" nếu người dùng nói giờ (ví dụ 'ăn sáng lúc 8 giờ' -> \"08:00\", '7 giờ tối' -> \"19:00\", '8 rưỡi sáng' -> \"08:30\", '12 giờ trưa' -> \"12:00\"). Nếu không nói giờ thì để null.\n")
        system.append("- note: ghi chú tiếng Việt, tổng hợp MỌI thông tin phụ người dùng nói ngoài số tiền, nhóm, ví, ngày và giờ (món/việc đã mua, tên quán hoặc địa điểm, đổ xăng ở đâu, phương tiện như đi xe ô tô/taxi/xe máy, đi cùng ai, mục đích...) thành một đoạn ngắn tự nhiên. Không lặp lại số tiền hay giờ trong note. Nếu không có thông tin gì thêm thì note chỉ ghi ngắn gọn nội dung giao dịch (ví dụ: ăn phở).\n")
        system.append("- transcript: nội dung bạn nghe/đọc được, nguyên văn.\n")
        system.append("Chỉ trả về DUY NHẤT một JSON, không kèm giải thích, theo mẫu:\n")
        system.append("{\"transcript\":\"...\",\"transactions\":[{\"amount\":50000,\"category_id\":1,\"wallet_id\":null,\"time\":\"08:00\",\"note\":\"ăn phở ở quán Bà Béo\",\"days_ago\":0}]}\n")
        system.append("Nếu không có giao dịch nào, trả về transactions là mảng rỗng.\n\n")
        system.append("Hôm nay: ").append(today).append("\n\n")
        system.append("Danh sách nhóm (id | loại | tên):\n").append(catLines).append("\n\n")
        system.append("Danh sách ví (id | tên):\n").append(walletLines).append("\n")

        val parts = JSONArray()
        if (wav != null) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "audio/wav")
                        .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))
                )
            )
        }
        val userText = when {
            !text.isNullOrBlank() && wav != null -> "Ghi chú thêm bằng văn bản: $text\nHãy xử lý đoạn ghi âm này."
            !text.isNullOrBlank() -> text.orEmpty()
            else -> "Hãy xử lý đoạn ghi âm này."
        }
        parts.put(textPart(userText))

        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(textPart(system.toString())))
            )
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put(
                "generationConfig",
                JSONObject().put("temperature", 0).put("responseMimeType", "application/json")
            )

        val raw = extractText(call(apiKey, model, body))
        val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val obj = JSONObject(clean)
        val arr = obj.optJSONArray("transactions") ?: JSONArray()
        val items = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            items.add(
                Item(
                    amount = o.optLong("amount", 0),
                    categoryId = if (o.isNull("category_id")) null else o.optLong("category_id"),
                    walletId = if (o.isNull("wallet_id")) null else o.optLong("wallet_id"),
                    note = o.optString("note", ""),
                    daysAgo = o.optInt("days_ago", 0),
                    time = if (o.isNull("time")) null else o.optString("time", "").ifBlank { null }
                )
            )
        }
        return ParseResult(obj.optString("transcript", ""), items)
    }
}
