package com.chitieu.app.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.chitieu.app.data.Category
import com.chitieu.app.data.T
import com.chitieu.app.data.Txn
import java.util.Calendar

@Composable
fun AddTxnScreen(vm: AppViewModel, nav: NavController, id: Long, onAi: () -> Unit) {
    val txns by vm.txns.collectAsState()
    val cats by vm.categories.collectAsState()
    val wallets by vm.wallets.collectAsState()
    val ctx = LocalContext.current
    val existing = txns.firstOrNull { it.id == id }

    var amountText by remember { mutableStateOf(existing?.amount?.toString() ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var categoryId by remember { mutableStateOf(existing?.categoryId) }
    var walletId by remember { mutableStateOf(existing?.walletId ?: vm.txWalletFilter) }
    var date by remember { mutableStateOf(existing?.date ?: System.currentTimeMillis()) }
    var pickCat by remember { mutableStateOf(false) }
    var walletMenu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val cat: Category? = cats.firstOrNull { it.id == categoryId }
    val wallet = wallets.firstOrNull { it.id == walletId } ?: wallets.firstOrNull()
    val amount = amountText.toLongOrNull() ?: 0L

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = if (existing != null) "Sửa giao dịch" else "Thêm giao dịch", onBack = { nav.popBackStack() }) {
            if (existing == null) {
                IconButton(onClick = onAi) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = "AI / giọng nói", tint = Color(0xFFFFC107))
                }
            } else {
                IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Xóa", tint = Red)
                }
            }
        }
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = amountText,
                onValueChange = { v -> amountText = v.filter { ch -> ch.isDigit() }.take(13) },
                label = { Text("Số tiền (đ)") },
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (amount > 0) Text(moneyD(amount), color = Muted, fontSize = 16.sp)

            FieldRow(label = "Nhóm", value = cat?.name ?: "Chọn nhóm") { pickCat = true }

            OutlinedTextField(
                value = note, onValueChange = { note = it },
                label = { Text("Ghi chú") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            FieldRow(label = "Ngày", value = dateVi(date)) {
                val c = Calendar.getInstance()
                c.timeInMillis = date
                DatePickerDialog(ctx, { _, y, m, d ->
                    val n = Calendar.getInstance()
                    n.timeInMillis = date
                    n.set(y, m, d)
                    date = n.timeInMillis
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            }

            FieldRow(label = "Giờ", value = timeVi(date)) {
                val c = Calendar.getInstance()
                c.timeInMillis = date
                TimePickerDialog(ctx, { _, h, m ->
                    val n = Calendar.getInstance()
                    n.timeInMillis = date
                    n.set(Calendar.HOUR_OF_DAY, h)
                    n.set(Calendar.MINUTE, m)
                    n.set(Calendar.SECOND, 0)
                    date = n.timeInMillis
                }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
            }

            Box {
                FieldRow(label = "Ví", value = wallet?.name ?: "—") { walletMenu = true }
                DropdownMenu(expanded = walletMenu, onDismissRequest = { walletMenu = false }) {
                    for (w in wallets) {
                        DropdownMenuItem(
                            text = { Text(w.name) },
                            onClick = { walletId = w.id; walletMenu = false }
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val c = cat
                    val w = wallet
                    when {
                        amount <= 0 -> Toast.makeText(ctx, "Nhập số tiền", Toast.LENGTH_SHORT).show()
                        c == null -> Toast.makeText(ctx, "Chọn nhóm", Toast.LENGTH_SHORT).show()
                        w == null -> Toast.makeText(ctx, "Chưa có ví", Toast.LENGTH_SHORT).show()
                        else -> {
                            vm.saveTxn(
                                Txn(
                                    id = existing?.id ?: 0L,
                                    walletId = w.id,
                                    categoryId = c.id,
                                    amount = amount,
                                    type = c.type,
                                    note = note.trim(),
                                    date = date
                                )
                            )
                            nav.popBackStack()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White)
            ) { Text("Lưu", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        }
    }

    if (pickCat) {
        CategoryPickerDialog(
            vm = vm,
            onPick = { c -> categoryId = c.id; pickCat = false },
            onDismiss = { pickCat = false }
        )
    }
    if (confirmDelete && existing != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = CardBg,
            title = { Text("Xóa giao dịch?") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteTxn(existing.id)
                    confirmDelete = false
                    nav.popBackStack()
                }) { Text("Xóa", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Hủy") } }
        )
    }
}

@Composable
private fun FieldRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Muted, fontSize = 17.sp, modifier = Modifier.width(72.dp))
        Text(value, fontSize = 18.sp, modifier = Modifier.weight(1f))
    }
}
