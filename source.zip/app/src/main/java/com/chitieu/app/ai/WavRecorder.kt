package com.chitieu.app.ai

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Ghi am micro (PCM 16kHz mono) va tra ve du lieu WAV de gui cho Gemini. */
class WavRecorder {
    private val sampleRate = 16000
    private var record: AudioRecord? = null
    private var thread: Thread? = null
    private val pcm = ByteArrayOutputStream()

    @Volatile
    var isRecording: Boolean = false
        private set

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (isRecording) return true
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return false
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        synchronized(pcm) { pcm.reset() }
        record = rec
        isRecording = true
        rec.startRecording()
        val t = Thread {
            val buf = ByteArray(minBuf)
            while (isRecording) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    synchronized(pcm) { pcm.write(buf, 0, n) }
                }
            }
        }
        thread = t
        t.start()
        return true
    }

    /** Dung ghi am, tra ve WAV (null neu khong co du lieu). */
    fun stop(): ByteArray? {
        if (!isRecording) return null
        isRecording = false
        try {
            thread?.join(1000)
        } catch (e: InterruptedException) {
            // ignore
        }
        val rec = record
        try {
            rec?.stop()
        } catch (e: Exception) {
            // ignore
        }
        rec?.release()
        record = null
        thread = null
        val data = synchronized(pcm) { pcm.toByteArray() }
        if (data.size < sampleRate / 2) return null // ngan hon ~0.25 giay
        return toWav(data)
    }

    private fun toWav(data: ByteArray): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(36 + data.size)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1.toShort())
        header.putShort(1.toShort())
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)
        header.putShort(2.toShort())
        header.putShort(16.toShort())
        header.put("data".toByteArray())
        header.putInt(data.size)
        val out = ByteArrayOutputStream()
        out.write(header.array())
        out.write(data)
        return out.toByteArray()
    }
}
