package com.chitieu.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM wallets ORDER BY id")
    fun wallets(): Flow<List<Wallet>>

    @Insert
    suspend fun insertWallet(w: Wallet): Long

    @Update
    suspend fun updateWallet(w: Wallet)

    @Query("DELETE FROM wallets WHERE id = :id")
    suspend fun deleteWallet(id: Long)

    @Query("DELETE FROM transactions WHERE walletId = :walletId")
    suspend fun deleteTxnsOfWallet(walletId: Long)

    @Query("SELECT COUNT(*) FROM wallets")
    suspend fun walletCount(): Int

    @Query("SELECT * FROM categories ORDER BY id")
    fun categories(): Flow<List<Category>>

    @Insert
    suspend fun insertCategory(c: Category): Long

    @Query("DELETE FROM categories WHERE id = :id OR parentId = :id")
    suspend fun deleteCategory(id: Long)

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun categoryCount(): Int

    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun txns(): Flow<List<Txn>>

    @Insert
    suspend fun insertTxn(t: Txn): Long

    @Update
    suspend fun updateTxn(t: Txn)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTxn(id: Long)

    @Query("SELECT * FROM budgets ORDER BY id")
    fun budgets(): Flow<List<Budget>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBudget(b: Budget): Long

    @Query("DELETE FROM budgets WHERE id = :id")
    suspend fun deleteBudget(id: Long)
}
