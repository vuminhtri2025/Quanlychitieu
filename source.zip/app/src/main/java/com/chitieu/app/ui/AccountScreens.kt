package com.chitieu.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.chitieu.app.data.Wallet
import kotlinx.coroutines.launch

@Composable
fun AccountScreen(vm: AppViewModel, nav: NavController, onAi: () -> Unit) {
    var showAbout by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = "Tài khoản", onBack = null)
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Column(
                modifier = Modifier.fillMaxWidth().background(CardBg).padding(vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(84.dp).clip(CircleShape).background(Green),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        vm.userName.take(1).uppercase(), fontSize = 42.sp,
                        color = Color.White, fontWeight = FontWeight.Medium
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(vm.userName, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Dữ liệu lưu trên thiết bị", color = Muted, fontSize = 16.sp)
            }
            Spacer(Modifier.height(8.dp))
            MenuRow(Icons.Filled.AccountBalanceWallet, "Ví của tôi") { nav.navigate("wallets") }
            MenuRow(Icons.Filled.Category, "Nhóm") { nav.navigate("categories") }
            MenuRow(Icons.Filled.AutoAwesome, "Thêm giao dịch bằng AI / giọng nói", onClick = onAi)
            MenuRow(Icons.Filled.Settings, "Cài đặt (Gemini API key)") { nav.navigate("settings") }
            MenuRow(Icons.Filled.Info, "Giới thiệu") { showAbout = true }
            Spacer(Modifier.height(16.dp))
            Text(
                "Phiên bản 1.0", color = Muted, fontSize = 16.sp,
                modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
        }
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            containerColor = CardBg,
            title = { Text("Chi Tiêu") },
            text = { Text("Ứng dụng quản lý chi tiêu cá nhân. Dữ liệu lưu trên máy. Ra lệnh bằng giọng nói được phân tích qua Google AI Studio (Gemini).") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Đóng", color = Green) } }
        )
    }
}

@Composable
private fun MenuRow(icon: ImageVector, title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(20.dp))
        Text(title, fontSize = 20.sp, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Muted)
    }
}

@Composable
fun WalletsScreen(vm: AppViewModel, nav: NavController) {
    val wallets by vm.wallets.collectAsState()
    val txns by vm.txns.collectAsState()
    var editing by remember { mutableStateOf<Wallet?>(null) }
    var creating by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = "Ví của tôi", onBack = { nav.popBackStack() }) {
            IconButton(onClick = { creating = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Thêm ví")
            }
        }
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(wallets, key = { it.id }) { w ->
                Row(
                    modifier = Modifier.fillMaxWidth().background(CardBg).clickable { editing = w }
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WalletIcon(48.dp)
                    Spacer(Modifier.width(16.dp))
                    Text(w.name, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    Text(moneyD(walletBalance(w, txns)), fontSize = 20.sp)
                }
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BarBg))
            }
        }
    }

    if (creating) {
        WalletDialog(
            initial = null,
            onSave = { vm.saveWallet(it); creating = false },
            onDelete = {},
            onDismiss = { creating = false }
        )
    }
    val e = editing
    if (e != null) {
        WalletDialog(
            initial = e,
            onSave = { vm.saveWallet(it); editing = null },
            onDelete = { vm.deleteWallet(e.id); editing = null },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun WalletDialog(
    initial: Wallet?,
    onSave: (Wallet) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var balance by remember { mutableStateOf(initial?.initialBalance?.toString() ?: "0") }
    var confirm by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(if (initial == null) "Ví mới" else "Sửa ví") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Tên ví") }, singleLine = true
                )
                OutlinedTextField(
                    value = balance,
                    onValueChange = { v -> balance = v.filter { ch -> ch.isDigit() || ch == '-' }.take(14) },
                    label = { Text("Số dư ban đầu (đ)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                if (confirm) {
                    Text("Xóa ví sẽ xóa cả các giao dịch trong ví. Nhấn Xóa lần nữa để xác nhận.", color = Red, fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank()) {
                    onSave(
                        Wallet(
                            id = initial?.id ?: 0L,
                            name = name.trim(),
                            initialBalance = balance.toLongOrNull() ?: 0L
                        )
                    )
                }
            }) { Text("Lưu", color = Green) }
        },
        dismissButton = {
            Row {
                if (initial != null) {
                    TextButton(onClick = { if (confirm) onDelete() else confirm = true }) {
                        Text("Xóa", color = Red)
                    }
                }
                TextButton(onClick = onDismiss) { Text("Hủy") }
            }
        }
    )
}

@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(vm.apiKey) }
    var model by remember { mutableStateOf(vm.model) }
    var name by remember { mutableStateOf(vm.userName) }
    var show by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(title = "Cài đặt", onBack = { nav.popBackStack() })
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Tên hiển thị") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Google AI Studio (Gemini)", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "Nhập API key để dùng lệnh giọng nói và nhập giao dịch bằng AI. Key chỉ lưu trên máy này.",
                color = Muted, fontSize = 15.sp
            )
            OutlinedTextField(
                value = key, onValueChange = { key = it },
                label = { Text("Gemini API key") }, singleLine = true,
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { show = !show }) { Text(if (show) "Ẩn key" else "Hiện key") }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
                }) { Text("Lấy API key") }
            }
            OutlinedTextField(
                value = model, onValueChange = { model = it },
                label = { Text("Model") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        vm.saveSettings(key, model, name)
                        status = "Đã lưu."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White),
                    shape = RoundedCornerShape(24.dp)
                ) { Text("Lưu") }
                OutlinedButton(
                    enabled = !testing && key.isNotBlank(),
                    onClick = {
                        vm.saveSettings(key, model, name)
                        testing = true
                        status = "Đang kiểm tra…"
                        scope.launch {
                            status = vm.testApi(key, model)
                            testing = false
                        }
                    }
                ) { Text("Kiểm tra kết nối") }
            }
            if (status.isNotBlank()) Text(status, color = if (status.startsWith("Lỗi")) Red else Green, fontSize = 15.sp)
        }
    }
}
