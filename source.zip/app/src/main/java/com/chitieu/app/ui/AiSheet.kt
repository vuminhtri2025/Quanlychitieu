package com.chitieu.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.chitieu.app.ai.WavRecorder
import com.chitieu.app.data.T
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSheet(vm: AppViewModel, onDismiss: () -> Unit, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val cats by vm.categories.collectAsState()
    val wallets by vm.wallets.collectAsState()
    var text by remember { mutableStateOf("") }
    val recorder = remember { WavRecorder() }
    var recording by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.clearAi() }
    DisposableEffect(Unit) {
        onDispose {
            if (recorder.isRecording) recorder.stop()
        }
    }

    fun startRec() {
        if (recorder.start()) {
            recording = true
            vm.aiError = null
        } else {
            vm.aiError = "Không mở được micro."
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            startRec()
        } else {
            vm.aiError = "Cần cấp quyền micro để ra lệnh bằng giọng nói."
        }
    }

    fun toggleRec() {
        if (recording) {
            recording = false
            val wav = recorder.stop()
            if (wav != null) {
                vm.runAi(text.takeIf { it.isNotBlank() }, wav)
            } else {
                vm.aiError = "Đoạn ghi âm quá ngắn, hãy thử lại."
            }
        } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRec()
        } else {
            permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF2A2A2D)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().imePadding().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color(0xFFFFC107))
                Spacer(Modifier.width(10.dp))
                Text("Thêm giao dịch bằng AI", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Đóng") }
            }
            Text(
                "Nhấn micro và nói, hoặc gõ như đang trò chuyện. Thử: “Hôm nay ăn phở 50k, đổ xăng 100k trả tiền mặt”.",
                color = Muted, fontSize = 16.sp
            )
            if (vm.apiKey.isBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Chưa có Gemini API key.", color = Red, modifier = Modifier.weight(1f))
                    TextButton(onClick = onOpenSettings) { Text("Nhập key", color = Green) }
                }
            }
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Hôm nay bạn đã chi tiêu bao nhiêu?") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                minLines = 2,
                trailingIcon = {
                    Row {
                        IconButton(onClick = { toggleRec() }) {
                            Icon(
                                if (recording) Icons.Filled.Stop else Icons.Filled.Mic,
                                contentDescription = "Ghi âm",
                                tint = if (recording) Red else Green
                            )
                        }
                        IconButton(
                            enabled = text.isNotBlank() && !vm.aiLoading && !recording,
                            onClick = { vm.runAi(text, null) }
                        ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Gửi") }
                    }
                }
            )
            if (recording) {
                Text("Đang nghe… nhấn nút dừng để phân tích.", color = Red, fontSize = 16.sp)
            }
            if (vm.aiLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Green, trackColor = BarBg)
                Text("Đang phân tích bằng Gemini…", color = Muted, fontSize = 15.sp)
            }
            val err = vm.aiError
            if (err != null) {
                Text(err, color = Red, fontSize = 15.sp)
            }
            if (vm.aiDrafts.isNotEmpty()) {
                if (vm.aiTranscript.isNotBlank()) {
                    Text("Nghe được: “" + vm.aiTranscript + "”", color = Muted, fontSize = 15.sp)
                }
                vm.aiDrafts.forEachIndexed { index, d ->
                    val c = cats.firstOrNull { it.id == d.categoryId }
                    val w = wallets.firstOrNull { it.id == d.walletId }
                    var walletMenu by remember(index) { mutableStateOf(false) }
                    Column(
                        modifier = Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(14.dp))
                            .padding(start = 14.dp, top = 8.dp, bottom = 10.dp, end = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(c?.name ?: "Khác", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Text(dateVi(d.date), color = Muted, fontSize = 14.sp)
                            }
                            Text(money(d.amount), fontSize = 18.sp, color = if (T.isIn(d.type)) Blue else Red)
                            IconButton(onClick = { vm.removeDraft(index) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Bỏ", tint = Muted)
                            }
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box {
                                OutlinedButton(onClick = { walletMenu = true }) {
                                    Text(w?.name ?: "Chọn ví")
                                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null)
                                }
                                DropdownMenu(expanded = walletMenu, onDismissRequest = { walletMenu = false }) {
                                    for (wl in wallets) {
                                        DropdownMenuItem(
                                            text = { Text(wl.name) },
                                            onClick = {
                                                vm.updateDraft(index, d.copy(walletId = wl.id))
                                                walletMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                            OutlinedButton(onClick = {
                                val cal = Calendar.getInstance()
                                cal.timeInMillis = d.date
                                TimePickerDialog(ctx, { _, h, m ->
                                    val n = Calendar.getInstance()
                                    n.timeInMillis = d.date
                                    n.set(Calendar.HOUR_OF_DAY, h)
                                    n.set(Calendar.MINUTE, m)
                                    n.set(Calendar.SECOND, 0)
                                    vm.updateDraft(index, d.copy(date = n.timeInMillis))
                                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
                            }) { Text("Giờ " + timeVi(d.date)) }
                        }
                        OutlinedTextField(
                            value = d.note,
                            onValueChange = { nv -> vm.updateDraft(index, d.copy(note = nv)) },
                            label = { Text("Ghi chú") },
                            modifier = Modifier.fillMaxWidth().padding(end = 10.dp, top = 6.dp)
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = {
                        vm.saveDrafts()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White)
                ) { Text("Lưu " + vm.aiDrafts.size + " giao dịch", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}
