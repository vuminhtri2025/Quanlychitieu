package com.chitieu.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.chitieu.app.ai.GeminiClient
import com.chitieu.app.data.AppDatabase
import com.chitieu.app.data.Budget
import com.chitieu.app.data.Category
import com.chitieu.app.data.Prefs
import com.chitieu.app.data.T
import com.chitieu.app.data.Txn
import com.chitieu.app.data.Wallet
import com.chitieu.app.data.seedIfNeeded
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class Draft(
    val amount: Long,
    val type: String,
    val categoryId: Long,
    val walletId: Long,
    val note: String,
    val date: Long
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val prefs = Prefs(app)

    val wallets: StateFlow<List<Wallet>> =
        dao.wallets().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val categories: StateFlow<List<Category>> =
        dao.categories().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val txns: StateFlow<List<Txn>> =
        dao.txns().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val budgets: StateFlow<List<Budget>> =
        dao.budgets().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- cai dat ----
    var hideBalance by mutableStateOf(prefs.hideBalance)
        private set
    var apiKey by mutableStateOf(prefs.apiKey)
        private set
    var model by mutableStateOf(prefs.model)
        private set
    var userName by mutableStateOf(prefs.userName)
        private set

    // bo loc vi o man hinh So giao dich (null = tat ca)
    var txWalletFilter by mutableStateOf<Long?>(null)

    init {
        viewModelScope.launch { seedIfNeeded(dao) }
    }

    fun toggleHide() {
        hideBalance = !hideBalance
        prefs.hideBalance = hideBalance
    }

    fun saveSettings(key: String, modelName: String, name: String) {
        apiKey = key.trim()
        model = modelName.trim().ifBlank { "gemini-2.5-flash" }
        userName = name.trim().ifBlank { "Tôi" }
        prefs.apiKey = apiKey
        prefs.model = model
        prefs.userName = userName
    }

    // ---- giao dich ----
    fun saveTxn(t: Txn) {
        viewModelScope.launch {
            if (t.id == 0L) dao.insertTxn(t) else dao.updateTxn(t)
        }
    }

    fun deleteTxn(id: Long) {
        viewModelScope.launch { dao.deleteTxn(id) }
    }

    // ---- vi ----
    fun saveWallet(w: Wallet) {
        viewModelScope.launch {
            if (w.id == 0L) dao.insertWallet(w) else dao.updateWallet(w)
        }
    }

    fun deleteWallet(id: Long) {
        viewModelScope.launch {
            dao.deleteTxnsOfWallet(id)
            dao.deleteWallet(id)
            if (txWalletFilter == id) txWalletFilter = null
        }
    }

    // ---- nhom ----
    fun saveCategory(c: Category) {
        viewModelScope.launch { dao.insertCategory(c) }
    }

    fun deleteCategory(id: Long) {
        viewModelScope.launch { dao.deleteCategory(id) }
    }

    // ---- ngan sach ----
    fun saveBudget(b: Budget) {
        viewModelScope.launch { dao.upsertBudget(b) }
    }

    fun deleteBudget(id: Long) {
        viewModelScope.launch { dao.deleteBudget(id) }
    }

    // ---- AI / giong noi ----
    var aiLoading by mutableStateOf(false)
        private set
    var aiError by mutableStateOf<String?>(null)
    var aiTranscript by mutableStateOf("")
        private set
    val aiDrafts = mutableStateListOf<Draft>()

    fun clearAi() {
        aiError = null
        aiTranscript = ""
        aiDrafts.clear()
    }

    fun updateDraft(index: Int, d: Draft) {
        if (index in 0 until aiDrafts.size) aiDrafts[index] = d
    }

    private fun buildDate(now: Long, daysAgo: Int, time: String?): Long {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = now
        c.add(java.util.Calendar.DAY_OF_YEAR, -daysAgo.coerceIn(0, 365))
        val parts = time?.trim()?.split(":")
        val h = parts?.getOrNull(0)?.toIntOrNull()
        val m = parts?.getOrNull(1)?.toIntOrNull() ?: 0
        if (h != null && h in 0..23 && m in 0..59) {
            c.set(java.util.Calendar.HOUR_OF_DAY, h)
            c.set(java.util.Calendar.MINUTE, m)
            c.set(java.util.Calendar.SECOND, 0)
            c.set(java.util.Calendar.MILLISECOND, 0)
        }
        return c.timeInMillis
    }

    fun removeDraft(index: Int) {
        if (index in 0 until aiDrafts.size) aiDrafts.removeAt(index)
    }

    fun runAi(text: String?, wav: ByteArray?) {
        if (aiLoading) return
        if (apiKey.isBlank()) {
            aiError = "Chưa có API key. Vào Tài khoản > Cài đặt để nhập Gemini API key."
            return
        }
        val cats = categories.value
        val ws = wallets.value
        if (cats.isEmpty() || ws.isEmpty()) {
            aiError = "Dữ liệu chưa sẵn sàng, thử lại sau giây lát."
            return
        }
        aiLoading = true
        aiError = null
        viewModelScope.launch {
            try {
                val r = GeminiClient.parse(apiKey, model, cats, ws, text, wav)
                aiTranscript = r.transcript
                aiDrafts.clear()
                val fallbackCat = cats.firstOrNull {
                    it.type == T.EXPENSE && it.name.contains("phát sinh", ignoreCase = true)
                } ?: cats.first()
                val now = System.currentTimeMillis()
                for (item in r.items) {
                    if (item.amount <= 0) continue
                    val cat = cats.firstOrNull { it.id == item.categoryId } ?: fallbackCat
                    val wallet = ws.firstOrNull { it.id == item.walletId } ?: ws.first()
                    aiDrafts.add(
                        Draft(
                            amount = item.amount,
                            type = cat.type,
                            categoryId = cat.id,
                            walletId = wallet.id,
                            note = item.note,
                            date = buildDate(now, item.daysAgo, item.time)
                        )
                    )
                }
                if (aiDrafts.isEmpty()) {
                    aiError = "Không nhận ra giao dịch nào. Hãy thử nói rõ số tiền và nội dung."
                }
            } catch (e: Exception) {
                aiError = "Lỗi: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                aiLoading = false
            }
        }
    }

    fun saveDrafts() {
        val list = aiDrafts.toList()
        viewModelScope.launch {
            for (d in list) {
                dao.insertTxn(
                    Txn(
                        walletId = d.walletId,
                        categoryId = d.categoryId,
                        amount = d.amount,
                        type = d.type,
                        note = d.note,
                        date = d.date
                    )
                )
            }
        }
        aiDrafts.clear()
        aiTranscript = ""
    }

    suspend fun testApi(key: String, modelName: String): String {
        return try {
            val r = GeminiClient.ping(key, modelName.ifBlank { "gemini-2.5-flash" })
            "Kết nối thành công: $r"
        } catch (e: Exception) {
            "Lỗi: " + (e.message ?: e.javaClass.simpleName)
        }
    }
}
