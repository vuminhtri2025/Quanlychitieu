package com.chitieu.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Green = Color(0xFF2DB84C)
val Red = Color(0xFFF2605C)
val Blue = Color(0xFF3AA9E8)
val Bg = Color(0xFF000000)
val CardBg = Color(0xFF1C1C1E)
val BarBg = Color(0xFF2C2C2E)
val Muted = Color(0xFF9A9AA0)
val IconBg = Color(0xFF2F4858)
val Orange = Color(0xFFE8702A)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Bg,
            onBackground = Color.White,
            surface = CardBg,
            onSurface = Color.White,
            surfaceVariant = BarBg,
            onSurfaceVariant = Muted,
            error = Red
        ),
        content = content
    )
}
