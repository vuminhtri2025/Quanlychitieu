# ===== Chi Tiêu AI - quy tắc R8 =====
# Activity và NotificationListenerService khai báo trong AndroidManifest được AGP tự giữ lại.
# App không dùng reflection/Gson nên không cần keep thêm lớp dữ liệu.

# Giữ số dòng để đọc stack trace; dùng mapping.txt (được upload ở GitHub Actions) để giải mã.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Bỏ log gỡ lỗi khỏi bản release (nhẹ hơn, đỡ tốn CPU)
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# Cảnh báo thiếu lớp không ảnh hưởng (chỉ dùng khi gỡ lỗi coroutines trên JVM)
-dontwarn java.lang.management.**
-dontwarn kotlinx.coroutines.debug.**
