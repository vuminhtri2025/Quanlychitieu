package com.vichitieu.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

// ======================= TAB 3: LỊCH SỬ =======================
@Composable
fun HistoryScreen(s: AppState) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) } // 0 tất cả, 1 chi, 2 thu
    var editing by remember { mutableStateOf<Txn?>(null) }

    editing?.let { e ->
        TxnDialog(e, "Sửa giao dịch",
            onSave = { s.upsert(it); editing = null },
            onDelete = { s.delete(e.id); editing = null },
            onDismiss = { editing = null })
    }

    val list = s.txns.sortedByDescending { it.time }.filter {
        (filter == 0 || (filter == 1 && it.isExpense) || (filter == 2 && !it.isExpense)) &&
            (query.isBlank() || it.note.contains(query, true) || it.category.contains(query, true) ||
                it.amount.toString().contains(query))
    }
    val rows = ArrayList<Any>()
    var lastDay = -1L
    list.forEach { t ->
        val key = cal(t.time).let { it.get(Calendar.YEAR) * 1000L + it.get(Calendar.DAY_OF_YEAR) }
        if (key != lastDay) { rows.add(t.time); lastDay = key }
        rows.add(t)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenHeader("Lịch sử", "${list.size} giao dịch")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Tìm theo ghi chú, nhóm, số tiền") },
            modifier = Modifier.fillMaxWidth())
        Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Tất cả", filter == 0) { filter = 0 }
            Pill("Chi tiêu", filter == 1, Red) { filter = 1 }
            Pill("Thu nhập", filter == 2, Green) { filter = 2 }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (rows.isEmpty()) item { Text("Không có giao dịch nào.", color = Muted, modifier = Modifier.padding(top = 20.dp)) }
            items(rows) { r ->
                if (r is Long) {
                    val dayTotal = list.filter { sameDay(it.time, r) }.sumOf { if (it.isExpense) -it.amount else it.amount }
                    val label = when {
                        sameDay(r, System.currentTimeMillis()) -> "Hôm nay"
                        sameDay(r, System.currentTimeMillis() - 86_400_000L) -> "Hôm qua"
                        else -> fmtDate(r)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label, color = Muted, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text((if (dayTotal > 0) "+" else "") + money(dayTotal), color = Muted, fontSize = 13.sp)
                    }
                } else if (r is Txn) {
                    TxnRow(r) { editing = r }
                }
            }
        }
    }
}

// ======================= TAB 4: PHÂN TÍCH =======================
@Composable
fun AnalysisScreen(s: AppState) {
    var offset by remember { mutableStateOf(0) }
    val base = Calendar.getInstance().apply { add(Calendar.MONTH, offset) }
    val y = base.get(Calendar.YEAR)
    val m = base.get(Calendar.MONTH)
    val month = s.txns.filter { sameMonth(it.time, y, m) }
    val exp = month.filter { it.isExpense }
    val inc = month.filter { !it.isExpense }.sumOf { it.amount }
    val expTotal = exp.sumOf { it.amount }
    val byCat = exp.groupBy { it.category }.map { it.key to it.value.sumOf { t -> t.amount } }.sortedByDescending { it.second }

    val prev = Calendar.getInstance().apply { add(Calendar.MONTH, offset - 1) }
    val prevExp = s.txns.filter { it.isExpense && sameMonth(it.time, prev.get(Calendar.YEAR), prev.get(Calendar.MONTH)) }.sumOf { it.amount }

    val daysCount = if (offset == 0) Calendar.getInstance().get(Calendar.DAY_OF_MONTH) else base.getActualMaximum(Calendar.DAY_OF_MONTH)

    val six = (5 downTo 0).map { k ->
        val c = Calendar.getInstance().apply { add(Calendar.MONTH, offset - k) }
        val ms = s.txns.filter { sameMonth(it.time, c.get(Calendar.YEAR), c.get(Calendar.MONTH)) }
        Triple("T${c.get(Calendar.MONTH) + 1}", ms.filter { !it.isExpense }.sumOf { it.amount }, ms.filter { it.isExpense }.sumOf { it.amount })
    }
    val maxBar = six.maxOf { maxOf(it.second, it.third) }.coerceAtLeast(1L)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Phân tích", "Hiểu tiền của bạn đi đâu")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Pill("‹", false) { offset-- }
            Text("Tháng ${m + 1}/$y", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Pill("›", false) { if (offset < 0) offset++ }
        }

        Panel {
            Title("Cơ cấu chi tiêu")
            Spacer(Modifier.height(12.dp))
            if (byCat.isEmpty()) {
                Text("Chưa có dữ liệu chi tiêu trong tháng này.", color = Muted, fontSize = 14.sp)
            } else {
                Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(180.dp)) {
                        val sw = 26.dp.toPx()
                        var start = -90f
                        byCat.forEach { (name, v) ->
                            val sweep = v.toFloat() / expTotal * 360f
                            drawArc(
                                color = catOf(name).color,
                                startAngle = start, sweepAngle = (sweep - 2f).coerceAtLeast(0.5f), useCenter = false,
                                topLeft = Offset(sw / 2, sw / 2),
                                size = Size(size.width - sw, size.height - sw),
                                style = Stroke(sw, cap = StrokeCap.Butt)
                            )
                            start += sweep
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tổng chi", color = Muted, fontSize = 12.sp)
                        Text(money(expTotal), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                byCat.forEach { (name, v) ->
                    val c = catOf(name)
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(c.color))
                        Text("  ${c.emoji} $name", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("${(v * 100 / expTotal)}%  ", color = Muted, fontSize = 13.sp)
                        Text(money(v), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Panel {
            Title("Thu – Chi 6 tháng")
            Spacer(Modifier.height(12.dp))
            Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                val slot = size.width / six.size
                val bw = slot * 0.26f
                six.forEachIndexed { i, t ->
                    val hi = (t.second.toFloat() / maxBar) * size.height
                    val he = (t.third.toFloat() / maxBar) * size.height
                    val x0 = i * slot + slot / 2
                    drawRoundRect(Green, Offset(x0 - bw - 2.dp.toPx(), size.height - hi.coerceAtLeast(3.dp.toPx())),
                        Size(bw, hi.coerceAtLeast(3.dp.toPx())), CornerRadius(6.dp.toPx()))
                    drawRoundRect(Red, Offset(x0 + 2.dp.toPx(), size.height - he.coerceAtLeast(3.dp.toPx())),
                        Size(bw, he.coerceAtLeast(3.dp.toPx())), CornerRadius(6.dp.toPx()))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                six.forEach { Text(it.first, Modifier.weight(1f), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center) }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("■ Thu", color = Green, fontSize = 12.sp)
                Text("■ Chi", color = Red, fontSize = 12.sp)
            }
        }

        Panel(color = Card2) {
            Title("Nhận xét nhanh")
            Spacer(Modifier.height(8.dp))
            val avg = expTotal / daysCount.coerceAtLeast(1)
            Text("• Trung bình mỗi ngày chi ${money(avg)}", color = Color.White, fontSize = 14.sp)
            if (byCat.isNotEmpty())
                Text("• Nhóm chi nhiều nhất: ${catOf(byCat[0].first).emoji} ${byCat[0].first} (${byCat[0].second * 100 / expTotal}%)",
                    color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            if (prevExp > 0) {
                val diff = (expTotal - prevExp) * 100 / prevExp
                Text("• So với tháng trước: ${if (diff >= 0) "+" else ""}$diff% chi tiêu",
                    color = if (diff > 0) Orange else Green, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            }
            if (inc > 0) {
                val rate = (inc - expTotal) * 100 / inc
                Text("• Tỷ lệ tiết kiệm: $rate% thu nhập", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

// ======================= TAB 5: NGÂN SÁCH & MỤC TIÊU =======================
@Composable
fun BudgetScreen(s: AppState) {
    val now = Calendar.getInstance()
    val y = now.get(Calendar.YEAR)
    val m = now.get(Calendar.MONTH)
    val spentBy = s.txns.filter { it.isExpense && sameMonth(it.time, y, m) }
        .groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
    var budgetDialog by remember { mutableStateOf(false) }
    var goalDialog by remember { mutableStateOf(false) }
    var depositFor by remember { mutableStateOf<Goal?>(null) }

    val totalLimit = s.budgets.sumOf { it.limit }
    val totalSpent = s.budgets.sumOf { spentBy[it.category] ?: 0L }

    if (budgetDialog) {
        var cat by remember { mutableStateOf("Ăn uống") }
        var amt by remember { mutableStateOf("") }
        FormDialog("Đặt ngân sách tháng", (amt.toLongOrNull() ?: 0L) > 0,
            { s.setBudget(Budget(cat, amt.toLong())); budgetDialog = false }, { budgetDialog = false }) {
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(EXPENSE_CATS) { c -> Pill(c.emoji + " " + c.name, cat == c.name, c.color) { cat = c.name } }
            }
            AmountField(amt, { amt = it }, "Hạn mức (₫)")
        }
    }
    if (goalDialog) {
        var name by remember { mutableStateOf("") }
        var amt by remember { mutableStateOf("") }
        FormDialog("Mục tiêu mới", name.isNotBlank() && (amt.toLongOrNull() ?: 0L) > 0,
            { s.upsertGoal(Goal(System.currentTimeMillis(), name.trim(), amt.toLong(), 0)); goalDialog = false },
            { goalDialog = false }) {
            OutlinedTextField(name, { name = it }, label = { Text("Tên mục tiêu") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            AmountField(amt, { amt = it }, "Số tiền cần đạt (₫)")
        }
    }
    depositFor?.let { g ->
        var amt by remember { mutableStateOf("") }
        FormDialog("Nạp vào “${g.name}”", (amt.toLongOrNull() ?: 0L) > 0,
            { s.upsertGoal(g.copy(saved = g.saved + amt.toLong())); depositFor = null }, { depositFor = null }) {
            AmountField(amt, { amt = it }, "Số tiền nạp (₫)")
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Ngân sách & mục tiêu", "Kiểm soát chi tiêu, tiến tới ước mơ")

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Orange).padding(20.dp)) {
            Text("Ngân sách tháng ${m + 1}", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            Text(if (totalLimit > 0) "Còn ${money(totalLimit - totalSpent)}" else "Chưa đặt ngân sách",
                color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            if (totalLimit > 0) {
                Spacer(Modifier.height(10.dp))
                Bar(totalSpent.toFloat() / totalLimit, Color.White)
                Text("Đã chi ${money(totalSpent)} / ${money(totalLimit)}", color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp))
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Title("Ngân sách theo nhóm")
            Pill("+ Thêm", true) { budgetDialog = true }
        }
        if (s.budgets.isEmpty()) Text("Đặt hạn mức cho từng nhóm để được cảnh báo khi sắp vượt.", color = Muted, fontSize = 14.sp)
        s.budgets.forEach { b ->
            val spent = spentBy[b.category] ?: 0L
            val p = spent.toFloat() / b.limit
            val col = when { p >= 1f -> Red; p >= 0.8f -> Orange; else -> Green }
            val c = catOf(b.category)
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${c.emoji} ${b.category}", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("${(p * 100).toInt()}%", color = col, fontWeight = FontWeight.Bold)
                    Text("  ✕", color = Muted, modifier = Modifier.clickable { s.deleteBudget(b.category) })
                }
                Spacer(Modifier.height(10.dp))
                Bar(p, col)
                Text(
                    if (p >= 1f) "Vượt ${money(spent - b.limit)} • ${money(spent)} / ${money(b.limit)}"
                    else "Còn ${money(b.limit - spent)} • ${money(spent)} / ${money(b.limit)}",
                    color = if (p >= 1f) Red else Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Title("Mục tiêu tiết kiệm")
            Pill("+ Thêm", true, Green) { goalDialog = true }
        }
        if (s.goals.isEmpty()) Text("Ví dụ: Mua điện thoại mới, du lịch, quỹ khẩn cấp…", color = Muted, fontSize = 14.sp)
        s.goals.forEach { g ->
            val p = g.saved.toFloat() / g.target
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎯 ${g.name}", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("${(p * 100).toInt().coerceAtMost(100)}%", color = Green, fontWeight = FontWeight.Bold)
                    Text("  ✕", color = Muted, modifier = Modifier.clickable { s.deleteGoal(g.id) })
                }
                Spacer(Modifier.height(10.dp))
                Bar(p, Green)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${money(g.saved)} / ${money(g.target)}", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    if (g.saved < g.target) Pill("+ Nạp tiền", false) { depositFor = g }
                    else Text("Hoàn thành 🎉", color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun FormDialog(
    title: String,
    canSave: Boolean,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp), content = content) },
        confirmButton = { TextButton(enabled = canSave, onClick = onSave) { Text("Lưu", color = Orange, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = Muted) } }
    )
}
