package com.vichitieu.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Calendar

data class Parsed(
    val amount: Long?,
    val amountClear: Boolean,   // có đơn vị rõ ràng (k, nghìn, triệu, đồng...) hoặc số đủ lớn
    val isExpense: Boolean,
    val time: Long,
    val category: String,
    val categoryMatched: Boolean,
    val note: String
)

object VoiceParser {
    private val numRe = Regex("""(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d+)?)\s*(triệu|tr|nghìn|ngàn|k|đ)?(\d)?\s*(rưỡi)?""")
    private val thousandsRe = Regex("""^\d{1,3}([.,]\d{3})+$""")

    fun parse(raw: String): Parsed {
        val text = raw.lowercase().replace("đồng", "đ").replace("vnd", "đ").replace("vnđ", "đ")

        // ---- số tiền ----
        var bestVal: Long? = null
        var bestClear = false
        var bestRange: IntRange? = null
        for (m in numRe.findAll(text)) {
            val num = m.groupValues[1]
            val unit = m.groupValues[2]
            val tail = m.groupValues[3]
            val half = m.groupValues[4].isNotEmpty()
            val base = if (thousandsRe.matches(num)) num.replace(Regex("[.,]"), "").toDouble()
            else num.replace(',', '.').toDouble()
            val mult = when (unit) {
                "triệu", "tr" -> 1_000_000.0
                "nghìn", "ngàn", "k" -> 1_000.0
                else -> 1.0
            }
            var v = base * mult
            if (mult == 1_000_000.0 && tail.isNotEmpty()) v += tail.toDouble() * 100_000
            if (half && mult > 1.0) v += mult / 2
            var clear = unit.isNotEmpty() || num.length >= 4
            if (unit.isEmpty() && v < 1000) { v *= 1000; clear = false }
            val vl = v.toLong()
            val better = bestVal == null || (clear && !bestClear) || (clear == bestClear && vl > (bestVal ?: 0L))
            if (better) { bestVal = vl; bestClear = clear; bestRange = m.range }
        }

        // ---- loại giao dịch & nhóm ----
        val incomeScore = INCOME_CATS.sumOf { c -> c.keywords.count { text.contains(it) } }
        val isExpense = incomeScore == 0
        val pool = if (isExpense) EXPENSE_CATS else INCOME_CATS
        var bestCat: Cat? = null
        var bestScore = 0
        for (c in pool) {
            val s = c.keywords.filter { text.contains(it) }.sumOf { it.length }
            if (s > bestScore) { bestScore = s; bestCat = c }
        }
        val catName = bestCat?.name ?: if (isExpense) "Khác" else "Thu nhập khác"

        // ---- ngày ----
        val c = Calendar.getInstance()
        when {
            text.contains("hôm kia") || text.contains("hôm trước") -> c.add(Calendar.DAY_OF_YEAR, -2)
            text.contains("hôm qua") -> c.add(Calendar.DAY_OF_YEAR, -1)
        }

        // ---- ghi chú ----
        var note = raw.trim()
        if (bestRange != null) {
            val r = bestRange
            if (r.last < text.length && text.length == raw.length) {
                note = (raw.substring(0, r.first) + " " + raw.substring(r.last + 1)).trim()
            }
        }
        note = note.replace(Regex("\\s+"), " ").trim()
        if (note.isNotEmpty()) note = note.replaceFirstChar { it.uppercase() }

        return Parsed(bestVal, bestClear, isExpense, c.timeInMillis, catName, bestCat != null, note)
    }
}

/** Nhận dạng giọng nói bằng Google SpeechRecognizer (dịch vụ Google trên thiết bị), tiếng Việt. */
class VoiceController(
    private val ctx: Context,
    private val onResult: (text: String, confidence: Float?) -> Unit
) {
    var listening by mutableStateOf(false)
    var partial by mutableStateOf("")
    var level by mutableStateOf(0f)
    var error by mutableStateOf<String?>(null)
    private var rec: SpeechRecognizer? = null

    fun start() {
        error = null
        partial = ""
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            error = "Thiết bị chưa có dịch vụ nhận dạng giọng nói của Google"
            return
        }
        stop()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false; level = 0f }
            override fun onError(code: Int) {
                listening = false; level = 0f
                error = when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Không nghe rõ, hãy thử lại"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Lỗi mạng, kiểm tra kết nối"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Chưa cấp quyền micro"
                    else -> "Lỗi nhận dạng (mã $code)"
                }
            }
            override fun onResults(results: Bundle?) {
                listening = false; level = 0f
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val scores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                val text = list?.firstOrNull()
                if (text.isNullOrBlank()) { error = "Không nhận được nội dung"; return }
                val conf = scores?.firstOrNull()?.takeIf { it >= 0f }
                partial = text
                onResult(text, conf)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    ?.let { partial = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        rec = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        r.startListening(i)
        listening = true
    }

    fun stop() {
        rec?.destroy()
        rec = null
        listening = false
        level = 0f
    }
}
