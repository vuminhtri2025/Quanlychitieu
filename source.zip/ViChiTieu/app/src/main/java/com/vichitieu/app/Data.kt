package com.vichitieu.app

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Txn(
    val id: Long,
    val amount: Long,
    val isExpense: Boolean,
    val time: Long,
    val category: String,
    val note: String
)

data class Budget(val category: String, val limit: Long)
data class Goal(val id: Long, val name: String, val target: Long, val saved: Long)

data class Cat(
    val name: String,
    val emoji: String,
    val color: Color,
    val isIncome: Boolean,
    val keywords: List<String>
)

val CATS = listOf(
    Cat("Ăn uống", "🍜", Color(0xFFFF762E), false,
        listOf("ăn", "uống", "cơm", "phở", "bún", "cà phê", "cafe", "trà sữa", "nhà hàng", "bữa", "trưa", "tối", "sáng", "bia", "nước")),
    Cat("Di chuyển", "🛵", Color(0xFF4F8DF7), false,
        listOf("xăng", "grab", "xe", "taxi", "gửi xe", "vé xe", "bus", "buýt", "di chuyển", "đổ xăng")),
    Cat("Mua sắm", "🛍️", Color(0xFFB36BFF), false,
        listOf("mua", "quần", "áo", "giày", "shopee", "lazada", "siêu thị", "đồ", "tạp hóa")),
    Cat("Hóa đơn", "🧾", Color(0xFFF2C94C), false,
        listOf("điện", "nước", "wifi", "internet", "thuê nhà", "tiền nhà", "hóa đơn", "điện thoại", "cước")),
    Cat("Giải trí", "🎬", Color(0xFFE94343), false,
        listOf("phim", "game", "du lịch", "xem", "karaoke", "netflix", "giải trí", "chơi")),
    Cat("Sức khỏe", "💊", Color(0xFF16A765), false,
        listOf("thuốc", "bệnh viện", "khám", "bác sĩ", "gym", "sức khỏe", "nha khoa")),
    Cat("Giáo dục", "📚", Color(0xFF2DD4BF), false,
        listOf("học", "sách", "khóa học", "học phí", "giáo dục")),
    Cat("Khác", "📦", Color(0xFF9AA0AA), false, emptyList()),
    Cat("Lương", "💰", Color(0xFF16A765), true,
        listOf("lương", "tiền lương")),
    Cat("Thưởng", "🎁", Color(0xFFFF762E), true,
        listOf("thưởng", "bonus", "lì xì")),
    Cat("Thu nhập khác", "💵", Color(0xFF2DD4BF), true,
        listOf("nhận", "thu nhập", "bán", "được cho", "hoàn tiền", "lãi"))
)

val EXPENSE_CATS = CATS.filter { !it.isIncome }
val INCOME_CATS = CATS.filter { it.isIncome }
fun catOf(name: String): Cat = CATS.firstOrNull { it.name == name } ?: CATS.first { it.name == "Khác" }

class AppState(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("vichitieu", Context.MODE_PRIVATE)
    val txns = mutableStateListOf<Txn>()
    val budgets = mutableStateListOf<Budget>()
    val goals = mutableStateListOf<Goal>()

    init { load() }

    fun upsert(t: Txn) {
        val i = txns.indexOfFirst { it.id == t.id }
        if (i >= 0) txns[i] = t else txns.add(t)
        save()
    }
    fun delete(id: Long) { txns.removeAll { it.id == id }; save() }

    fun setBudget(b: Budget) {
        val i = budgets.indexOfFirst { it.category == b.category }
        if (i >= 0) budgets[i] = b else budgets.add(b)
        save()
    }
    fun deleteBudget(cat: String) { budgets.removeAll { it.category == cat }; save() }

    fun upsertGoal(g: Goal) {
        val i = goals.indexOfFirst { it.id == g.id }
        if (i >= 0) goals[i] = g else goals.add(g)
        save()
    }
    fun deleteGoal(id: Long) { goals.removeAll { it.id == id }; save() }

    private fun save() {
        val t = JSONArray()
        txns.forEach {
            t.put(JSONObject().put("id", it.id).put("amount", it.amount).put("exp", it.isExpense)
                .put("time", it.time).put("cat", it.category).put("note", it.note))
        }
        val b = JSONArray()
        budgets.forEach { b.put(JSONObject().put("cat", it.category).put("limit", it.limit)) }
        val g = JSONArray()
        goals.forEach {
            g.put(JSONObject().put("id", it.id).put("name", it.name).put("target", it.target).put("saved", it.saved))
        }
        prefs.edit().putString("txns", t.toString()).putString("budgets", b.toString())
            .putString("goals", g.toString()).apply()
    }

    private fun load() {
        try {
            val t = JSONArray(prefs.getString("txns", "[]"))
            for (i in 0 until t.length()) {
                val o = t.getJSONObject(i)
                txns.add(Txn(o.getLong("id"), o.getLong("amount"), o.getBoolean("exp"),
                    o.getLong("time"), o.getString("cat"), o.optString("note", "")))
            }
            val b = JSONArray(prefs.getString("budgets", "[]"))
            for (i in 0 until b.length()) {
                val o = b.getJSONObject(i)
                budgets.add(Budget(o.getString("cat"), o.getLong("limit")))
            }
            val g = JSONArray(prefs.getString("goals", "[]"))
            for (i in 0 until g.length()) {
                val o = g.getJSONObject(i)
                goals.add(Goal(o.getLong("id"), o.getString("name"), o.getLong("target"), o.getLong("saved")))
            }
        } catch (_: Exception) { }
    }
}

// ---------- tiện ích ----------
fun money(v: Long): String {
    val s = kotlin.math.abs(v).toString().reversed().chunked(3).joinToString(".").reversed()
    return (if (v < 0) "-" else "") + s + " ₫"
}

fun moneyShort(v: Long): String = when {
    v >= 1_000_000_000 -> String.format("%.1ftỷ", v / 1e9)
    v >= 1_000_000 -> String.format("%.1ftr", v / 1e6)
    v >= 1_000 -> "${v / 1000}k"
    else -> v.toString()
}

fun cal(time: Long): Calendar = Calendar.getInstance().apply { timeInMillis = time }

fun sameMonth(time: Long, year: Int, month: Int): Boolean {
    val c = cal(time)
    return c.get(Calendar.YEAR) == year && c.get(Calendar.MONTH) == month
}

fun sameDay(a: Long, b: Long): Boolean {
    val x = cal(a); val y = cal(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

fun fmtDate(time: Long): String {
    val c = cal(time)
    return "%02d/%02d/%d".format(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR))
}

fun fmtTime(time: Long): String {
    val c = cal(time)
    return "%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
}
