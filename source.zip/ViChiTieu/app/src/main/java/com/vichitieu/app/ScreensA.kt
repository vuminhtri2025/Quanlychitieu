package com.vichitieu.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Calendar

const val CONFIDENCE_THRESHOLD = 0.8f

// ======================= TAB 1: TỔNG QUAN =======================
@Composable
fun OverviewScreen(s: AppState) {
    val now = Calendar.getInstance()
    val y = now.get(Calendar.YEAR)
    val m = now.get(Calendar.MONTH)
    val month = s.txns.filter { sameMonth(it.time, y, m) }
    val inc = month.filter { !it.isExpense }.sumOf { it.amount }
    val exp = month.filter { it.isExpense }.sumOf { it.amount }
    val total = s.txns.sumOf { if (it.isExpense) -it.amount else it.amount }
    val recent = s.txns.sortedByDescending { it.time }.take(5)
    var editing by remember { mutableStateOf<Txn?>(null) }

    editing?.let { e ->
        TxnDialog(e, "Sửa giao dịch",
            onSave = { s.upsert(it); editing = null },
            onDelete = { s.delete(e.id); editing = null },
            onDismiss = { editing = null })
    }

    // 7 ngày gần nhất
    val days = (6 downTo 0).map { k ->
        val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -k)
        val label = arrayOf("CN", "T2", "T3", "T4", "T5", "T6", "T7")[c.get(Calendar.DAY_OF_WEEK) - 1]
        label to s.txns.filter { it.isExpense && sameDay(it.time, c.timeInMillis) }.sumOf { it.amount }
    }
    val maxDay = (days.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)

    LazyColumn(
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("Tổng quan", "Your money. Always within reach.") }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Orange, Color(0xFFFF9A5C)))).padding(22.dp)
            ) {
                Text("Số dư hiện tại", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                Text(money(total), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                Text("Tháng ${m + 1}/$y: ${if (inc - exp >= 0) "+" else ""}${money(inc - exp)}",
                    color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Green).padding(18.dp)) {
                    Text("Thu nhập", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Text(money(inc), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Red).padding(18.dp)) {
                    Text("Chi tiêu", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Text(money(exp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Panel {
                Title("Chi tiêu 7 ngày qua")
                Spacer(Modifier.height(12.dp))
                Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                    val n = days.size
                    val slot = size.width / n
                    val bw = slot * 0.5f
                    days.forEachIndexed { i, d ->
                        val h = (d.second.toFloat() / maxDay) * (size.height - 4.dp.toPx())
                        val hh = if (d.second > 0) h.coerceAtLeast(6.dp.toPx()) else 4.dp.toPx()
                        drawRoundRect(
                            color = if (i == n - 1) Orange else Card2,
                            topLeft = Offset(i * slot + (slot - bw) / 2, size.height - hh),
                            size = Size(bw, hh),
                            cornerRadius = CornerRadius(8.dp.toPx())
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    days.forEach { Text(it.first, Modifier.weight(1f), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center) }
                }
            }
        }
        item { Title("Giao dịch gần đây") }
        if (recent.isEmpty()) {
            item { Text("Chưa có giao dịch. Sang tab Giọng nói để thêm khoản đầu tiên 🎙️", color = Muted, fontSize = 14.sp) }
        }
        items(recent) { t -> TxnRow(t) { editing = t } }
    }
}

// ======================= TAB 2: NHẬP BẰNG GIỌNG NÓI =======================
@Composable
fun VoiceScreen(s: AppState) {
    val ctx = LocalContext.current
    var draft by remember { mutableStateOf<Txn?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }
    var banner by remember { mutableStateOf<String?>(null) }
    var heard by remember { mutableStateOf("") }
    var heardConf by remember { mutableStateOf<Float?>(null) }
    var manual by remember { mutableStateOf(false) }

    val voice = remember {
        VoiceController(ctx) { text, conf ->
            heard = text
            heardConf = conf
            val p = VoiceParser.parse(text)
            val reasons = mutableListOf<String>()
            if (p.amount == null) reasons += "chưa nhận được số tiền"
            else if (!p.amountClear) reasons += "số tiền chưa rõ đơn vị"
            if (!p.categoryMatched) reasons += "chưa xác định được nhóm"
            if (conf != null && conf < CONFIDENCE_THRESHOLD) reasons += "độ tự tin thấp (${(conf * 100).toInt()}%)"
            val t = Txn(System.currentTimeMillis(), p.amount ?: 0L, p.isExpense, p.time, p.category, p.note)
            if (reasons.isEmpty()) {
                s.upsert(t)
                banner = "✓ Đã tự lưu: ${if (t.isExpense) "-" else "+"}${money(t.amount)} • ${t.category}"
            } else {
                banner = null
                hint = "Cần xác nhận: " + reasons.joinToString(", ")
                draft = t
            }
        }
    }
    DisposableEffect(Unit) { onDispose { voice.stop() } }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) voice.start() else voice.error = "Cần cấp quyền micro để nhập bằng giọng nói"
    }
    fun toggle() {
        banner = null
        if (voice.listening) voice.stop()
        else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            voice.start()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    draft?.let { d ->
        TxnDialog(d, "Xác nhận giao dịch", hint = hint,
            onSave = { s.upsert(it); draft = null; banner = "✓ Đã lưu giao dịch" },
            onDismiss = { draft = null })
    }
    if (manual) {
        TxnDialog(newTxn(), "Thêm giao dịch",
            onSave = { s.upsert(it); manual = false; banner = "✓ Đã lưu giao dịch" },
            onDismiss = { manual = false })
    }

    val pulse by animateFloatAsState(if (voice.listening) 1f + voice.level * 0.6f else 1f, label = "pulse")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Nhập bằng giọng nói", "Nói tự nhiên, ứng dụng sẽ tự tách thông tin")

        Box(Modifier.fillMaxWidth().height(230.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(150.dp).scale(pulse).clip(CircleShape).background(Orange.copy(alpha = 0.18f)))
            Box(
                Modifier.size(128.dp).clip(CircleShape)
                    .background(if (voice.listening) Red else Orange)
                    .clickable { toggle() },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (voice.listening) Icons.Rounded.Stop else Icons.Rounded.Mic, "Mic",
                    tint = Color.White, modifier = Modifier.size(56.dp))
            }
        }
        Text(
            if (voice.listening) "Đang nghe… chạm để dừng" else "Chạm vào micro để nói",
            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )

        voice.error?.let {
            Text(it, color = Red, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        banner?.let {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Green).padding(16.dp)) {
                Text(it, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
        val shown = if (voice.listening) voice.partial else heard
        if (shown.isNotBlank()) {
            Panel {
                Text("Bạn nói", color = Muted, fontSize = 12.sp)
                Text("“$shown”", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                if (!voice.listening) {
                    Text(
                        heardConf?.let { "Độ tự tin: ${(it * 100).toInt()}%" } ?: "Độ tự tin: không có dữ liệu",
                        color = Orange, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
        Panel {
            Text("Gợi ý cách nói", color = Muted, fontSize = 12.sp)
            Text("• “Ăn trưa 50 nghìn”\n• “Đổ xăng 80k hôm qua”\n• “Nhận lương 15 triệu”\n• “Trà sữa 45.000 đồng”",
                color = Color.White, fontSize = 14.sp, lineHeight = 22.sp)
            Text("Tự lưu khi độ tự tin ≥ ${(CONFIDENCE_THRESHOLD * 100).toInt()}% và đủ số tiền + nhóm. Nếu chưa chắc, ứng dụng sẽ hỏi xác nhận.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Card2)
                .clickable { manual = true }.padding(14.dp),
            contentAlignment = Alignment.Center
        ) { Text("✍️  Nhập tay", color = Color.White, fontWeight = FontWeight.SemiBold) }
    }
}
