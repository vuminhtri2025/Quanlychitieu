package com.vichitieu.app

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class TabItem(val label: String, val icon: ImageVector)

/**
 * Thanh tab: nhấn giữ lên thanh, trượt ngón tay sang tab muốn chọn (tab được phóng to + hiện tên),
 * thả tay để chuyển. Chạm nhanh vào tab cũng hoạt động như nhấn-thả.
 */
@Composable
fun HoldNavBar(
    tabs: List<TabItem>,
    selected: Int,
    hover: Int,
    onHover: (Int) -> Unit,
    onSelect: (Int) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF0E1013))
            .navigationBarsPadding()
            .height(68.dp)
            .pointerInput(tabs.size) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val n = tabs.size
                    fun idx(x: Float) = (x / size.width * n).toInt().coerceIn(0, n - 1)
                    var cur = idx(down.position.x)
                    onHover(cur)
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull() ?: break
                        if (!ch.pressed) break
                        val i = idx(ch.position.x)
                        if (i != cur) {
                            cur = i
                            onHover(cur)
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                        ch.consume()
                    }
                    onSelect(cur)
                    onHover(-1)
                }
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        tabs.forEachIndexed { i, t ->
            val active = if (hover >= 0) hover == i else selected == i
            val s by animateFloatAsState(if (hover == i) 1.25f else 1f, label = "tabScale")
            Column(
                Modifier.weight(1f).fillMaxHeight().scale(s),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.clip(RoundedCornerShape(50))
                        .background(if (active) Orange else Color.Transparent)
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Icon(t.icon, contentDescription = t.label,
                        tint = if (active) Color.White else Muted, modifier = Modifier.size(22.dp))
                }
                Text(t.label, fontSize = 10.sp, color = if (active) Color.White else Muted,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}
