package com.vichitieu.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

@Composable
fun Pill(text: String, selected: Boolean, color: Color = Orange, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) color else Card2)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun Bar(progress: Float, color: Color, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Card2)) {
        Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight()
            .clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, color: Color = CardBg, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(color).padding(18.dp),
        content = content
    )
}

@Composable
fun Title(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun ScreenHeader(title: String, sub: String) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text(sub, color = Muted, fontSize = 14.sp)
    }
}

@Composable
fun TxnRow(t: Txn, onClick: () -> Unit) {
    val c = catOf(t.category)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg)
            .clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(c.color.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center) { Text(c.emoji, fontSize = 20.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.category, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(if (t.note.isBlank()) fmtTime(t.time) else "${t.note} • ${fmtTime(t.time)}",
                color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text((if (t.isExpense) "-" else "+") + money(t.amount),
            color = if (t.isExpense) Red else Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun AmountField(value: String, onChange: (String) -> Unit, label: String = "Số tiền (₫)") {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(12)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
    val n = value.toLongOrNull()
    if (n != null && n > 0) Text(money(n), color = Orange, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
}

/** Hộp thoại thêm / sửa / xác nhận giao dịch: số tiền, ngày giờ, nhóm, ghi chú. */
@Composable
fun TxnDialog(
    initial: Txn,
    title: String,
    hint: String? = null,
    onSave: (Txn) -> Unit,
    onDelete: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var amount by remember { mutableStateOf(if (initial.amount > 0) initial.amount.toString() else "") }
    var expense by remember { mutableStateOf(initial.isExpense) }
    var time by remember { mutableStateOf(initial.time) }
    var category by remember { mutableStateOf(initial.category) }
    var note by remember { mutableStateOf(initial.note) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (hint != null) Text(hint, color = Orange, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Chi tiêu", expense, Red) {
                        expense = true
                        if (catOf(category).isIncome) category = "Khác"
                    }
                    Pill("Thu nhập", !expense, Green) {
                        expense = false
                        if (!catOf(category).isIncome) category = "Thu nhập khác"
                    }
                }
                AmountField(amount, { amount = it })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("📅 " + fmtDate(time), false) {
                        val c = cal(time)
                        DatePickerDialog(ctx, { _, y, m, d ->
                            val n = cal(time); n.set(y, m, d); time = n.timeInMillis
                        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    }
                    Pill("🕒 " + fmtTime(time), false) {
                        val c = cal(time)
                        TimePickerDialog(ctx, { _, h, mi ->
                            val n = cal(time); n.set(Calendar.HOUR_OF_DAY, h); n.set(Calendar.MINUTE, mi)
                            time = n.timeInMillis
                        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                    }
                }
                Text("Nhóm", color = Muted, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(if (expense) EXPENSE_CATS else INCOME_CATS) { c ->
                        Pill(c.emoji + " " + c.name, category == c.name, c.color) { category = c.name }
                    }
                }
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Ghi chú") }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = (amount.toLongOrNull() ?: 0L) > 0,
                onClick = {
                    onSave(initial.copy(amount = amount.toLong(), isExpense = expense, time = time,
                        category = category, note = note.trim()))
                }
            ) { Text("Lưu", color = Orange, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Xóa", color = Red) }
                TextButton(onClick = onDismiss) { Text("Hủy", color = Muted) }
            }
        }
    )
}

fun newTxn(): Txn = Txn(System.currentTimeMillis(), 0, true, System.currentTimeMillis(), "Khác", "")
