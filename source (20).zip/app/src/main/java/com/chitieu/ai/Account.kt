@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Tab Tài khoản: danh sách mục; mỗi mục mở một trang con (có nút quay lại). */
@Composable
fun AccountScreen(active: Boolean = true) {
    var page by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = active && page != null) { page = null }
    when (val p = page) {
        null -> AccountMenu { page = it }
        "budget" -> BudgetScreen { page = null }
        "debt" -> DebtScreen { page = null }
        else -> SettingsPage(p.orEmpty()) { page = null }
    }
}

private class ARow(
    val id: String, val emoji: String, val color: Color, val title: String,
    val sub: String = "", val badge: String = "", val badgeColor: Color = Fresh
)

@Composable
private fun AccountGroup(rows: List<ARow>, open: (String) -> Unit) {
    AppCard(Modifier.fillMaxWidth()) {
        rows.forEachIndexed { i, r ->
            Row(
                Modifier.fillMaxWidth().clickable { open(r.id) }.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBubble(r.emoji, r.color, 42.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(r.title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (r.badge.isNotEmpty()) {
                            Spacer(Modifier.width(8.dp))
                            Pill(r.badge, r.badgeColor)
                        }
                    }
                    if (r.sub.isNotEmpty()) Text(r.sub, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text("›", color = Muted, fontSize = 24.sp)
            }
            if (i < rows.size - 1) HorizontalDivider(Modifier.padding(start = 72.dp), color = Lilac)
        }
    }
}

@Composable
fun AccountMenu(open: (String) -> Unit) {
    val ctx = LocalContext.current
    var about by remember { mutableStateOf(false) }
    val name = Store.userName.trim()
    val ver = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    val openDebts = Store.debts.count { Store.remaining(it) > 0 }
    val budgetCount = Store.budgets.count { it.value > 0L }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Tài khoản") {
            Text(
                "Giới thiệu ⓘ",
                Modifier.clip(CircleShape).clickable { about = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                color = Muted, fontSize = 14.sp
            )
        }
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // ---- Hồ sơ
            AppCard(Modifier.fillMaxWidth(), color = Lilac, onClick = { open("ai") }) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(72.dp).background(Fresh, CircleShape), contentAlignment = Alignment.Center) {
                            Text(name.firstOrNull()?.uppercase() ?: "🙂", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(if (name.isEmpty()) "Chưa đặt tên" else name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("Trợ lý ${Store.aiName} • ${Store.persona}", color = Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("›", color = Muted, fontSize = 28.sp)
                }
            }
            // ---- Ví, ngân sách
            AccountGroup(
                listOf(
                    ARow("wallet", "👛", Fresh, "Ví của tôi", "${Store.wallets.size} ví"),
                    ARow("budget", "🎯", Color(0xFFF2994A), "Ngân sách", if (budgetCount > 0) "$budgetCount danh mục có hạn mức" else "Chưa đặt hạn mức")
                ), open
            )
            // ---- Tính năng
            AccountGroup(
                listOf(
                    ARow(
                        "auto", "⚡", Color(0xFFF2994A), "Tự động ghi giao dịch",
                        if (Store.autoSave) "Ngưỡng ${(Store.autoThreshold * 100).toInt()}% • AI đã học ${Auto.learned()} giao dịch" else "",
                        if (Store.autoSave) "Bật" else "Tắt", if (Store.autoSave) Fresh else Muted
                    ),
                    ARow(
                        "notif", "🔔", Color(0xFFE5645F), "Quét thông báo giao dịch",
                        if (Store.notifOn) (if (Store.notifMode == "selected") "Chỉ quét ${Store.notifAllow.size} app đã chọn" else "Quét mọi app") else "",
                        if (Store.notifOn) "Bật" else "Tắt", if (Store.notifOn) Fresh else Muted
                    ),
                    ARow("debt", "🤝", Color(0xFF8E6BDB), "Sổ nợ", if (openDebts > 0) "$openDebts khoản đang mở" else "Chưa có khoản nào"),
                    ARow("ai", "🤖", Color(0xFF4C8DDB), "Trợ lý AI", "${Store.aiName} • ${Store.persona} • " + if (Store.apiKey.isBlank()) "chưa kết nối Gemini" else "đã kết nối Gemini"),
                    ARow("voice", "🎙️", Color(0xFFE867A0), "Giọng nói", (if (Store.voiceMode == "gemini") "Ghi âm → Gemini nghe" else "Nhận diện của máy") + if (Store.voiceReply) " • đọc phản hồi" else ""),
                    ARow(
                        "travel", "✈️", Color(0xFF29B6D6), "Chế độ du lịch",
                        if (Store.travelOn) "${Store.travelName.trim().ifBlank { "Đang đi du lịch" }} • 1 ${Store.travelCur} = ${Travel.fmtForeign(Store.travelRate)}đ" else "Tắt",
                        if (Store.travelOn) "Bật" else "", Fresh
                    ),
                    ARow("theme", "🌙", Color(0xFF8A8494), "Giao diện", when (Store.themeMode) { "light" -> "Sáng"; "dark" -> "Tối (xám trắng)"; else -> "Theo hệ thống" }),
                    ARow("fx", "✨", Color(0xFF26A69A), "Hiệu ứng chat", if (Store.typeEffect) "Chữ hiện dần • ${Store.typeMs / 1000}s" else "Tắt"),
                    ARow("data", "📤", Color(0xFF3F8FE0), "Dữ liệu", "${Store.txs.size} giao dịch • xuất CSV")
                ), open
            )
        }
    }
    if (about) AlertDialog(
        onDismissRequest = { about = false }, title = { Text("Chi Tiêu AI") },
        text = { Text("Phiên bản $ver\nTrợ lý chi tiêu cá nhân: nhắn hoặc nói khoản chi, AI ghi sổ giúp bạn (dùng Google Gemini).") },
        confirmButton = { TextButton(onClick = { about = false }) { Text("Đóng") } }
    )
}

@Composable
fun SettingsPage(id: String, back: () -> Unit) {
    val title = when (id) {
        "ai" -> "🤖 Trợ lý AI & Gemini"; "auto" -> "⚡ Tự động ghi giao dịch"; "key" -> "🔑 Kết nối Gemini"; "voice" -> "🎙️ Giọng nói"
        "fx" -> "✨ Hiệu ứng chat"; "notif" -> "🔔 Quét thông báo"; "wallet" -> "👛 Ví của tôi"; "theme" -> "🌙 Giao diện"; "travel" -> "✈️ Chế độ du lịch"; else -> "📤 Dữ liệu"
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại") }
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (id) {
                "ai" -> {
                    KeySettings()
                    AiSettings()
                }
                "auto" -> AutoSettings()
                "notif" -> NotifSettings()
                "key" -> KeySettings()
                "voice" -> VoiceSettings()
                "fx" -> FxSettings()
                "wallet" -> WalletSettings()
                "theme" -> ThemeSettings()
                "travel" -> TravelSettings()
                else -> DataSettings()
            }
        }
    }
}
