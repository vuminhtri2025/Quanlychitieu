package com.chitieu.ai

import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onStop() {
        Store.flush()   // đảm bảo dữ liệu đã ghi xong trước khi app xuống nền
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        NotifScan.drain(this)   // quét lại thông báo còn chờ nếu đã có mạng
        Store.systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        setContent {
            val dark = isDark
            val bg = Lavender
            val bar = Paper
            val view = LocalView.current
            SideEffect {
                window.statusBarColor = bg.toArgb()
                window.navigationBarColor = bar.toArgb()
                window.setBackgroundDrawable(ColorDrawable(bg.toArgb()))
                val c = WindowInsetsControllerCompat(window, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
            AppTheme { App() }
        }
    }
}

@Composable
fun App() {
    val tabs = listOf("💬" to "Chat", "📒" to "Giao dịch", "👤" to "Tài khoản")
    val pager = rememberPagerState { tabs.size }
    val scope = rememberCoroutineScope()
    Scaffold(
        containerColor = Lavender,
        bottomBar = {
            Surface(color = Paper, shadowElevation = 12.dp, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)) {
                NavigationBar(containerColor = Color.Transparent, tonalElevation = 0.dp) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = pager.currentPage == i,
                            onClick = { scope.launch { pager.animateScrollToPage(i) } },
                            icon = { Text(t.first, fontSize = 20.sp) },
                            label = { Text(t.second, fontSize = 12.sp, maxLines = 1, softWrap = false) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Lilac, selectedTextColor = Fresh, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        HorizontalPager(state = pager, modifier = Modifier.padding(pad), beyondViewportPageCount = tabs.size) { page ->
            Surface(Modifier.fillMaxSize(), color = Lavender) {
                when (page) {
                    0 -> ChatScreen(pager.currentPage == 0)
                    1 -> TransactionsScreen()
                    else -> AccountScreen(pager.currentPage == 2)
                }
            }
        }
    }
}
