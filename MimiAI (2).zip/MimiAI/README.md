# MimiAI – Quản lý chi tiêu bằng chat & giọng nói (Kotlin + Jetpack Compose)

- Nhắn tin / nói: "Sáng nay ăn phở 45k", "Cho Nam vay 500k", "Nam trả nợ 200k", "Chuyển 1 triệu từ tiền mặt sang ngân hàng"
- Nhiều ví, cho vay / đi vay / trả nợ, ngân sách, thống kê
- Gemini AI (tùy chọn) – nhập API key trong Cài đặt
- Keystore: app/keystore/mimi-release.jks (alias `mimi`) – giữ nguyên để cập nhật app

## Cấu trúc màn hình
- Tab **Chat**: trò chuyện + giọng nói, thẻ xác nhận giao dịch
- Tab **Giao dịch**: tổng tài sản, thu/chi, biểu đồ, sổ giao dịch theo tháng
- Tab **Tài khoản**: Ví của tôi, Ngân sách, Sổ nợ, Tự động ghi giao dịch, Giao dịch định kì, Hóa đơn, Công cụ
