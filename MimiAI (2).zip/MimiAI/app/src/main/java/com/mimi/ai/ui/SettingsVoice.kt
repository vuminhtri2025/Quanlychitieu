package com.mimi.ai.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mimi.ai.data.Wallet
import com.mimi.ai.data.fmt
import com.mimi.ai.data.parseSigned
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

// ============================================================ QUẢN LÝ VÍ

private val walletIcons = listOf("💵", "🏦", "📱", "💳", "👛", "🪙", "🏧", "💰", "🐷", "📈")

@Composable
fun WalletsScreen(vm: MimiViewModel, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<Wallet?>(null) }
    var adding by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundBtn("←") { onBack() }
            T("Quản lý ví", 22, FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 12.dp))
            RoundBtn("＋", C.green, Color.White) { adding = true }
        }
        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), color = C.lilac) {
            Column(Modifier.padding(18.dp)) {
                T("Tổng tài sản", 14, FontWeight.SemiBold)
                T(fmt(vm.totalAssets()), 30, FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            vm.wallets.forEach { w ->
                Card20(Modifier.fillMaxWidth().clickable { editing = w }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(w.icon, C.lilac, 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            T(w.name, 16, FontWeight.Bold)
                            if (w.id == vm.settings.defaultWalletId) T("⭐ Ví mặc định", 12, color = C.green)
                        }
                        val b = vm.balance(w)
                        T(fmt(b), 17, FontWeight.Bold, if (b < 0) C.red else C.ink)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.padding(horizontal = 20.dp)) { Tip("Chạm vào ví để đổi tên, chỉnh số dư hoặc đặt làm ví mặc định. Câu nhắn như “ăn phở 45k bằng momo” sẽ tự chọn đúng ví.") }
    }

    if (adding) WalletDialog(vm, null) { adding = false }
    editing?.let { w -> WalletDialog(vm, w) { editing = null } }
}

@Composable
private fun WalletDialog(vm: MimiViewModel, w: Wallet?, onClose: () -> Unit) {
    var name by remember { mutableStateOf(w?.name ?: "") }
    var icon by remember { mutableStateOf(w?.icon ?: "💵") }
    var balance by remember { mutableStateOf(if (w != null) vm.balance(w).toString() else "0") }
    var confirmDelete by remember { mutableStateOf(false) }

    Dialog2(if (w == null) "Thêm ví" else "Sửa ví", onClose, "Lưu", onConfirm = {
        if (name.isNotBlank()) {
            if (w == null) vm.addWallet(name, icon, parseSigned(balance)) else vm.editWallet(w, name, icon, parseSigned(balance))
            onClose()
        }
    }) {
        TextInput(name, { name = it }, "Tên ví")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            walletIcons.forEach { ic ->
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(if (ic == icon) C.greenSoft else C.lilac)
                        .border(if (ic == icon) 2.dp else 0.dp, if (ic == icon) C.green else Color.Transparent, CircleShape)
                        .clickable { icon = ic },
                    contentAlignment = Alignment.Center
                ) { T(ic, 20) }
            }
        }
        MoneyField(balance, { balance = it }, "Số dư hiện tại", allowNegative = true)
        if (w != null) {
            if (w.id != vm.settings.defaultWalletId) {
                Box(Modifier.clip(RoundedCornerShape(50)).background(C.greenSoft).clickable {
                    vm.updateSettings(vm.settings.copy(defaultWalletId = w.id)); onClose()
                }.padding(horizontal = 16.dp, vertical = 9.dp)) { T("⭐ Đặt làm ví mặc định", 14, FontWeight.SemiBold, C.green) }
            }
            if (vm.canDeleteWallet(w)) {
                if (!confirmDelete) {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(C.redSoft).clickable { confirmDelete = true }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                        T("🗑 Xóa ví", 14, FontWeight.SemiBold, C.red)
                    }
                } else {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(C.red).clickable { vm.deleteWallet(w); onClose() }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                        T("Xác nhận xóa ví", 14, FontWeight.SemiBold, Color.White)
                    }
                }
            } else T("Ví đã có giao dịch (hoặc là ví duy nhất) nên không thể xóa.", 12, color = C.sub)
        }
    }
}

// ============================================================ GHI ÂM GIỌNG NÓI

@Composable
fun VoiceOverlay(onResult: (String) -> Unit, onClose: () -> Unit) {
    val ctx: Context = LocalContext.current
    var partial by remember { mutableStateOf("") }
    var level by remember { mutableFloatStateOf(0f) }
    var seconds by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(true) }
    var restart by remember { mutableIntStateOf(0) }
    var phase by remember { mutableFloatStateOf(0f) }
    val available = remember { SpeechRecognizer.isRecognitionAvailable(ctx) }

    val recognizer = remember { if (available) SpeechRecognizer.createSpeechRecognizer(ctx) else null }

    DisposableEffect(restart) {
        val r = recognizer
        if (r != null) {
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) { level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    listening = false
                    message = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Mình chưa nghe rõ, bạn thử nói lại nhé."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Nhận dạng giọng nói cần kết nối mạng."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Chưa cấp quyền micro cho ứng dụng."
                        else -> "Không ghi âm được (mã $error). Bạn thử lại nhé."
                    }
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) onResult(text) else {
                        listening = false
                        message = "Mình chưa nghe rõ, bạn thử nói lại nhé."
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            partial = ""
            message = ""
            seconds = 0
            listening = true
            r.startListening(intent)
        }
        onDispose { recognizer?.cancel() }
    }
    DisposableEffect(Unit) { onDispose { recognizer?.destroy() } }

    LaunchedEffect(listening, restart) {
        while (listening) {
            delay(1000)
            seconds++
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60)
            phase += 0.5f
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF1E1B26)).statusBarsPadding().pointerInput(Unit) { detectTapGestures { } }) {
        Box(Modifier.align(Alignment.TopEnd).padding(20.dp)) { RoundBtn("✕", Color(0x33FFFFFF), Color.White) { onClose() } }

        Column(Modifier.align(Alignment.Center).padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            T(
                when {
                    !available -> "Thiết bị không hỗ trợ nhận dạng giọng nói"
                    listening -> "Đang ghi âm..."
                    else -> "Đã dừng"
                },
                20, FontWeight.Medium, Color.White
            )
            Spacer(Modifier.height(28.dp))
            // Sóng âm
            Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                val bars = 29
                val gap = size.width / bars
                for (i in 0 until bars) {
                    val envelope = 1f - abs(i - bars / 2f) / (bars / 2f)
                    val wave = (sin((i * 0.7f + phase).toDouble()).toFloat() + 1f) / 2f
                    val amp = if (listening) (0.12f + level * 0.88f * wave) * (0.35f + envelope * 0.65f) else 0.06f
                    val h = (size.height * amp).coerceAtLeast(6f)
                    drawRoundRect(
                        Brush.verticalGradient(listOf(Color(0xFFB388FF), Color(0xFF4FE0A0))),
                        Offset(i * gap + gap * 0.25f, (size.height - h) / 2f),
                        Size(gap * 0.5f, h),
                        CornerRadius(gap * 0.25f)
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
            val mm = seconds / 60
            val ss = seconds % 60
            T("%02d:%02d".format(mm, ss), 40, FontWeight.Bold, Color.White)
            Spacer(Modifier.height(24.dp))
            if (available) {
                Box(
                    Modifier.size(84.dp).clip(CircleShape).border(2.dp, Color(0xFFB388FF), CircleShape).clickable {
                        if (listening) {
                            recognizer?.stopListening()
                        } else {
                            restart++
                        }
                    },
                    contentAlignment = Alignment.Center
                ) { T(if (listening) "⏸" else "🎤", 30, color = Color.White) }
            }
            Spacer(Modifier.height(22.dp))
            val line = when {
                message.isNotEmpty() -> message
                partial.isNotBlank() -> "Nói: “$partial”"
                listening -> "Hãy nói, ví dụ: “Ăn trưa 120 nghìn”"
                else -> ""
            }
            T(line, 15, color = Color(0xFFB9B3C7), align = TextAlign.Center)
            if (!listening && available) {
                Spacer(Modifier.height(6.dp))
                T("Chạm nút micro để nói lại", 12, color = Color(0xFF8E88A0))
            }
        }
    }
}
