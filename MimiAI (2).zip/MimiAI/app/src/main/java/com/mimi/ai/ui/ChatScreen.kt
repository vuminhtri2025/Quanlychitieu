package com.mimi.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mimi.ai.data.Cats
import com.mimi.ai.data.Tx
import com.mimi.ai.data.TxType
import com.mimi.ai.data.fmt
import com.mimi.ai.data.parseMoney

@Composable
fun ChatScreen(vm: MimiViewModel, onMic: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Pair<String, Tx>?>(null) }
    var menu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val count = vm.messages.size + if (vm.thinking) 1 else 0

    LaunchedEffect(count, vm.messages.lastOrNull()?.status) {
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Column(Modifier.fillMaxWidth()) {
        // Header: Mimi + trạng thái
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            MimiAvatar(48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T("Mimi", 22, FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(C.green))
                    Spacer(Modifier.width(6.dp))
                    T(if (vm.thinking) "Đang suy nghĩ..." else "Đang hoạt động", 13, color = C.green)
                }
            }
            Box {
                RoundBtn("⋯") { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Xóa cuộc trò chuyện") }, onClick = { menu = false; vm.clearChat() })
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(vm.messages, key = { it.id }) { m ->
                MessageItem(vm, m, onEdit = { m.tx?.let { t -> editing = m.id to t } })
            }
            if (vm.thinking) {
                item(key = "thinking") { Bubble("Mimi đang suy nghĩ…", false) }
            }
        }

        // Gợi ý nhanh
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickChip("🎙️ Ghi bằng giọng nói") { onMic() }
            QuickChip("📊 Chi tiêu tháng này") { vm.send("Chi tiêu tháng này") }
            QuickChip("💰 Số dư các ví") { vm.send("Số dư các ví") }
            QuickChip("💳 Tình hình nợ") { vm.send("Tình hình nợ") }
            QuickChip("💡 Tư vấn tiết kiệm") { vm.send("Tư vấn tiết kiệm") }
        }

        // Ô nhập
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Nhập nội dung...", color = C.sub) },
                shape = InputShape,
                maxLines = 4,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = C.lilac, unfocusedContainerColor = C.lilac,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = C.green
                ),
                modifier = Modifier.weight(1f)
            )
            RoundBtn("🎤", C.lilac, C.green, 48.dp) { onMic() }
            RoundBtn("➤", C.green, Color.White, 48.dp) {
                if (input.isNotBlank()) {
                    vm.send(input)
                    input = ""
                }
            }
        }
    }

    editing?.let { (msgId, tx) ->
        TxEditDialog(
            vm = vm, initial = tx, title = "Chỉnh sửa giao dịch",
            onDismiss = { editing = null },
            onSave = { vm.updateProposal(msgId, it); editing = null }
        )
    }
}

@Composable
private fun QuickChip(text: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(C.white).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) { T(text, 13, FontWeight.Medium) }
}

@Composable
private fun Bubble(text: String, fromUser: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier.widthIn(max = 300.dp).clip(CardShape).background(if (fromUser) C.userBubble else C.lilac)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) { T(text, 15) }
    }
}

@Composable
private fun MessageItem(vm: MimiViewModel, m: com.mimi.ai.data.ChatMsg, onEdit: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Bubble(m.text, m.fromUser)
        val tx = m.tx
        if (tx != null) ProposalCard(vm, m.id, tx, m.status, onEdit)
    }
}

@Composable
private fun ProposalCard(vm: MimiViewModel, msgId: String, tx: Tx, status: Int, onEdit: () -> Unit) {
    val outflow = tx.type.sign < 0
    val amountColor = when {
        tx.type == TxType.TRANSFER -> C.ink
        outflow -> C.red
        else -> C.green
    }
    val sign = when {
        tx.type == TxType.TRANSFER -> ""
        outflow -> "-"
        else -> "+"
    }
    Card20(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Box(Modifier.clip(RoundedCornerShape(50)).background(C.greenSoft).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    T("AI nhận diện", 12, FontWeight.SemiBold, C.green)
                }
            }
            T(sign + fmt(tx.amount), 30, FontWeight.Bold, amountColor)
            Spacer(Modifier.size(10.dp))
            InfoRow("Loại", tx.type.label)
            if (tx.type.isDebt) InfoRow("Người", tx.person.ifBlank { "Chưa rõ" })
            else if (tx.type != TxType.TRANSFER) InfoRow("Danh mục", tx.category)
            if (tx.type == TxType.TRANSFER) {
                InfoRow("Từ ví", vm.walletName(tx.walletId))
                InfoRow("Đến ví", vm.walletName(tx.toWalletId))
            } else InfoRow("Ví", vm.walletName(tx.walletId))
            InfoRow("Nội dung", tx.note)
            Spacer(Modifier.size(12.dp))
            when (status) {
                0 -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        Modifier.weight(1.3f).clip(RoundedCornerShape(50)).background(Color(0xFF08843C)).clickable { vm.confirm(msgId) }
                            .padding(vertical = 13.dp),
                        contentAlignment = Alignment.Center
                    ) { T("Xác nhận", 16, FontWeight.Bold, Color.White) }
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(50)).clickable { onEdit() }.padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
                        T("Chỉnh sửa", 15, FontWeight.Medium, C.sub)
                    }
                    Box(Modifier.clip(RoundedCornerShape(50)).clickable { vm.cancel(msgId) }.padding(horizontal = 12.dp, vertical = 13.dp)) {
                        T("Hủy", 14, color = C.red)
                    }
                }
                1 -> T("✅ Đã ghi vào sổ", 14, FontWeight.SemiBold, C.green)
                else -> T("Đã hủy", 14, color = C.sub)
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        T(label, 15, color = C.sub, modifier = Modifier.width(96.dp))
        T(value, 15, FontWeight.SemiBold, modifier = Modifier.weight(1f), align = TextAlign.End)
    }
}

// ============================================================ Hộp thoại thêm / sửa giao dịch (dùng chung)

@Composable
fun TxEditDialog(vm: MimiViewModel, initial: Tx, title: String, onDismiss: () -> Unit, onSave: (Tx) -> Unit) {
    var type by remember { mutableStateOf(initial.type) }
    var amount by remember { mutableStateOf(if (initial.amount > 0) initial.amount.toString() else "") }
    var category by remember { mutableStateOf(initial.category) }
    var walletId by remember { mutableStateOf(initial.walletId.ifBlank { vm.wallets.first().id }) }
    var toWalletId by remember { mutableStateOf(initial.toWalletId.ifBlank { vm.wallets.firstOrNull { it.id != walletId }?.id ?: walletId }) }
    var person by remember { mutableStateOf(initial.person) }
    var note by remember { mutableStateOf(initial.note) }
    var error by remember { mutableStateOf("") }

    val basic = initial.type == TxType.INCOME || initial.type == TxType.EXPENSE || initial.type == TxType.TRANSFER
    val cats = if (type == TxType.INCOME) Cats.income else Cats.expense

    Dialog2(title, onDismiss, "Lưu", onConfirm = {
        val a = parseMoney(amount)
        when {
            a <= 0 -> error = "Hãy nhập số tiền lớn hơn 0"
            type == TxType.TRANSFER && walletId == toWalletId -> error = "Hai ví phải khác nhau"
            type.isDebt && person.isBlank() -> error = "Hãy nhập tên người"
            else -> {
                val cat = when {
                    type == TxType.TRANSFER -> "Chuyển ví"
                    type.isDebt -> type.label
                    cats.none { it.name == category } -> cats.last().name
                    else -> category
                }
                onSave(
                    initial.copy(
                        type = type, amount = a, category = cat, walletId = walletId,
                        toWalletId = if (type == TxType.TRANSFER) toWalletId else "",
                        person = if (type.isDebt) person.trim() else "", note = note.trim()
                    )
                )
            }
        }
    }) {
        if (basic) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TxType.EXPENSE, TxType.INCOME, TxType.TRANSFER).forEach { tp ->
                    Pill(tp.label, type == tp) {
                        type = tp
                        if (tp != TxType.TRANSFER && cats.none { it.name == category }) category = ""
                    }
                }
            }
        } else {
            T("Loại: ${type.label}", 14, FontWeight.SemiBold, C.green)
        }
        MoneyField(amount, { amount = it })
        if (type.isDebt) {
            TextInput(person, { person = it }, "Người liên quan")
        } else if (type != TxType.TRANSFER) {
            val shown = if (cats.any { it.name == category }) category else cats.last().name
            Picker("Danh mục", Cats.find(shown).icon + " " + shown, cats.map { it.icon + " " + it.name }) { category = cats[it].name }
        }
        Picker(if (type == TxType.TRANSFER) "Từ ví" else "Ví", vm.walletName(walletId), vm.wallets.map { it.icon + " " + it.name }) { walletId = vm.wallets[it].id }
        if (type == TxType.TRANSFER) {
            Picker("Đến ví", vm.walletName(toWalletId), vm.wallets.map { it.icon + " " + it.name }) { toWalletId = vm.wallets[it].id }
        }
        TextInput(note, { note = it }, "Nội dung")
        if (error.isNotEmpty()) T(error, 13, color = C.red)
    }
}
