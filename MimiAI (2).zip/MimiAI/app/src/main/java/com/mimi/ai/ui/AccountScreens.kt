package com.mimi.ai.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mimi.ai.data.Bill
import com.mimi.ai.data.Cats
import com.mimi.ai.data.Recurring
import com.mimi.ai.data.TxType
import com.mimi.ai.data.fmt
import com.mimi.ai.data.fmtDate
import com.mimi.ai.data.newId
import com.mimi.ai.data.parseDate
import com.mimi.ai.data.parseMoney

// ============================================================ DÒNG MENU DÙNG CHUNG

@Composable
fun MenuRow(
    icon: String,
    title: String,
    sub: String? = null,
    badge: String? = null,
    toggle: Boolean? = null,
    last: Boolean = false,
    onClick: () -> Unit
) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBubble(icon, C.lilac, 42.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(title, 16, FontWeight.SemiBold)
                    if (badge != null) {
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(C.green).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            T(badge, 11, FontWeight.Bold, Color.White)
                        }
                    }
                }
                if (sub != null) T(sub, 12, color = C.sub)
            }
            if (toggle != null) {
                Switch(
                    checked = toggle, onCheckedChange = { onClick() },
                    colors = SwitchDefaults.colors(checkedTrackColor = C.green, checkedThumbColor = Color.White)
                )
            } else T("›", 22, color = C.sub)
        }
        if (!last) Box(Modifier.fillMaxWidth().padding(start = 72.dp).height(1.dp).background(C.line.copy(alpha = 0.6f)))
    }
}

// ============================================================ TÀI KHOẢN

@Composable
fun AccountScreen(vm: MimiViewModel, onOpen: (String) -> Unit) {
    val s = vm.settings
    var editName by remember { mutableStateOf(false) }
    val dueBills = vm.bills.count { !vm.billPaid(it) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        ScreenTitle("Tài khoản")

        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clickable { editName = true }) {
            Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(72.dp).clip(CircleShape).background(C.green), contentAlignment = Alignment.Center) {
                    T(s.userName.take(1).uppercase(), 30, FontWeight.Bold, Color.White)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFFF9800)).padding(horizontal = 14.dp, vertical = 3.dp)) {
                    T("THÀNH VIÊN MIMI", 11, FontWeight.Bold, Color.White)
                }
                Spacer(Modifier.height(6.dp))
                T(s.userName, 20, FontWeight.Bold)
                T("Chạm để đổi tên • Dữ liệu lưu trên máy bạn", 12, color = C.sub)
            }
        }
        Spacer(Modifier.height(14.dp))

        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth()) {
            Column {
                MenuRow("👛", "Ví của tôi", "${vm.wallets.size} ví • Tổng ${fmt(vm.totalAssets())}") { onOpen("wallets") }
                MenuRow("🎯", "Ngân sách", if (vm.totalBudget() > 0) "Tổng hạn mức ${fmt(vm.totalBudget())}/tháng" else "Chưa đặt hạn mức") { onOpen("budget") }
                MenuRow("💳", "Sổ nợ", "Nợ phải trả ${fmt(vm.totalIOwe())} • Phải thu ${fmt(vm.totalOwedToMe())}") { onOpen("debts") }
                MenuRow("🔔", "Tự động ghi giao dịch", if (s.autoSave) "Đang bật" else "Đang tắt", badge = "Mới") { onOpen("auto") }
                MenuRow("🔁", "Giao dịch định kì", "${vm.recurring.size} giao dịch") { onOpen("recurring") }
                MenuRow("🧾", "Hóa đơn", if (dueBills > 0) "$dueBills hóa đơn chưa thanh toán tháng này" else "${vm.bills.size} hóa đơn") { onOpen("bills") }
                MenuRow("🧰", "Công cụ", "Xuất dữ liệu, xóa dữ liệu, giới thiệu", last = true) { onOpen("tools") }
            }
        }
    }

    if (editName) {
        var n by remember { mutableStateOf(s.userName) }
        Dialog2("Tên của bạn", { editName = false }, "Lưu", onConfirm = {
            vm.updateSettings(s.copy(userName = n.trim().ifBlank { "Bạn" }))
            editName = false
        }) { TextInput(n, { n = it }, "Tên hiển thị") }
    }
}

// ============================================================ TỰ ĐỘNG GHI GIAO DỊCH / AI

@Composable
fun AutoScreen(vm: MimiViewModel, onBack: () -> Unit) {
    val s = vm.settings
    var gemini by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        SubHeader("Tự động ghi giao dịch", onBack)
        Box(Modifier.padding(horizontal = 20.dp)) {
            Tip(
                "Khi bật, khoản thu/chi Mimi nhận diện từ tin nhắn hoặc giọng nói sẽ được ghi thẳng vào sổ, không cần bấm Xác nhận. " +
                    "Giao dịch nợ và chuyển ví luôn cần bạn xác nhận.",
                "🔔"
            )
        }
        Spacer(Modifier.height(14.dp))
        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth()) {
            Column {
                MenuRow("⚡", "Tự động lưu giao dịch", "Bỏ qua bước xác nhận với thu/chi", toggle = s.autoSave) {
                    vm.updateSettings(s.copy(autoSave = !s.autoSave))
                }
                MenuRow("🤖", "Dùng Gemini AI", if (s.useAi) "Đang bật • ${s.geminiModel}" else "Tắt • dùng bộ phân tích nội bộ", toggle = s.useAi) {
                    if (s.geminiKey.isBlank()) gemini = true else vm.updateSettings(s.copy(useAi = !s.useAi))
                }
                MenuRow("🔑", "Kết nối Gemini", if (s.geminiKey.isBlank()) "Chưa có API key" else "Đã lưu API key", last = true) { gemini = true }
            }
        }
    }

    if (gemini) {
        var key by remember { mutableStateOf(s.geminiKey) }
        var model by remember { mutableStateOf(s.geminiModel) }
        Dialog2("Kết nối Gemini", { gemini = false }, "Lưu & bật", onConfirm = {
            vm.updateSettings(s.copy(geminiKey = key.trim(), geminiModel = model.trim().ifBlank { "gemini-2.5-flash-lite" }, useAi = key.isNotBlank()))
            gemini = false
        }) {
            T("Dán API key từ Google AI Studio. Khi lỗi mạng, Mimi tự dùng bộ phân tích nội bộ. Key chỉ lưu trên máy bạn.", 13, color = C.sub)
            TextInput(key, { key = it }, "Gemini API key")
            TextInput(model, { model = it }, "Tên model")
        }
    }
}

// ============================================================ CÔNG CỤ

@Composable
fun ToolsScreen(vm: MimiViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf("") }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        SubHeader("Công cụ", onBack)
        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth()) {
            Column {
                MenuRow("📤", "Xuất dữ liệu (JSON)", "Chia sẻ bản sao lưu dữ liệu của bạn") {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "MimiAI backup")
                        putExtra(Intent.EXTRA_TEXT, vm.exportJson())
                    }
                    ctx.startActivity(Intent.createChooser(send, "Xuất dữ liệu").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                MenuRow("🗑️", "Xóa toàn bộ dữ liệu", "Giao dịch, nợ, ngân sách, hóa đơn và chat") { dialog = "reset" }
                MenuRow("ℹ️", "Giới thiệu ứng dụng", "MimiAI • Quản lý chi tiêu bằng trò chuyện", last = true) { dialog = "about" }
            }
        }
    }

    when (dialog) {
        "reset" -> Dialog2("Xóa toàn bộ dữ liệu?", { dialog = "" }, "Xóa", onConfirm = { vm.clearAll(); dialog = "" }) {
            T("Toàn bộ giao dịch, khoản nợ, ngân sách, hóa đơn, giao dịch định kì và lịch sử chat sẽ bị xóa. Các ví được giữ lại với số dư 0. Không thể hoàn tác.", 14)
        }
        "about" -> Dialog2("MimiAI", { dialog = "" }) {
            T("Ghi chi tiêu bằng cách nhắn tin hoặc nói chuyện với Mimi. Hỗ trợ nhiều ví, cho vay / đi vay, theo dõi trả nợ, hóa đơn và giao dịch định kì. Dữ liệu lưu ngay trên điện thoại của bạn.", 14)
        }
    }
}

// ============================================================ GIAO DỊCH ĐỊNH KÌ

private val freqNames = listOf("Hằng ngày", "Hằng tuần", "Hằng tháng")

@Composable
fun RecurringScreen(vm: MimiViewModel, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<Recurring?>(null) }
    var adding by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        SubHeader("Giao dịch định kì", onBack) { RoundBtn("＋", C.green, Color.White) { adding = true } }
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (vm.recurring.isEmpty()) {
                T("Chưa có giao dịch định kì.\nBấm ＋ để thêm khoản tự lặp như lương, tiền nhà, Netflix...", 14, color = C.sub)
            }
            vm.recurring.forEach { r ->
                val income = r.type == TxType.INCOME
                Card20(Modifier.fillMaxWidth().clickable { editing = r }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Cats.find(r.category).icon, if (income) C.greenSoft else C.redSoft, 46.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            T(r.note.ifBlank { r.category }, 15, FontWeight.SemiBold, maxLines = 1)
                            T(
                                freqNames[r.freq.coerceIn(0, 2)] + " • " + (if (r.active) "Kế tiếp ${fmtDate(r.nextAt)}" else "Tạm dừng") +
                                    " • " + vm.walletName(r.walletId),
                                12, color = C.sub, maxLines = 1
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            T((if (income) "+" else "-") + fmt(r.amount), 15, FontWeight.Bold, if (income) C.green else C.red)
                            Switch(
                                checked = r.active, onCheckedChange = { vm.saveRecurring(r.copy(active = it)) },
                                colors = SwitchDefaults.colors(checkedTrackColor = C.green, checkedThumbColor = Color.White)
                            )
                        }
                    }
                }
            }
            Tip("Giao dịch định kì được tạo tự động mỗi khi bạn mở ứng dụng, cho tất cả các kỳ đã đến hạn.", "🔁")
        }
    }

    if (adding) RecurringDialog(vm, null) { adding = false }
    editing?.let { r -> RecurringDialog(vm, r) { editing = null } }
}

@Composable
private fun RecurringDialog(vm: MimiViewModel, r: Recurring?, onClose: () -> Unit) {
    var type by remember { mutableStateOf(r?.type ?: TxType.EXPENSE) }
    var amount by remember { mutableStateOf(r?.amount?.toString() ?: "") }
    var category by remember { mutableStateOf(r?.category ?: "Hóa đơn") }
    var walletId by remember { mutableStateOf(r?.walletId ?: vm.settings.defaultWalletId.ifBlank { vm.wallets.first().id }) }
    var freq by remember { mutableIntStateOf(r?.freq ?: 2) }
    var date by remember { mutableStateOf(fmtDate(r?.nextAt ?: System.currentTimeMillis())) }
    var note by remember { mutableStateOf(r?.note ?: "") }
    var error by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }

    val cats = if (type == TxType.INCOME) Cats.income else Cats.expense
    val shownCat = if (cats.any { it.name == category }) category else cats.last().name

    Dialog2(if (r == null) "Thêm giao dịch định kì" else "Sửa giao dịch định kì", onClose, "Lưu", onConfirm = {
        val a = parseMoney(amount)
        val d = parseDate(date)
        when {
            a <= 0 -> error = "Hãy nhập số tiền"
            d == 0L -> error = "Ngày sai định dạng (dd/MM/yyyy)"
            else -> {
                val keep = r != null && date == fmtDate(r.nextAt)
                vm.saveRecurring(
                    Recurring(
                        id = r?.id ?: newId(), type = type, amount = a, category = shownCat, walletId = walletId,
                        note = note.trim(), freq = freq, nextAt = if (keep) r!!.nextAt else d, active = r?.active ?: true
                    )
                )
                onClose()
            }
        }
    }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Chi", type == TxType.EXPENSE) { type = TxType.EXPENSE }
            Pill("Thu", type == TxType.INCOME) { type = TxType.INCOME }
        }
        MoneyField(amount, { amount = it })
        Picker("Danh mục", Cats.find(shownCat).icon + " " + shownCat, cats.map { it.icon + " " + it.name }) { category = cats[it].name }
        Picker("Ví", vm.walletName(walletId), vm.wallets.map { it.icon + " " + it.name }) { walletId = vm.wallets[it].id }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            freqNames.forEachIndexed { i, n -> Pill(n, freq == i) { freq = i } }
        }
        TextInput(date, { date = it }, "Ngày kế tiếp (dd/MM/yyyy)")
        T("Nếu ngày đã qua, các kỳ đã đến hạn sẽ được tạo ngay.", 12, color = C.sub)
        TextInput(note, { note = it }, "Nội dung")
        if (error.isNotEmpty()) T(error, 13, color = C.red)
        if (r != null) {
            if (!confirmDelete) {
                Box(Modifier.clip(RoundedCornerShape(50)).background(C.redSoft).clickable { confirmDelete = true }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                    T("🗑 Xóa", 14, FontWeight.SemiBold, C.red)
                }
            } else {
                Box(Modifier.clip(RoundedCornerShape(50)).background(C.red).clickable { vm.deleteRecurring(r.id); onClose() }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                    T("Xác nhận xóa (giao dịch đã tạo vẫn giữ)", 14, FontWeight.SemiBold, Color.White)
                }
            }
        }
    }
}

// ============================================================ HÓA ĐƠN

@Composable
fun BillsScreen(vm: MimiViewModel, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<Bill?>(null) }
    var adding by remember { mutableStateOf(false) }
    val unpaidTotal = vm.bills.filter { !vm.billPaid(it) }.sumOf { it.amount }
    val sorted = vm.bills.sortedWith(compareBy<Bill>({ vm.billPaid(it) }, { it.dayOfMonth }))

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        SubHeader("Hóa đơn", onBack) { RoundBtn("＋", C.green, Color.White) { adding = true } }
        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), color = C.lilac) {
            Column(Modifier.padding(18.dp)) {
                T("Cần thanh toán tháng này", 14, FontWeight.SemiBold)
                T(fmt(unpaidTotal), 30, FontWeight.Bold, if (unpaidTotal > 0) C.red else C.green)
                T("${vm.bills.count { !vm.billPaid(it) }}/${vm.bills.size} hóa đơn chưa thanh toán", 12, color = C.sub)
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (sorted.isEmpty()) T("Chưa có hóa đơn nào.\nBấm ＋ để thêm tiền điện, nước, internet, tiền nhà...", 14, color = C.sub)
            sorted.forEach { b ->
                val paid = vm.billPaid(b)
                val left = vm.billDaysLeft(b)
                val status = when {
                    paid -> "✓ Đã thanh toán tháng này"
                    left < 0 -> "Quá hạn ${-left} ngày"
                    left == 0 -> "Hạn hôm nay"
                    else -> "Còn $left ngày"
                }
                val statusColor = when {
                    paid -> C.green
                    left <= 0 -> C.red
                    left <= 3 -> Color(0xFFF59E2B)
                    else -> C.sub
                }
                Card20(Modifier.fillMaxWidth().clickable { editing = b }) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBubble(Cats.find(b.category).icon, C.lilac)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                T(b.name, 16, FontWeight.Bold, maxLines = 1)
                                T("Hạn ngày ${b.dayOfMonth} hằng tháng • ${vm.walletName(b.walletId)}", 12, color = C.sub, maxLines = 1)
                            }
                            Spacer(Modifier.width(8.dp))
                            T(fmt(b.amount), 16, FontWeight.Bold)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            T(status, 13, FontWeight.SemiBold, statusColor, modifier = Modifier.weight(1f))
                            if (!paid) {
                                Box(Modifier.clip(RoundedCornerShape(50)).background(C.green).clickable { vm.payBill(b) }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                                    T("Thanh toán", 13, FontWeight.Bold, Color.White)
                                }
                            }
                        }
                    }
                }
            }
            Tip("Bấm “Thanh toán” để ghi một khoản chi vào sổ từ ví đã chọn. Hóa đơn tự trở lại trạng thái chưa thanh toán khi sang tháng mới.", "🧾")
        }
    }

    if (adding) BillDialog(vm, null) { adding = false }
    editing?.let { b -> BillDialog(vm, b) { editing = null } }
}

@Composable
private fun BillDialog(vm: MimiViewModel, b: Bill?, onClose: () -> Unit) {
    var name by remember { mutableStateOf(b?.name ?: "") }
    var amount by remember { mutableStateOf(b?.amount?.toString() ?: "") }
    var day by remember { mutableStateOf(b?.dayOfMonth?.toString() ?: "") }
    var walletId by remember { mutableStateOf(b?.walletId ?: vm.settings.defaultWalletId.ifBlank { vm.wallets.first().id }) }
    var category by remember { mutableStateOf(b?.category ?: "Hóa đơn") }
    var error by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }

    Dialog2(if (b == null) "Thêm hóa đơn" else "Sửa hóa đơn", onClose, "Lưu", onConfirm = {
        val a = parseMoney(amount)
        val d = day.filter { it.isDigit() }.toIntOrNull() ?: 0
        when {
            name.isBlank() -> error = "Hãy nhập tên hóa đơn"
            a <= 0 -> error = "Hãy nhập số tiền"
            d !in 1..31 -> error = "Ngày hạn phải từ 1 đến 31"
            else -> {
                vm.saveBill(Bill(b?.id ?: newId(), name.trim(), a, d, walletId, category, b?.paidMonth ?: ""))
                onClose()
            }
        }
    }) {
        TextInput(name, { name = it }, "Tên hóa đơn (vd: Tiền điện)")
        MoneyField(amount, { amount = it })
        TextInput(day, { day = it.filter { c -> c.isDigit() }.take(2) }, "Hạn thanh toán (ngày trong tháng)")
        Picker("Danh mục", Cats.find(category).icon + " " + category, Cats.expense.map { it.icon + " " + it.name }) { category = Cats.expense[it].name }
        Picker("Trả từ ví", vm.walletName(walletId), vm.wallets.map { it.icon + " " + it.name }) { walletId = vm.wallets[it].id }
        if (error.isNotEmpty()) T(error, 13, color = C.red)
        if (b != null) {
            if (!confirmDelete) {
                Box(Modifier.clip(RoundedCornerShape(50)).background(C.redSoft).clickable { confirmDelete = true }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                    T("🗑 Xóa hóa đơn", 14, FontWeight.SemiBold, C.red)
                }
            } else {
                Box(Modifier.clip(RoundedCornerShape(50)).background(C.red).clickable { vm.deleteBill(b.id); onClose() }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                    T("Xác nhận xóa", 14, FontWeight.SemiBold, Color.White)
                }
            }
        }
    }
}
