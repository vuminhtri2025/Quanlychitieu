package com.mimi.ai.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class AppData(
    val wallets: List<Wallet>,
    val txs: List<Tx>,
    val debts: List<Debt>,
    val budgets: Map<String, Long>,
    val messages: List<ChatMsg>,
    val settings: AppSettings,
    val recurring: List<Recurring> = emptyList(),
    val bills: List<Bill> = emptyList()
)

class Store(private val file: File) {
    private val exec = Executors.newSingleThreadExecutor()

    fun write(json: String) {
        exec.execute {
            try {
                val tmp = File(file.path + ".tmp")
                tmp.writeText(json)
                if (!tmp.renameTo(file)) {
                    file.writeText(json)
                    tmp.delete()
                }
            } catch (e: Exception) {
                // bỏ qua lỗi ghi file
            }
        }
    }

    fun read(): AppData? {
        return try {
            if (!file.exists()) null else Codec.decode(file.readText())
        } catch (e: Exception) {
            null
        }
    }
}

object Codec {
    private fun txJson(t: Tx) = JSONObject()
        .put("id", t.id).put("type", t.type.name).put("amount", t.amount)
        .put("category", t.category).put("walletId", t.walletId).put("toWalletId", t.toWalletId)
        .put("person", t.person).put("note", t.note).put("time", t.time).put("debtId", t.debtId)

    private fun txFrom(o: JSONObject) = Tx(
        id = o.getString("id"),
        type = TxType.valueOf(o.getString("type")),
        amount = o.getLong("amount"),
        category = o.optString("category"),
        walletId = o.optString("walletId"),
        toWalletId = o.optString("toWalletId"),
        person = o.optString("person"),
        note = o.optString("note"),
        time = o.optLong("time"),
        debtId = o.optString("debtId")
    )

    fun encode(
        wallets: List<Wallet>,
        txs: List<Tx>,
        debts: List<Debt>,
        budgets: Map<String, Long>,
        messages: List<ChatMsg>,
        s: AppSettings,
        recurring: List<Recurring> = emptyList(),
        bills: List<Bill> = emptyList()
    ): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("wallets", JSONArray().also { a ->
            wallets.forEach {
                a.put(JSONObject().put("id", it.id).put("name", it.name).put("icon", it.icon).put("initial", it.initial))
            }
        })
        root.put("txs", JSONArray().also { a -> txs.forEach { a.put(txJson(it)) } })
        root.put("debts", JSONArray().also { a ->
            debts.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("person", it.person).put("dir", it.dir.name)
                        .put("principal", it.principal).put("note", it.note).put("createdAt", it.createdAt)
                        .put("dueAt", it.dueAt).put("walletId", it.walletId)
                )
            }
        })
        root.put("recurring", JSONArray().also { a ->
            recurring.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("type", it.type.name).put("amount", it.amount)
                        .put("category", it.category).put("walletId", it.walletId).put("note", it.note)
                        .put("freq", it.freq).put("nextAt", it.nextAt).put("active", it.active)
                )
            }
        })
        root.put("bills", JSONArray().also { a ->
            bills.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("name", it.name).put("amount", it.amount)
                        .put("dayOfMonth", it.dayOfMonth).put("walletId", it.walletId)
                        .put("category", it.category).put("paidMonth", it.paidMonth)
                )
            }
        })
        root.put("budgets", JSONObject().also { o -> budgets.forEach { (k, v) -> o.put(k, v) } })
        root.put("messages", JSONArray().also { a ->
            messages.takeLast(80).forEach {
                val o = JSONObject().put("id", it.id).put("fromUser", it.fromUser).put("text", it.text)
                    .put("status", it.status).put("time", it.time)
                if (it.tx != null) o.put("tx", txJson(it.tx))
                a.put(o)
            }
        })
        root.put(
            "settings",
            JSONObject().put("userName", s.userName).put("useAi", s.useAi).put("geminiKey", s.geminiKey)
                .put("geminiModel", s.geminiModel).put("autoSave", s.autoSave)
                .put("defaultWalletId", s.defaultWalletId)
        )
        return root.toString()
    }

    fun decode(json: String): AppData {
        val root = JSONObject(json)
        val wallets = ArrayList<Wallet>()
        root.optJSONArray("wallets")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                wallets.add(Wallet(o.getString("id"), o.getString("name"), o.optString("icon", "💵"), o.optLong("initial")))
            }
        }
        val txs = ArrayList<Tx>()
        root.optJSONArray("txs")?.let { a -> for (i in 0 until a.length()) txs.add(txFrom(a.getJSONObject(i))) }
        val debts = ArrayList<Debt>()
        root.optJSONArray("debts")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                debts.add(
                    Debt(
                        o.getString("id"), o.optString("person"), DebtDir.valueOf(o.getString("dir")),
                        o.optLong("principal"), o.optString("note"), o.optLong("createdAt"),
                        o.optLong("dueAt"), o.optString("walletId")
                    )
                )
            }
        }
        val budgets = HashMap<String, Long>()
        root.optJSONObject("budgets")?.let { o -> o.keys().forEach { k -> budgets[k] = o.optLong(k) } }
        val msgs = ArrayList<ChatMsg>()
        root.optJSONArray("messages")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                msgs.add(
                    ChatMsg(
                        o.getString("id"), o.optBoolean("fromUser"), o.optString("text"),
                        o.optJSONObject("tx")?.let { txFrom(it) }, o.optInt("status"), o.optLong("time")
                    )
                )
            }
        }
        val so = root.optJSONObject("settings")
        val settings = if (so == null) AppSettings() else AppSettings(
            userName = so.optString("userName", "Bạn"),
            useAi = so.optBoolean("useAi"),
            geminiKey = so.optString("geminiKey"),
            geminiModel = so.optString("geminiModel", "gemini-2.5-flash-lite"),
            autoSave = so.optBoolean("autoSave"),
            defaultWalletId = so.optString("defaultWalletId")
        )
        val recurring = ArrayList<Recurring>()
        root.optJSONArray("recurring")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                recurring.add(
                    Recurring(
                        o.getString("id"), TxType.valueOf(o.getString("type")), o.optLong("amount"),
                        o.optString("category"), o.optString("walletId"), o.optString("note"),
                        o.optInt("freq", 2), o.optLong("nextAt"), o.optBoolean("active", true)
                    )
                )
            }
        }
        val bills = ArrayList<Bill>()
        root.optJSONArray("bills")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                bills.add(
                    Bill(
                        o.getString("id"), o.optString("name"), o.optLong("amount"), o.optInt("dayOfMonth", 1),
                        o.optString("walletId"), o.optString("category", "Hóa đơn"), o.optString("paidMonth")
                    )
                )
            }
        }
        return AppData(wallets, txs, debts, budgets, msgs, settings, recurring, bills)
    }
}
