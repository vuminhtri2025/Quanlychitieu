package com.mimi.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mimi.ai.data.Cats
import com.mimi.ai.data.Tx
import com.mimi.ai.data.TxType
import com.mimi.ai.data.dayOf
import com.mimi.ai.data.daysInMonth
import com.mimi.ai.data.fmt
import com.mimi.ai.data.fmtDateTime
import com.mimi.ai.data.fmtSigned
import com.mimi.ai.data.monthRange
import com.mimi.ai.data.newId
import java.util.Calendar

/** Trang "Giao dịch": tổng quan (ví, thu/chi, biểu đồ) + sổ giao dịch trong cùng một màn hình cuộn. */
@Composable
fun TransactionsScreen(vm: MimiViewModel, onWallets: () -> Unit) {
    val cal = remember { Calendar.getInstance() }
    val cy = cal.get(Calendar.YEAR)
    val cm = cal.get(Calendar.MONTH)
    var year by remember { mutableIntStateOf(cy) }
    var month by remember { mutableIntStateOf(cm) }
    var filter by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Tx?>(null) }
    var adding by remember { mutableStateOf(false) }
    var hide by remember { mutableStateOf(false) }

    val monthList = vm.monthTxs(year, month)
    val income = monthList.filter { it.type == TxType.INCOME }.sumOf { it.amount }
    val expenses = monthList.filter { it.type == TxType.EXPENSE }
    val expense = expenses.sumOf { it.amount }
    val byCat = expenses.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
        .toList().sortedByDescending { it.second }
    val shown = monthList.filter {
        when (filter) {
            1 -> it.type == TxType.INCOME
            2 -> it.type == TxType.EXPENSE
            3 -> it.type == TxType.TRANSFER
            4 -> it.type.isDebt
            else -> true
        }
    }.sortedByDescending { it.time }

    val total = vm.totalAssets()
    val prev = vm.totalAssets(monthRange(cy, cm).first - 1)
    val pct = if (prev != 0L) ((total - prev) * 100 / kotlin.math.abs(prev)).toInt() else 0

    LazyColumn(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenTitle("Giao dịch") { RoundBtn("＋", C.green, Color.White) { adding = true } }
        }

        // Chọn tháng
        item {
            Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), color = C.lilac) {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.padding(horizontal = 14.dp).clickable {
                        month--
                        if (month < 0) { month = 11; year-- }
                    }) { T("◀", 16, color = C.sub, modifier = Modifier.padding(8.dp)) }
                    T("Tháng ${month + 1}/$year", 17, FontWeight.SemiBold, modifier = Modifier.weight(1f), align = TextAlign.Center)
                    Box(Modifier.padding(horizontal = 14.dp).clickable {
                        month++
                        if (month > 11) { month = 0; year++ }
                    }) { T("▶", 16, color = C.sub, modifier = Modifier.padding(8.dp)) }
                }
            }
        }

        // Tổng tài sản + các ví
        item {
            Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clickable { onWallets() }) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T("Tổng tài sản", 15, FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.clickable { hide = !hide }) { T(if (hide) "🙈" else "👁️", 16) }
                    }
                    T(if (hide) "••••••••" else fmt(total), 32, FontWeight.Bold)
                    if (prev != 0L) {
                        T(
                            (if (pct >= 0) "▲ +" else "▼ ") + "$pct% so với tháng trước", 13, FontWeight.Medium,
                            if (pct >= 0) C.green else C.red
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        vm.wallets.forEach { w ->
                            Box(Modifier.clip(RoundedCornerShape(14.dp)).background(C.lilac).padding(horizontal = 12.dp, vertical = 8.dp)) {
                                Column {
                                    T(w.icon + " " + w.name, 12, color = C.sub, maxLines = 1)
                                    T(if (hide) "•••" else fmt(vm.balance(w)), 14, FontWeight.Bold, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Thu / Chi
        item {
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryBox("Thu", "+" + fmt(income), C.green, C.greenSoft, Modifier.weight(1f))
                SummaryBox("Chi", "-" + fmt(expense), C.red, C.redSoft, Modifier.weight(1f))
            }
        }

        // Chi tiêu theo danh mục
        item {
            Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    T("Chi tiêu theo danh mục", 16, FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    if (byCat.isEmpty()) {
                        T("Chưa có khoản chi nào trong tháng này.", 13, color = C.sub)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Donut(byCat.map { it.second.toFloat() to Color(Cats.find(it.first).color) }, 150.dp, fmt(expense), "Chi tiêu")
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                byCat.take(5).forEach { (name, v) ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(10.dp).clip(CircleShape).background(Color(Cats.find(name).color)))
                                        Spacer(Modifier.width(8.dp))
                                        T(name, 13, modifier = Modifier.weight(1f), maxLines = 1)
                                        T("${if (expense > 0) v * 100 / expense else 0}%", 13, FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dòng tiền trong tháng
        item {
            Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T("Dòng tiền trong tháng", 16, FontWeight.Bold, modifier = Modifier.weight(1f))
                        Box(Modifier.size(8.dp).clip(CircleShape).background(C.green))
                        T("  Thu   ", 12, color = C.sub)
                        Box(Modifier.size(8.dp).clip(CircleShape).background(C.red))
                        T("  Chi", 12, color = C.sub)
                    }
                    Spacer(Modifier.height(12.dp))
                    val n = daysInMonth(year, month)
                    val di = LongArray(n)
                    val de = LongArray(n)
                    monthList.forEach { t ->
                        val d = (dayOf(t.time) - 1).coerceIn(0, n - 1)
                        if (t.type == TxType.INCOME) di[d] += t.amount
                        if (t.type == TxType.EXPENSE) de[d] += t.amount
                    }
                    LineChart(di.toList(), de.toList(), listOf("1", "7", "14", "21", n.toString()))
                }
            }
        }

        // Mimi nhận xét
        item {
            Row(
                Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(CardShape).background(C.lilac).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MimiAvatar(48.dp)
                Spacer(Modifier.width(12.dp))
                T(vm.tip(), 13, modifier = Modifier.weight(1f))
            }
        }

        // Sổ giao dịch
        item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                T("Lịch sử giao dịch", 18, FontWeight.Bold)
                PillRow(listOf("Tất cả", "Thu", "Chi", "Chuyển", "Nợ"), filter) { filter = it }
            }
        }
        if (shown.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    T("Chưa có giao dịch nào.\nHãy nhắn cho Mimi ở tab Chat nhé!", 14, color = C.sub, align = TextAlign.Center)
                }
            }
        } else {
            items(shown, key = { it.id }) { tx ->
                Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.white)) {
                    TxRow(vm, tx) { selected = tx }
                }
            }
        }
    }

    selected?.let { tx -> TxDetailDialog(vm, tx, onDismiss = { selected = null }) }
    if (adding) {
        val blank = Tx(newId(), TxType.EXPENSE, 0, "Ăn uống", vm.settings.defaultWalletId, time = System.currentTimeMillis())
        TxEditDialog(vm, blank, "Thêm giao dịch", onDismiss = { adding = false }, onSave = { vm.addTx(it); adding = false })
    }
}

@Composable
fun SummaryBox(label: String, value: String, fg: Color, bg: Color, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(bg).padding(14.dp)) {
        Column {
            T(label, 13, FontWeight.SemiBold, fg)
            T(value, 17, FontWeight.Bold, fg, maxLines = 1)
        }
    }
}

@Composable
fun TxRow(vm: MimiViewModel, tx: Tx, onClick: () -> Unit) {
    val title = when (tx.type) {
        TxType.TRANSFER -> "Chuyển ví"
        TxType.LEND, TxType.BORROW, TxType.REPAY_PAID, TxType.REPAY_RECEIVED -> "${tx.type.label} ${tx.person}"
        else -> tx.category
    }
    val sub = if (tx.type == TxType.TRANSFER) "${vm.walletName(tx.walletId)} → ${vm.walletName(tx.toWalletId)}"
    else fmtDateTime(tx.time) + " • " + (tx.note.ifBlank { vm.walletName(tx.walletId) })
    val color = when {
        tx.type == TxType.TRANSFER -> C.ink
        tx.type.sign > 0 -> C.green
        else -> C.red
    }
    val amountText = if (tx.type == TxType.TRANSFER) fmt(tx.amount) else fmtSigned(tx.type.sign * tx.amount)
    val tint = when {
        tx.type == TxType.TRANSFER -> C.lilac
        tx.type.sign > 0 -> C.greenSoft
        else -> C.redSoft
    }
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(Cats.icon(tx), tint)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            T(title, 15, FontWeight.SemiBold, maxLines = 1)
            T(sub, 12, color = C.sub, maxLines = 1)
        }
        Spacer(Modifier.width(8.dp))
        T(amountText, 15, FontWeight.Bold, color)
    }
}

@Composable
private fun TxDetailDialog(vm: MimiViewModel, tx: Tx, onDismiss: () -> Unit) {
    var edit by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val editable = tx.type == TxType.INCOME || tx.type == TxType.EXPENSE || tx.type == TxType.TRANSFER

    if (edit) {
        TxEditDialog(vm, tx, "Sửa giao dịch", onDismiss = { edit = false; onDismiss() }, onSave = { vm.updateTx(it); edit = false; onDismiss() })
        return
    }
    Dialog2(tx.type.label + " " + fmt(tx.amount), onDismiss, if (editable) "Sửa" else null, if (editable) ({ edit = true }) else null) {
        DetailLine("Thời gian", fmtDateTime(tx.time))
        if (tx.type == TxType.TRANSFER) {
            DetailLine("Từ ví", vm.walletName(tx.walletId))
            DetailLine("Đến ví", vm.walletName(tx.toWalletId))
        } else {
            DetailLine("Ví", vm.walletName(tx.walletId))
            if (tx.type.isDebt) DetailLine("Người", tx.person) else DetailLine("Danh mục", tx.category)
        }
        if (tx.note.isNotBlank()) DetailLine("Nội dung", tx.note)
        if (!editable) T("Giao dịch nợ được quản lý ở Tài khoản → Sổ nợ.", 12, color = C.sub)
        if (!confirmDelete) {
            Box(Modifier.clip(RoundedCornerShape(50)).background(C.redSoft).clickable { confirmDelete = true }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                T("🗑 Xóa giao dịch", 14, FontWeight.SemiBold, C.red)
            }
        } else {
            val extra = if (tx.type == TxType.LEND || tx.type == TxType.BORROW) " Khoản nợ và các lần trả liên quan cũng sẽ bị xóa." else ""
            T("Xóa thật sự?$extra", 13, color = C.red)
            Box(Modifier.clip(RoundedCornerShape(50)).background(C.red).clickable { vm.deleteTx(tx.id); onDismiss() }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                T("Xác nhận xóa", 14, FontWeight.SemiBold, Color.White)
            }
        }
    }
}

@Composable
fun DetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        T(label, 14, color = C.sub, modifier = Modifier.width(90.dp))
        T(value, 14, FontWeight.SemiBold, modifier = Modifier.weight(1f), align = TextAlign.End)
    }
}
