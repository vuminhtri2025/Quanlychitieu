package com.mimi.ai.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mimi.ai.data.fmt
import com.mimi.ai.data.fmtShort

/** Bảng màu "Soft Minimal Premium". */
object C {
    val bg = Color(0xFFF8F5FA)        // Lavender Mist - nền chính
    val lilac = Color(0xFFEDE6F2)     // Soft Lilac - card phụ
    val white = Color(0xFFFFFFFF)     // Pure White - card chính
    val green = Color(0xFF299B69)     // Fresh Green - màu chủ đạo
    val red = Color(0xFFD95761)       // Coral Red - chi tiêu
    val ink = Color(0xFF292530)       // Charcoal - chữ chính
    val sub = Color(0xFF7D7788)
    val greenSoft = Color(0xFFE2F4EB)
    val redSoft = Color(0xFFFBE6E8)
    val line = Color(0xFFE6DFEC)
    val userBubble = Color(0xFFDCD2F2)
}

val CardShape = RoundedCornerShape(20.dp)   // Card radius 20dp
val InputShape = RoundedCornerShape(14.dp)  // Input radius 14dp

@Composable
fun MimiTheme(content: @Composable () -> Unit) {
    val scheme = lightColorScheme(
        primary = C.green, onPrimary = Color.White,
        background = C.bg, onBackground = C.ink,
        surface = C.white, onSurface = C.ink,
        secondaryContainer = C.lilac, error = C.red
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun T(
    text: String,
    size: Int = 14,
    weight: FontWeight = FontWeight.Normal,
    color: Color = C.ink,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text, modifier = modifier, color = color, fontSize = size.sp, fontWeight = weight, textAlign = align,
        maxLines = maxLines, overflow = if (maxLines == Int.MAX_VALUE) TextOverflow.Clip else TextOverflow.Ellipsis
    )
}

@Composable
fun Card20(modifier: Modifier = Modifier, color: Color = C.white, content: @Composable () -> Unit) {
    Box(modifier.clip(CardShape).background(color).border(1.dp, C.line.copy(alpha = 0.6f), CardShape)) { content() }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) C.green else C.lilac)
            .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 13, FontWeight.SemiBold, if (selected) Color.White else C.ink) }
}

@Composable
fun PillRow(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s -> Pill(s, i == selected) { onSelect(i) } }
    }
}

@Composable
fun ScreenTitle(title: String, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        T(title, 26, FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@Composable
fun SubHeader(title: String, onBack: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        RoundBtn("←") { onBack() }
        T(title, 22, FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 12.dp))
        trailing?.invoke()
    }
}

@Composable
fun RoundBtn(label: String, bg: Color = C.lilac, fg: Color = C.ink, size: Dp = 40.dp, onClick: () -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(bg).clickable { onClick() }, contentAlignment = Alignment.Center) {
        T(label, 18, FontWeight.Bold, fg)
    }
}

@Composable
fun IconBubble(icon: String, tint: Color = C.lilac, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(tint), contentAlignment = Alignment.Center) { T(icon, 20) }
}

@Composable
fun ProgressBar(frac: Float, color: Color, height: Dp = 8.dp, track: Color = C.lilac) {
    val f = frac.coerceIn(0f, 1f)
    Box(Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(track)) {
        Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

/** Mimi - robot trợ lý, vẽ bằng Canvas. */
@Composable
fun MimiAvatar(size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(C.lilac), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size * 0.7f)) {
            val w = this.size.width
            val h = this.size.height
            drawRoundRect(Color.White, Offset(w * 0.08f, h * 0.2f), Size(w * 0.84f, h * 0.68f), CornerRadius(w * 0.22f))
            drawRoundRect(C.ink, Offset(w * 0.17f, h * 0.32f), Size(w * 0.66f, h * 0.38f), CornerRadius(w * 0.16f))
            drawCircle(Color(0xFF4FE0A0), w * 0.075f, Offset(w * 0.37f, h * 0.51f))
            drawCircle(Color(0xFF4FE0A0), w * 0.075f, Offset(w * 0.63f, h * 0.51f))
            drawLine(Color.White, Offset(w * 0.5f, h * 0.2f), Offset(w * 0.5f, h * 0.06f), strokeWidth = w * 0.05f)
            drawCircle(C.green, w * 0.06f, Offset(w * 0.5f, h * 0.06f))
        }
    }
}

@Composable
fun Donut(slices: List<Pair<Float, Color>>, size: Dp, centerTop: String, centerBottom: String) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = this.size.minDimension * 0.18f
            val inset = stroke / 2
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            val total = slices.sumOf { it.first.toDouble() }.toFloat()
            if (total <= 0f) {
                drawArc(C.lilac, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
            } else {
                var start = -90f
                for ((v, col) in slices) {
                    val sweep = v / total * 360f
                    drawArc(col, start, (sweep - 1.5f).coerceAtLeast(0.5f), false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Butt))
                    start += sweep
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            T(centerTop, 15, FontWeight.Bold, align = TextAlign.Center)
            T(centerBottom, 11, color = C.sub)
        }
    }
}

/** Biểu đồ đường 2 chuỗi (thu = xanh, chi = đỏ). */
@Composable
fun LineChart(income: List<Long>, expense: List<Long>, xLabels: List<String>) {
    val maxV = maxOf(income.maxOrNull() ?: 0L, expense.maxOrNull() ?: 0L, 1L)
    val top = niceCeil(maxV)
    Row(Modifier.fillMaxWidth().height(160.dp)) {
        Column(Modifier.fillMaxHeight().padding(end = 6.dp), verticalArrangement = Arrangement.SpaceBetween) {
            for (i in 3 downTo 0) T(if (i == 0) "0" else fmtShort(top * i / 3), 10, color = C.sub)
        }
        Canvas(Modifier.weight(1f).fillMaxHeight()) {
            val w = this.size.width
            val h = this.size.height
            for (i in 0..3) {
                val y = h * i / 3f
                drawLine(C.line, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }
            fun plot(data: List<Long>, col: Color) {
                if (data.size < 2) return
                val path = Path()
                val fill = Path()
                data.forEachIndexed { i, v ->
                    val x = w * i / (data.size - 1)
                    val y = h - (v.toFloat() / top) * h
                    if (i == 0) {
                        path.moveTo(x, y); fill.moveTo(x, h); fill.lineTo(x, y)
                    } else {
                        path.lineTo(x, y); fill.lineTo(x, y)
                    }
                }
                fill.lineTo(w, h); fill.close()
                drawPath(fill, Brush.verticalGradient(listOf(col.copy(alpha = 0.18f), Color.Transparent)))
                drawPath(path, col, style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            plot(income, C.green)
            plot(expense, C.red)
        }
    }
    Row(Modifier.fillMaxWidth().padding(start = 34.dp, top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        xLabels.forEach { T(it, 10, color = C.sub) }
    }
}

private fun niceCeil(v: Long): Long {
    var step = 1L
    while (step * 10 <= v) step *= 10
    val m = ((v + step - 1) / step) * step
    return if (m % 3L == 0L) m else (m / 3 + 1) * 3
}

// ---------------------------------------------------------------- hộp thoại & ô nhập

@Composable
fun MoneyField(value: String, onChange: (String) -> Unit, label: String = "Số tiền", allowNegative: Boolean = false) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = { s ->
                onChange(if (allowNegative) s.filterIndexed { i, c -> c.isDigit() || (i == 0 && c == '-') } else s.filter { it.isDigit() })
            },
            label = { Text(label) },
            singleLine = true,
            shape = InputShape,
            keyboardOptions = KeyboardOptions(keyboardType = if (allowNegative) KeyboardType.Text else KeyboardType.Number),
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth()
        )
        val v = if (allowNegative) com.mimi.ai.data.parseSigned(value) else com.mimi.ai.data.parseMoney(value)
        if (v != 0L) T("= ${fmt(v)}", 12, color = C.sub, modifier = Modifier.padding(start = 4.dp, top = 2.dp))
    }
}

@Composable
fun TextInput(value: String, onChange: (String) -> Unit, label: String, singleLine: Boolean = true) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine,
        shape = InputShape, colors = fieldColors(), modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = C.white, unfocusedContainerColor = C.white,
    focusedIndicatorColor = C.green, unfocusedIndicatorColor = C.line,
    focusedLabelColor = C.green, cursorColor = C.green
)

@Composable
fun Picker(label: String, value: String, options: List<String>, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clip(InputShape).border(1.dp, C.line, InputShape).background(C.white)
                .clickable { open = true }.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            T(label, 13, color = C.sub, modifier = Modifier.width(92.dp))
            T(value, 15, FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
            T("▾", 14, color = C.sub)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, s ->
                DropdownMenuItem(text = { Text(s) }, onClick = { open = false; onSelect(i) })
            }
        }
    }
}

@Composable
fun Dialog2(
    title: String,
    onDismiss: () -> Unit,
    confirmText: String? = "Lưu",
    onConfirm: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.bg,
        shape = CardShape,
        title = { T(title, 18, FontWeight.Bold) },
        text = {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) { content() }
        },
        confirmButton = {
            if (confirmText != null && onConfirm != null) {
                TextButton(onClick = onConfirm) { T(confirmText, 15, FontWeight.Bold, C.green) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { T(if (onConfirm == null) "Đóng" else "Hủy", 15, color = C.sub) } }
    )
}

@Composable
fun Tip(text: String, icon: String = "💡") {
    Card20(Modifier.fillMaxWidth(), color = C.lilac) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            T(icon, 28)
            Spacer(Modifier.width(12.dp))
            T(text, 13, color = C.ink, modifier = Modifier.weight(1f))
        }
    }
}
