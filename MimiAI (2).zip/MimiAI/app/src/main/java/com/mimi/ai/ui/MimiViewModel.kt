package com.mimi.ai.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mimi.ai.ai.GeminiClient
import com.mimi.ai.ai.LocalParser
import com.mimi.ai.ai.ParseContext
import com.mimi.ai.ai.ParseResult
import com.mimi.ai.data.AppSettings
import com.mimi.ai.data.Bill
import com.mimi.ai.data.Recurring
import com.mimi.ai.data.ChatMsg
import com.mimi.ai.data.Codec
import com.mimi.ai.data.Debt
import com.mimi.ai.data.DebtDir
import com.mimi.ai.data.Store
import com.mimi.ai.data.Tx
import com.mimi.ai.data.TxType
import com.mimi.ai.data.Wallet
import com.mimi.ai.data.fmt
import com.mimi.ai.data.monthOf
import com.mimi.ai.data.monthRange
import com.mimi.ai.data.newId
import com.mimi.ai.data.yearOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

class MimiViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(File(app.filesDir, "mimi_data.json"))

    val wallets = mutableStateListOf<Wallet>()
    val txs = mutableStateListOf<Tx>()
    val debts = mutableStateListOf<Debt>()
    val budgets = mutableStateMapOf<String, Long>()
    val messages = mutableStateListOf<ChatMsg>()
    val recurring = mutableStateListOf<Recurring>()
    val bills = mutableStateListOf<Bill>()
    var settings by mutableStateOf(AppSettings())
    var thinking by mutableStateOf(false)

    init {
        val d = store.read()
        if (d != null) {
            wallets.addAll(d.wallets)
            txs.addAll(d.txs)
            debts.addAll(d.debts)
            budgets.putAll(d.budgets)
            messages.addAll(d.messages)
            recurring.addAll(d.recurring)
            bills.addAll(d.bills)
            settings = d.settings
        }
        if (wallets.isEmpty()) {
            wallets.add(Wallet(newId(), "Tiền mặt", "💵", 0))
            wallets.add(Wallet(newId(), "Ngân hàng", "🏦", 0))
            wallets.add(Wallet(newId(), "Ví MoMo", "📱", 0))
        }
        if (settings.defaultWalletId.isBlank() || wallets.none { it.id == settings.defaultWalletId }) {
            settings = settings.copy(defaultWalletId = wallets.first().id)
        }
        if (messages.isEmpty()) greet()
        runRecurring()
        save()
    }

    private fun greet() {
        messages.add(
            ChatMsg(
                newId(), false,
                "Xin chào ${settings.userName}! 👋\nHôm nay bạn cần mình hỗ trợ gì nào? Bạn có thể nhắn:\n" +
                    "• “Sáng nay ăn phở 45k”\n• “Cho Nam vay 500k”\n• “Nam trả nợ 200k”\n• “Chuyển 1 triệu từ tiền mặt sang ngân hàng”\n" +
                    "Hoặc bấm 🎤 để nói.",
                time = System.currentTimeMillis()
            )
        )
    }

    fun save() {
        store.write(Codec.encode(wallets.toList(), txs.toList(), debts.toList(), budgets.toMap(), messages.toList(), settings, recurring.toList(), bills.toList()))
    }

    fun exportJson(): String =
        Codec.encode(wallets.toList(), txs.toList(), debts.toList(), budgets.toMap(), messages.toList(), settings.copy(geminiKey = ""), recurring.toList(), bills.toList())

    // ---------------------------------------------------------------- tính toán

    fun txDelta(w: Wallet, upTo: Long = Long.MAX_VALUE): Long {
        var s = 0L
        for (t in txs) {
            if (t.time > upTo) continue
            if (t.type == TxType.TRANSFER) {
                if (t.walletId == w.id) s -= t.amount
                if (t.toWalletId == w.id) s += t.amount
            } else if (t.walletId == w.id) {
                s += t.type.sign * t.amount
            }
        }
        return s
    }

    fun balance(w: Wallet, upTo: Long = Long.MAX_VALUE): Long = w.initial + txDelta(w, upTo)
    fun totalAssets(upTo: Long = Long.MAX_VALUE): Long = wallets.sumOf { balance(it, upTo) }
    fun wallet(id: String): Wallet? = wallets.firstOrNull { it.id == id }
    fun walletName(id: String): String = wallet(id)?.name ?: "(ví đã xóa)"

    fun repaid(d: Debt): Long = txs.filter { it.debtId == d.id && it.type.isRepay }.sumOf { it.amount }
    fun remaining(d: Debt): Long = (d.principal - repaid(d)).coerceAtLeast(0)
    fun openDebts(): List<Debt> = debts.filter { remaining(it) > 0 }
    fun totalIOwe(): Long = debts.filter { it.dir == DebtDir.I_OWE }.sumOf { remaining(it) }
    fun totalOwedToMe(): Long = debts.filter { it.dir == DebtDir.OWE_ME }.sumOf { remaining(it) }

    fun monthTxs(year: Int, month: Int): List<Tx> {
        val r = monthRange(year, month)
        return txs.filter { it.time in r }
    }

    fun monthExpense(year: Int, month: Int): Long =
        monthTxs(year, month).filter { it.type == TxType.EXPENSE }.sumOf { it.amount }

    fun monthIncome(year: Int, month: Int): Long =
        monthTxs(year, month).filter { it.type == TxType.INCOME }.sumOf { it.amount }

    fun totalBudget(): Long = budgets.values.sum()

    fun categorySpent(year: Int, month: Int): Map<String, Long> =
        monthTxs(year, month).filter { it.type == TxType.EXPENSE }.groupBy { it.category }
            .mapValues { e -> e.value.sumOf { it.amount } }

    fun tip(): String {
        val c = Calendar.getInstance()
        val y = c.get(Calendar.YEAR)
        val m = c.get(Calendar.MONTH)
        val spent = monthExpense(y, m)
        val budget = totalBudget()
        if (budget > 0) {
            val pct = (spent * 100 / budget).toInt()
            return when {
                pct > 100 -> "Bạn đã vượt ngân sách tháng này ${fmt(spent - budget)}. Thử cắt giảm các khoản không cần thiết nhé!"
                pct >= 80 -> "Bạn đã dùng $pct% ngân sách. Còn ${fmt(budget - spent)}, hãy cân nhắc trước khi chi nhé."
                else -> "Bạn chi tiêu khá hợp lý! Còn ${fmt(budget - spent)} ngân sách để thoải mái tận hưởng nhé 💜"
            }
        }
        if (spent == 0L) return "Hãy nhắn cho Mimi khoản chi đầu tiên của bạn để bắt đầu theo dõi nhé!"
        val top = categorySpent(y, m).maxByOrNull { it.value }
        return if (top != null) "Tháng này bạn chi nhiều nhất cho “${top.key}” (${top.value * 100 / spent}%). Hãy đặt ngân sách cho mục này ở Tài khoản → Ngân sách nhé."
        else "Hãy đặt ngân sách để Mimi nhắc bạn khi chi tiêu quá tay nhé."
    }

    // ---------------------------------------------------------------- chat

    private fun ctx() = ParseContext(wallets.toList(), openDebts(), settings.defaultWalletId)

    private fun botSay(text: String, tx: Tx? = null, status: Int = 0) {
        messages.add(ChatMsg(newId(), false, text, tx, status, System.currentTimeMillis()))
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        messages.add(ChatMsg(newId(), true, t, time = System.currentTimeMillis()))
        thinking = true
        val c = ctx()
        val s = settings
        viewModelScope.launch {
            var result: ParseResult? = null
            if (s.useAi && s.geminiKey.isNotBlank()) {
                val json = withContext(Dispatchers.IO) {
                    GeminiClient.classify(s.geminiKey, s.geminiModel, t, c.wallets.map { it.name }, c.openDebts.map { it.person })
                }
                if (json != null) result = LocalParser.fromAi(json, t, c)
            }
            if (result == null) result = LocalParser.parse(t, c)
            handle(result)
            thinking = false
            save()
        }
    }

    private fun handle(r: ParseResult) {
        when (r) {
            is ParseResult.Propose -> {
                val tx = r.tx
                if (settings.autoSave && (tx.type == TxType.INCOME || tx.type == TxType.EXPENSE)) {
                    addTx(tx)
                    botSay("Đã ghi tự động ✅", tx, 1)
                } else {
                    botSay("Mình đã nhận diện giao dịch này. Bạn kiểm tra rồi xác nhận nhé:", tx, 0)
                }
            }
            is ParseResult.Reply -> botSay(r.text)
            is ParseResult.SetBudget -> {
                budgets[r.category] = r.amount
                botSay("Đã đặt ngân sách “${r.category}” là ${fmt(r.amount)}/tháng 🎯")
            }
            is ParseResult.Query -> botSay(answer(r.kind))
        }
    }

    private fun answer(kind: String): String {
        val c = Calendar.getInstance()
        val y = c.get(Calendar.YEAR)
        val m = c.get(Calendar.MONTH)
        return when (kind) {
            "balance" -> "💰 Số dư các ví:\n" + wallets.joinToString("\n") { "• ${it.name}: ${fmt(balance(it))}" } +
                "\nTổng tài sản: ${fmt(totalAssets())}"
            "spend" -> "📊 Tháng ${m + 1}/$y: chi ${fmt(monthExpense(y, m))}, thu ${fmt(monthIncome(y, m))}.\n" + tip()
            "debt" -> "💳 Bạn đang nợ ${fmt(totalIOwe())} và được nợ ${fmt(totalOwedToMe())} (${openDebts().size} khoản đang mở)."
            "advice" -> "💡 " + tip()
            "hello" -> "Chào ${settings.userName}! 👋 Bạn muốn ghi khoản chi nào hôm nay?"
            else -> "Mình chưa hiểu rõ ý bạn 😅 Hãy thử: “Ăn trưa 50k”, “Lương 15 triệu”, “Cho Nam vay 500k”, “Trả nợ Hùng 100k”, “Số dư các ví”."
        }
    }

    fun confirm(msgId: String) {
        val i = messages.indexOfFirst { it.id == msgId }
        if (i < 0) return
        val msg = messages[i]
        val tx = msg.tx ?: return
        if (msg.status != 0) return
        val ok = addTx(tx)
        if (ok) {
            messages[i] = msg.copy(status = 1)
            botSay("Đã ghi vào sổ ✅")
        } else {
            botSay("Mình không tìm thấy khoản nợ tương ứng để trả. Bạn kiểm tra lại tên người ở Tài khoản → Sổ nợ nhé.")
        }
        save()
    }

    fun cancel(msgId: String) {
        val i = messages.indexOfFirst { it.id == msgId }
        if (i < 0) return
        messages[i] = messages[i].copy(status = 2)
        save()
    }

    fun updateProposal(msgId: String, tx: Tx) {
        val i = messages.indexOfFirst { it.id == msgId }
        if (i < 0) return
        messages[i] = messages[i].copy(tx = tx)
        save()
    }

    fun clearChat() {
        messages.clear()
        greet()
        save()
    }

    // ---------------------------------------------------------------- giao dịch

    /** Ghi một giao dịch (kèm xử lý khoản nợ). Trả về false nếu không thể ghi. */
    fun addTx(tx: Tx): Boolean {
        when (tx.type) {
            TxType.LEND, TxType.BORROW -> {
                val debt = Debt(
                    id = newId(), person = tx.person.ifBlank { "Chưa rõ" },
                    dir = if (tx.type == TxType.LEND) DebtDir.OWE_ME else DebtDir.I_OWE,
                    principal = tx.amount, note = tx.note, createdAt = tx.time, dueAt = 0L, walletId = tx.walletId
                )
                debts.add(debt)
                txs.add(tx.copy(debtId = debt.id, person = debt.person, category = tx.type.label))
            }
            TxType.REPAY_PAID, TxType.REPAY_RECEIVED -> {
                val wantDir = if (tx.type == TxType.REPAY_PAID) DebtDir.I_OWE else DebtDir.OWE_ME
                val d = debts.firstOrNull { it.id == tx.debtId }
                    ?: openDebts().firstOrNull { it.dir == wantDir && it.person.equals(tx.person, true) }
                    ?: return false
                val rem = remaining(d)
                if (rem <= 0) return false
                txs.add(tx.copy(amount = minOf(tx.amount, rem), debtId = d.id, person = d.person, category = tx.type.label))
            }
            else -> txs.add(tx)
        }
        save()
        return true
    }

    fun updateTx(tx: Tx) {
        val i = txs.indexOfFirst { it.id == tx.id }
        if (i >= 0) {
            txs[i] = tx
            save()
        }
    }

    /** Xóa giao dịch. Nếu là giao dịch tạo khoản nợ thì xóa cả khoản nợ và các lần trả. */
    fun deleteTx(id: String) {
        val t = txs.firstOrNull { it.id == id } ?: return
        if (t.type == TxType.LEND || t.type == TxType.BORROW) {
            txs.removeAll { it.debtId == t.debtId }
            debts.removeAll { it.id == t.debtId }
        } else {
            txs.removeAll { it.id == id }
        }
        save()
    }

    // ---------------------------------------------------------------- nợ

    fun addDebt(dir: DebtDir, person: String, amount: Long, walletId: String, note: String, dueAt: Long) {
        val now = System.currentTimeMillis()
        val d = Debt(newId(), person.trim().ifBlank { "Chưa rõ" }, dir, amount, note, now, dueAt, walletId)
        debts.add(d)
        val type = if (dir == DebtDir.OWE_ME) TxType.LEND else TxType.BORROW
        txs.add(Tx(newId(), type, amount, type.label, walletId, person = d.person, note = note, time = now, debtId = d.id))
        save()
    }

    fun repay(d: Debt, amount: Long, walletId: String) {
        val type = if (d.dir == DebtDir.I_OWE) TxType.REPAY_PAID else TxType.REPAY_RECEIVED
        val amt = minOf(amount, remaining(d))
        if (amt <= 0) return
        txs.add(
            Tx(
                newId(), type, amt, type.label, walletId, person = d.person,
                note = if (type == TxType.REPAY_PAID) "Trả nợ ${d.person}" else "${d.person} trả nợ",
                time = System.currentTimeMillis(), debtId = d.id
            )
        )
        save()
    }

    fun deleteDebt(id: String) {
        txs.removeAll { it.debtId == id }
        debts.removeAll { it.id == id }
        save()
    }

    // ---------------------------------------------------------------- ví, ngân sách, cài đặt

    fun addWallet(name: String, icon: String, balance: Long) {
        wallets.add(Wallet(newId(), name.trim().ifBlank { "Ví mới" }, icon, balance))
        save()
    }

    /** desiredBalance là số dư hiện tại người dùng muốn; initial được tính ngược lại. */
    fun editWallet(w: Wallet, name: String, icon: String, desiredBalance: Long) {
        val i = wallets.indexOfFirst { it.id == w.id }
        if (i < 0) return
        wallets[i] = w.copy(name = name.trim().ifBlank { w.name }, icon = icon, initial = desiredBalance - txDelta(w))
        save()
    }

    fun canDeleteWallet(w: Wallet): Boolean =
        wallets.size > 1 && txs.none { it.walletId == w.id || it.toWalletId == w.id } &&
            recurring.none { it.walletId == w.id } && bills.none { it.walletId == w.id }

    fun deleteWallet(w: Wallet) {
        if (!canDeleteWallet(w)) return
        wallets.removeAll { it.id == w.id }
        if (settings.defaultWalletId == w.id) settings = settings.copy(defaultWalletId = wallets.first().id)
        save()
    }

    fun setBudget(category: String, amount: Long) {
        if (amount <= 0) budgets.remove(category) else budgets[category] = amount
        save()
    }

    fun updateSettings(s: AppSettings) {
        settings = s
        save()
    }

    fun clearAll() {
        txs.clear()
        debts.clear()
        budgets.clear()
        recurring.clear()
        bills.clear()
        messages.clear()
        for (i in wallets.indices) wallets[i] = wallets[i].copy(initial = 0)
        greet()
        save()
    }

    // ---------------------------------------------------------------- giao dịch định kì

    private fun advance(t: Long, freq: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        when (freq) {
            0 -> c.add(Calendar.DAY_OF_YEAR, 1)
            1 -> c.add(Calendar.WEEK_OF_YEAR, 1)
            else -> c.add(Calendar.MONTH, 1)
        }
        return c.timeInMillis
    }

    /** Tạo các giao dịch định kì đã đến hạn (gọi khi mở app). */
    fun runRecurring() {
        val now = System.currentTimeMillis()
        var changed = false
        for (i in recurring.indices) {
            var r = recurring[i]
            if (!r.active || r.nextAt > now) continue
            var guard = 0
            while (r.nextAt <= now && guard < 400) {
                txs.add(
                    Tx(
                        newId(), r.type, r.amount, r.category, r.walletId,
                        note = r.note.ifBlank { "Giao dịch định kì" }, time = r.nextAt
                    )
                )
                r = r.copy(nextAt = advance(r.nextAt, r.freq))
                guard++
            }
            recurring[i] = r
            changed = true
        }
        if (changed) save()
    }

    fun saveRecurring(r: Recurring) {
        val i = recurring.indexOfFirst { it.id == r.id }
        if (i >= 0) recurring[i] = r else recurring.add(r)
        runRecurring()
        save()
    }

    fun deleteRecurring(id: String) {
        recurring.removeAll { it.id == id }
        save()
    }

    // ---------------------------------------------------------------- hóa đơn

    fun monthKey(t: Long = System.currentTimeMillis()): String =
        "%04d-%02d".format(yearOf(t), monthOf(t) + 1)

    fun billPaid(b: Bill): Boolean = b.paidMonth == monthKey()

    /** Số ngày còn lại đến hạn trong tháng này (âm = quá hạn). */
    fun billDaysLeft(b: Bill): Int {
        val now = Calendar.getInstance()
        val y = now.get(Calendar.YEAR)
        val m = now.get(Calendar.MONTH)
        val day = b.dayOfMonth.coerceIn(1, com.mimi.ai.data.daysInMonth(y, m))
        return day - now.get(Calendar.DAY_OF_MONTH)
    }

    fun saveBill(b: Bill) {
        val i = bills.indexOfFirst { it.id == b.id }
        if (i >= 0) bills[i] = b else bills.add(b)
        save()
    }

    fun deleteBill(id: String) {
        bills.removeAll { it.id == id }
        save()
    }

    fun payBill(b: Bill) {
        val now = System.currentTimeMillis()
        txs.add(Tx(newId(), TxType.EXPENSE, b.amount, b.category, b.walletId, note = "Hóa đơn: ${b.name}", time = now))
        val i = bills.indexOfFirst { it.id == b.id }
        if (i >= 0) bills[i] = bills[i].copy(paidMonth = monthKey(now))
        save()
    }

    fun currentYear(): Int = yearOf(System.currentTimeMillis())
    fun currentMonth(): Int = monthOf(System.currentTimeMillis())
}
