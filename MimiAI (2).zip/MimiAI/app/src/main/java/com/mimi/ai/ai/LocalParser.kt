package com.mimi.ai.ai

import com.mimi.ai.data.Cats
import com.mimi.ai.data.Debt
import com.mimi.ai.data.DebtDir
import com.mimi.ai.data.Tx
import com.mimi.ai.data.TxType
import com.mimi.ai.data.Wallet
import com.mimi.ai.data.newId
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.roundToLong

sealed class ParseResult {
    data class Propose(val tx: Tx) : ParseResult()
    data class Reply(val text: String) : ParseResult()
    data class SetBudget(val category: String, val amount: Long) : ParseResult()
    data class Query(val kind: String) : ParseResult()
}

/** Dữ liệu ngữ cảnh để parser nhận diện ví và khoản nợ đang mở. */
class ParseContext(
    val wallets: List<Wallet>,
    val openDebts: List<Debt>,
    val defaultWalletId: String
)

object LocalParser {

    // ------------------------------------------------------------ số tiền

    private val unitMul = mapOf(
        "k" to 1000.0, "nghìn" to 1000.0, "ngàn" to 1000.0,
        "tr" to 1_000_000.0, "triệu" to 1_000_000.0, "củ" to 1_000_000.0,
        "tỷ" to 1_000_000_000.0, "tỉ" to 1_000_000_000.0,
        "đ" to 1.0, "đồng" to 1.0, "vnd" to 1.0, "vnđ" to 1.0
    )
    private val amountRe = Regex(
        "(\\d+(?:[.,]\\d+)*)\\s*(?:(tỷ|tỉ|triệu|nghìn|ngàn|vnđ|vnd|đồng|củ|tr|k|đ)(?![\\p{L}]))?(\\d+)?(?:\\s*(rưỡi))?",
        RegexOption.IGNORE_CASE
    )
    private val skipAfter = listOf("giờ", "phút", "ngày", "tháng", "người", "cái", "ly", "phần", "bữa", "lần", "%", "h ", "km")

    private class Tok(val value: Long, val hasUnit: Boolean, val mul: Double, val start: Int, val end: Int)

    private fun parseNum(s: String): Double? {
        return try {
            if (Regex("^\\d{1,3}([.,]\\d{3})+$").matches(s)) s.replace(".", "").replace(",", "").toDouble()
            else s.replace(",", ".").toDouble()
        } catch (e: Exception) {
            null
        }
    }

    fun extractAmount(text: String): Long? {
        val toks = ArrayList<Tok>()
        for (m in amountRe.findAll(text)) {
            val unit = m.groupValues[2].lowercase()
            val tail = m.groupValues[3]
            val half = m.groupValues[4].isNotEmpty()
            val endIdx = m.range.last + 1
            val after = text.substring(endIdx).trimStart().lowercase()
            val nextCh = if (endIdx < text.length) text[endIdx] else ' '
            val prevCh = if (m.range.first > 0) text[m.range.first - 1] else ' '
            if (nextCh == '/' || prevCh == '/' || nextCh == ':' || prevCh == ':') continue
            if (unit.isEmpty() && skipAfter.any { after.startsWith(it) }) continue
            val num = parseNum(m.groupValues[1]) ?: continue
            val mul = unitMul[unit] ?: 0.0
            var value: Double
            if (unit.isEmpty()) {
                value = if (num < 1000) num * 1000 else num
            } else {
                value = num * mul
                if (mul >= 1000) {
                    if (tail.isNotEmpty()) value += ("0.$tail").toDouble() * mul
                    if (half) value += mul / 2
                }
            }
            if (value <= 0) continue
            toks.add(Tok(value.roundToLong(), mul >= 1000, mul, m.range.first, endIdx))
        }
        if (toks.isEmpty()) return null
        val results = ArrayList<Pair<Long, Boolean>>()
        var i = 0
        while (i < toks.size) {
            var total = toks[i].value
            var j = i
            while (j + 1 < toks.size && toks[j].hasUnit && toks[j + 1].hasUnit &&
                toks[j + 1].mul < toks[j].mul && text.substring(toks[j].end, toks[j + 1].start).isBlank()
            ) {
                total += toks[j + 1].value
                j++
            }
            results.add(total to toks[i].hasUnit)
            i = j + 1
        }
        return (results.firstOrNull { it.second } ?: results.firstOrNull())?.first
    }

    // ------------------------------------------------------------ tiện ích văn bản

    private fun has(t: String, kw: String): Boolean =
        Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(kw) + "(?![\\p{L}\\p{N}])").containsMatchIn(t)

    private fun hasAny(t: String, kws: List<String>) = kws.any { has(t, it) }

    private val firstPerson = setOf("tôi", "mình", "tui", "tao")
    private val unitWords = setOf("k", "tr", "triệu", "nghìn", "ngàn", "đ", "đồng", "củ", "tỷ")
    private val nameStop = setOf(
        "tôi", "mình", "tui", "tao", "vay", "mượn", "tiền", "nợ", "trả", "cho", "của", "là", "hết", "khoản",
        "số", "bằng", "ví", "từ", "vào", "sang", "hôm", "qua", "nay", "ngày", "lúc", "để", "rồi", "nhé", "với", "hoàn"
    )

    private fun words(t: String): List<String> =
        t.trim().split(Regex("\\s+")).map { it.trim(',', '.', ';', '!', '?', '"', '“', '”') }.filter { it.isNotEmpty() }

    private fun cap(s: String) = s.split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }

    private fun nameFrom(ws: List<String>): String {
        val out = ArrayList<String>()
        for (w in ws) {
            if (w[0].isDigit() || w in nameStop || w in unitWords) break
            out.add(w)
            if (out.size >= 3) break
        }
        return cap(out.joinToString(" "))
    }

    private fun nameBefore(ws: List<String>, idx: Int): String {
        val out = ArrayList<String>()
        var i = idx - 1
        while (i >= 0 && out.size < 3) {
            val w = ws[i]
            if (w[0].isDigit() || w in nameStop || w in unitWords) break
            out.add(0, w)
            i--
        }
        return cap(out.joinToString(" "))
    }

    // ------------------------------------------------------------ ví

    private fun aliases(w: Wallet): List<String> {
        val n = w.name.lowercase()
        val a = arrayListOf(n)
        if (n.contains("ngân hàng")) a.addAll(listOf("ngân hàng", "bank", "atm", "thẻ", "chuyển khoản", "vietcombank", "techcombank", "bidv", "tpbank", "vcb"))
        if (n.contains("tiền mặt")) a.addAll(listOf("tiền mặt", "cash"))
        if (n.contains("momo")) a.add("momo")
        return a.distinct()
    }

    private fun walletMentions(t: String, wallets: List<Wallet>): List<Pair<Wallet, Int>> {
        val res = ArrayList<Pair<Wallet, Int>>()
        for (w in wallets) {
            var best = -1
            for (al in aliases(w)) {
                val m = Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(al) + "(?![\\p{L}\\p{N}])").find(t)
                if (m != null && (best == -1 || m.range.first < best)) best = m.range.first
            }
            if (best >= 0) res.add(w to best)
        }
        return res.sortedBy { it.second }
    }

    fun findWallet(name: String, wallets: List<Wallet>): Wallet? {
        val n = name.trim().lowercase()
        if (n.isEmpty()) return null
        return wallets.firstOrNull { it.name.lowercase() == n }
            ?: wallets.firstOrNull { it.name.lowercase().contains(n) || n.contains(it.name.lowercase()) }
            ?: walletMentions(n, wallets).firstOrNull()?.first
    }

    // ------------------------------------------------------------ danh mục

    private val expenseKeywords: List<Pair<String, List<String>>> = listOf(
        "Hóa đơn" to listOf("điện", "nước máy", "internet", "wifi", "điện thoại", "hóa đơn", "cước", "tiền điện", "tiền nước", "truyền hình"),
        "Sức khỏe" to listOf("thuốc", "khám", "bệnh viện", "bác sĩ", "nha khoa", "gym", "sức khỏe", "vitamin", "xét nghiệm", "răng"),
        "Giáo dục" to listOf("học phí", "khóa học", "sách", "học", "lớp", "giáo dục", "văn phòng phẩm"),
        "Đi lại" to listOf("xăng", "grab", "taxi", "xe buýt", "buýt", "gửi xe", "vé xe", "đi lại", "tàu", "máy bay", "đổ xăng", "xe", "be", "gojek", "vé tàu", "phí cầu đường"),
        "Giải trí" to listOf("phim", "game", "du lịch", "karaoke", "netflix", "giải trí", "nhạc", "spotify", "xem", "chơi", "vé"),
        "Quà tặng" to listOf("quà", "tặng", "mừng", "cưới", "từ thiện", "biếu", "lì xì", "phong bì"),
        "Ăn uống" to listOf("ăn", "phở", "cơm", "bún", "bánh", "cafe", "cà phê", "café", "trà sữa", "uống", "nhậu", "bia", "quán", "lẩu", "nướng", "đồ ăn", "thức ăn", "trà", "sinh tố", "kem", "xôi", "mì", "cháo", "ăn sáng", "ăn trưa", "ăn tối"),
        "Sinh hoạt" to listOf("tiền nhà", "thuê nhà", "thuê", "siêu thị", "chợ", "gas", "giặt", "sinh hoạt", "đồ dùng", "tạp hóa", "rác"),
        "Mua sắm" to listOf("mua", "quần", "áo", "giày", "túi", "shopee", "lazada", "tiki", "mỹ phẩm", "sắm", "đồ")
    )

    private fun expenseCategory(t: String): String {
        for ((cat, kws) in expenseKeywords) if (hasAny(t, kws)) return cat
        return "Khác"
    }

    private fun incomeCategory(t: String): String = when {
        has(t, "lương") -> "Lương"
        hasAny(t, listOf("thưởng", "bonus")) -> "Thưởng"
        hasAny(t, listOf("lãi", "cổ tức", "tiền lãi")) -> "Lãi"
        else -> "Thu nhập khác"
    }

    private val incomeWords = listOf("lương", "nhận", "thưởng", "bán", "lãi", "thu", "cashback", "hoàn", "bonus", "cổ tức")
    private val incomePhrases = listOf("được cho", "được tặng", "được thưởng", "chuyển khoản cho tôi", "chuyển cho tôi", "chuyển cho mình", "vợ chuyển", "chồng chuyển", "mẹ chuyển", "bố chuyển")
    private val strongExpense = listOf("chi", "mua", "tiêu", "ăn", "uống", "trả", "đóng", "nạp", "đổ")

    // ------------------------------------------------------------ thời gian

    private fun timeFrom(t: String): Long {
        val c = Calendar.getInstance()
        when {
            has(t, "hôm kia") -> c.add(Calendar.DAY_OF_YEAR, -2)
            has(t, "hôm qua") -> c.add(Calendar.DAY_OF_YEAR, -1)
            else -> {
                val m = Regex("(\\d{1,2})/(\\d{1,2})").find(t)
                if (m != null) {
                    val d = m.groupValues[1].toInt()
                    val mo = m.groupValues[2].toInt() - 1
                    if (d in 1..31 && mo in 0..11) {
                        val now = Calendar.getInstance()
                        c.set(now.get(Calendar.YEAR), mo, d)
                        if (c.timeInMillis > now.timeInMillis + 86_400_000L) c.add(Calendar.YEAR, -1)
                    }
                }
            }
        }
        return c.timeInMillis
    }

    // ------------------------------------------------------------ parse chính

    private fun mkTx(
        type: TxType, amount: Long, cat: String, wallet: String, to: String = "",
        person: String = "", note: String, time: Long, debtId: String = ""
    ) = Tx(newId(), type, amount, cat, wallet, to, person, note, time, debtId)

    fun parse(text: String, ctx: ParseContext): ParseResult {
        val raw = text.trim()
        val t = raw.lowercase().replace(Regex("[;!?]+"), " ")
        val amount = extractAmount(t)
        val note = raw.replaceFirstChar { it.uppercase() }
        val time = timeFrom(t)
        val defWallet = ctx.wallets.firstOrNull { it.id == ctx.defaultWalletId } ?: ctx.wallets.firstOrNull()
        val mentions = walletMentions(t, ctx.wallets)
        val wallet = mentions.firstOrNull()?.first ?: defWallet
        val walletId = wallet?.id ?: ""

        if (amount == null) return noAmount(t)

        // đặt ngân sách
        if (has(t, "ngân sách") || has(t, "hạn mức")) {
            val cat = expenseCategory(t).let { if (it == "Khác" && !has(t, "khác")) "Khác" else it }
            return ParseResult.SetBudget(cat, amount)
        }

        val ws = words(t)

        // chuyển ví
        if (has(t, "chuyển") || has(t, "rút") || has(t, "nạp")) {
            if (mentions.size >= 2) {
                val tu = t.indexOf("từ ")
                var from = mentions[0].first
                var to = mentions[1].first
                if (tu >= 0) {
                    val afterTu = mentions.firstOrNull { it.second > tu }
                    if (afterTu != null) {
                        from = afterTu.first
                        to = mentions.first { it.first.id != from.id }.first
                    }
                }
                return ParseResult.Propose(mkTx(TxType.TRANSFER, amount, "Chuyển ví", from.id, to.id, note = note, time = time))
            }
        }

        // trả nợ / thu nợ
        val repay = repayIntent(t, ws, ctx, amount, note, time, walletId)
        if (repay != null) return repay

        // vay / cho vay
        val iv = ws.indexOfFirst { it == "vay" || it == "mượn" }
        if (iv >= 0) {
            val ic = ws.subList(0, iv).lastIndexOf("cho")
            val type: TxType
            var person: String
            if (ic >= 0 && iv == ic + 1) {
                type = TxType.LEND
                person = nameFrom(ws.drop(iv + 1))
            } else if (ic >= 0) {
                val between = ws.subList(ic + 1, iv)
                if (between.isNotEmpty() && between[0] in firstPerson) {
                    type = TxType.BORROW
                    person = nameBefore(ws, ic)
                } else {
                    type = TxType.LEND
                    person = nameFrom(between)
                }
            } else {
                val next = ws.getOrNull(iv + 1)
                if (next != null && next in firstPerson) {
                    type = TxType.LEND
                    person = nameBefore(ws, iv)
                } else {
                    type = TxType.BORROW
                    person = nameFrom(ws.drop(iv + 1).dropWhile { it == "của" || it == "tiền" })
                }
            }
            if (person.isBlank()) person = "Chưa rõ"
            return ParseResult.Propose(mkTx(type, amount, type.label, walletId, person = person, note = note, time = time))
        }
        if (has(t, "cho vay") || has(t, "cho mượn")) {
            val ic = ws.indexOf("cho")
            val person = nameFrom(ws.drop(ic + 2)).ifBlank { "Chưa rõ" }
            return ParseResult.Propose(mkTx(TxType.LEND, amount, TxType.LEND.label, walletId, person = person, note = note, time = time))
        }

        // thu / chi
        val income = (hasAny(t, incomeWords) || incomePhrases.any { t.contains(it) }) && !hasAny(t, strongExpense)
        return if (income) {
            ParseResult.Propose(mkTx(TxType.INCOME, amount, incomeCategory(t), walletId, note = note, time = time))
        } else {
            ParseResult.Propose(mkTx(TxType.EXPENSE, amount, expenseCategory(t), walletId, note = note, time = time))
        }
    }

    private fun repayIntent(
        t: String, ws: List<String>, ctx: ParseContext, amount: Long,
        note: String, time: Long, walletId: String
    ): ParseResult? {
        val trigger = has(t, "trả") || has(t, "hoàn trả") || has(t, "thu nợ") || has(t, "đòi") || has(t, "tất toán")
        if (!trigger) return null
        // 1) có tên người đang nợ/được nợ trong câu
        val matched = ctx.openDebts.filter { has(t, it.person.lowercase()) }
        if (matched.isNotEmpty() && (has(t, "nợ") || has(t, "trả") || has(t, "thu nợ") || has(t, "đòi") || has(t, "hoàn"))) {
            val iTra = ws.indexOf("trả")
            val subjectIsMe = iTra > 0 && ws[iTra - 1] in firstPerson
            val d = matched.firstOrNull { x ->
                when {
                    subjectIsMe -> x.dir == DebtDir.I_OWE
                    iTra == 0 -> x.dir == DebtDir.I_OWE
                    else -> true
                }
            } ?: matched.first()
            val type = if (d.dir == DebtDir.I_OWE) TxType.REPAY_PAID else TxType.REPAY_RECEIVED
            return ParseResult.Propose(mkTx(type, amount, type.label, walletId, person = d.person, note = note, time = time, debtId = d.id))
        }
        if (!has(t, "nợ") && !has(t, "thu nợ")) return null
        // 2) không có khoản nợ khớp: dùng ngữ pháp để lấy tên, rồi báo lại
        val iTra = ws.indexOfFirst { it == "trả" || it == "đòi" }
        var person = ""
        if (iTra >= 0) {
            person = if (iTra == 0 || ws[iTra - 1] in firstPerson) {
                nameFrom(ws.drop(iTra + 1).dropWhile { it == "nợ" || it == "tiền" })
            } else nameBefore(ws, iTra)
        }
        return if (person.isBlank()) ParseResult.Reply("Bạn trả nợ cho ai vậy? Hãy nói rõ tên người, ví dụ: “Trả nợ Hùng 100k”.")
        else ParseResult.Reply("Mình chưa thấy khoản nợ nào với $person. Bạn kiểm tra lại ở Tài khoản → Sổ nợ hoặc ghi khoản vay trước nhé.")
    }

    private fun noAmount(t: String): ParseResult = when {
        hasAny(t, listOf("số dư", "tài sản", "còn bao nhiêu", "các ví", "ví của tôi")) -> ParseResult.Query("balance")
        hasAny(t, listOf("chi tiêu", "tiêu bao nhiêu", "báo cáo", "thống kê", "đã chi")) -> ParseResult.Query("spend")
        has(t, "nợ") || has(t, "vay") || has(t, "mượn") -> ParseResult.Query("debt")
        hasAny(t, listOf("tiết kiệm", "tư vấn", "gợi ý", "mẹo")) -> ParseResult.Query("advice")
        hasAny(t, listOf("chào", "hello", "hi", "xin chào", "alo")) -> ParseResult.Query("hello")
        else -> ParseResult.Query("help")
    }

    // ------------------------------------------------------------ ánh xạ kết quả từ Gemini

    fun fromAi(o: JSONObject, text: String, ctx: ParseContext): ParseResult? {
        val intent = o.optString("intent").lowercase()
        val reply = o.optString("reply")
        val amount = o.optLong("amount", 0L)
        val note = o.optString("note").ifBlank { text.trim().replaceFirstChar { it.uppercase() } }
        val defWallet = ctx.wallets.firstOrNull { it.id == ctx.defaultWalletId } ?: ctx.wallets.firstOrNull()
        val wallet = findWallet(o.optString("wallet"), ctx.wallets) ?: defWallet ?: return null
        val person = o.optString("person").trim().let { cap(it) }
        val time = timeFrom(text.lowercase())
        fun cat(isIncome: Boolean): String {
            val c = o.optString("category")
            val list = if (isIncome) Cats.income else Cats.expense
            return list.firstOrNull { it.name.equals(c, true) }?.name ?: (if (isIncome) "Thu nhập khác" else "Khác")
        }
        return when (intent) {
            "expense" -> if (amount > 0) ParseResult.Propose(mkTx(TxType.EXPENSE, amount, cat(false), wallet.id, note = note, time = time)) else null
            "income" -> if (amount > 0) ParseResult.Propose(mkTx(TxType.INCOME, amount, cat(true), wallet.id, note = note, time = time)) else null
            "transfer" -> {
                val to = findWallet(o.optString("to_wallet"), ctx.wallets)
                if (amount > 0 && to != null && to.id != wallet.id)
                    ParseResult.Propose(mkTx(TxType.TRANSFER, amount, "Chuyển ví", wallet.id, to.id, note = note, time = time))
                else null
            }
            "lend", "borrow" -> {
                if (amount <= 0) return null
                val type = if (intent == "lend") TxType.LEND else TxType.BORROW
                ParseResult.Propose(mkTx(type, amount, type.label, wallet.id, person = person.ifBlank { "Chưa rõ" }, note = note, time = time))
            }
            "repay_paid", "repay_received" -> {
                if (amount <= 0) return null
                val wantDir = if (intent == "repay_paid") DebtDir.I_OWE else DebtDir.OWE_ME
                val d = ctx.openDebts.firstOrNull { it.dir == wantDir && it.person.equals(person, true) }
                    ?: ctx.openDebts.firstOrNull { it.dir == wantDir && has(person.lowercase(), it.person.lowercase()) }
                if (d == null) ParseResult.Reply(reply.ifBlank { "Mình chưa thấy khoản nợ nào với ${person.ifBlank { "người này" }}." })
                else {
                    val type = if (wantDir == DebtDir.I_OWE) TxType.REPAY_PAID else TxType.REPAY_RECEIVED
                    ParseResult.Propose(mkTx(type, amount, type.label, wallet.id, person = d.person, note = note, time = time, debtId = d.id))
                }
            }
            "query" -> ParseResult.Query(o.optString("query", "help"))
            "chat" -> ParseResult.Reply(reply.ifBlank { "Mình có thể giúp bạn ghi chi tiêu, quản lý ví và nợ nhé!" })
            else -> null
        }
    }
}
