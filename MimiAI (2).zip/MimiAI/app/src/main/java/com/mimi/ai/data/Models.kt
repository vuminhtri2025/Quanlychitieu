package com.mimi.ai.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

enum class TxType(val label: String) {
    INCOME("Thu"),
    EXPENSE("Chi"),
    TRANSFER("Chuyển"),
    LEND("Cho vay"),
    BORROW("Đi vay"),
    REPAY_PAID("Trả nợ"),
    REPAY_RECEIVED("Thu nợ");

    val isDebt: Boolean get() = this == LEND || this == BORROW || this == REPAY_PAID || this == REPAY_RECEIVED
    val isRepay: Boolean get() = this == REPAY_PAID || this == REPAY_RECEIVED

    /** +1: tiền vào ví, -1: tiền ra khỏi ví, 0: chuyển ví (xử lý riêng) */
    val sign: Int
        get() = when (this) {
            INCOME, BORROW, REPAY_RECEIVED -> 1
            EXPENSE, LEND, REPAY_PAID -> -1
            TRANSFER -> 0
        }
}

/** OWE_ME: người khác nợ tôi (tôi cho vay). I_OWE: tôi nợ người khác (tôi đi vay). */
enum class DebtDir { OWE_ME, I_OWE }

data class Wallet(val id: String, val name: String, val icon: String, val initial: Long)

data class Tx(
    val id: String,
    val type: TxType,
    val amount: Long,
    val category: String,
    val walletId: String,
    val toWalletId: String = "",
    val person: String = "",
    val note: String = "",
    val time: Long,
    val debtId: String = ""
)

data class Debt(
    val id: String,
    val person: String,
    val dir: DebtDir,
    val principal: Long,
    val note: String,
    val createdAt: Long,
    val dueAt: Long = 0L,
    val walletId: String
)

/** status: 0 = chờ xác nhận, 1 = đã ghi, 2 = đã hủy */
data class ChatMsg(
    val id: String,
    val fromUser: Boolean,
    val text: String,
    val tx: Tx? = null,
    val status: Int = 0,
    val time: Long
)

data class AppSettings(
    val userName: String = "Bạn",
    val useAi: Boolean = false,
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.5-flash-lite",
    val autoSave: Boolean = false,
    val defaultWalletId: String = ""
)

/** freq: 0 = hằng ngày, 1 = hằng tuần, 2 = hằng tháng. nextAt = thời điểm phát sinh kế tiếp. */
data class Recurring(
    val id: String,
    val type: TxType,
    val amount: Long,
    val category: String,
    val walletId: String,
    val note: String,
    val freq: Int,
    val nextAt: Long,
    val active: Boolean = true
)

/** Hóa đơn hằng tháng. paidMonth dạng "2026-11" = tháng đã thanh toán gần nhất. */
data class Bill(
    val id: String,
    val name: String,
    val amount: Long,
    val dayOfMonth: Int,
    val walletId: String,
    val category: String,
    val paidMonth: String = ""
)

data class Category(val name: String, val icon: String, val color: Long)

object Cats {
    val expense = listOf(
        Category("Ăn uống", "🍴", 0xFFF59E2B),
        Category("Đi lại", "🚗", 0xFF7B61D9),
        Category("Sinh hoạt", "🏠", 0xFF3B8EF0),
        Category("Hóa đơn", "🧾", 0xFF26A69A),
        Category("Mua sắm", "🛍️", 0xFFE5719B),
        Category("Giải trí", "🎮", 0xFF8E6CEF),
        Category("Sức khỏe", "💊", 0xFFEF5350),
        Category("Giáo dục", "📚", 0xFF5C6BC0),
        Category("Quà tặng", "🎁", 0xFFEC407A),
        Category("Khác", "⭐", 0xFF9E9AA7)
    )
    val income = listOf(
        Category("Lương", "💼", 0xFF299B69),
        Category("Thưởng", "🏆", 0xFF43A047),
        Category("Lãi", "📈", 0xFF00897B),
        Category("Thu nhập khác", "💰", 0xFF66BB6A)
    )
    val all = expense + income

    fun find(name: String): Category =
        all.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: expense.last()

    fun icon(tx: Tx): String = when (tx.type) {
        TxType.TRANSFER -> "🔄"
        TxType.LEND -> "💸"
        TxType.BORROW -> "🤝"
        TxType.REPAY_PAID -> "📤"
        TxType.REPAY_RECEIVED -> "📥"
        else -> find(tx.category).icon
    }
}

// ---------------------------------------------------------------- helpers

fun newId(): String = UUID.randomUUID().toString().take(12)

fun fmt(v: Long): String {
    val s = abs(v).toString()
    val sb = StringBuilder()
    for ((i, c) in s.reversed().withIndex()) {
        if (i > 0 && i % 3 == 0) sb.append('.')
        sb.append(c)
    }
    return (if (v < 0) "-" else "") + sb.reverse().toString() + "đ"
}

fun fmtSigned(v: Long): String = (if (v > 0) "+" else "") + fmt(v)

/** Nhãn ngắn cho trục biểu đồ: 1tr, 500k... */
fun fmtShort(v: Long): String = when {
    v >= 1_000_000_000L -> "${v / 1_000_000_000L}tỷ"
    v >= 1_000_000L -> {
        val x = v / 100_000L
        if (x % 10 == 0L) "${x / 10}tr" else "${x / 10}.${x % 10}tr"
    }
    v >= 1_000L -> "${v / 1000}k"
    else -> "$v"
}

/** Chỉ giữ chữ số. */
fun parseMoney(s: String): Long = s.filter { it.isDigit() }.take(13).toLongOrNull() ?: 0L

/** Cho phép dấu trừ ở đầu. */
fun parseSigned(s: String): Long {
    val neg = s.trim().startsWith("-")
    val v = parseMoney(s)
    return if (neg) -v else v
}

private val viLocale = Locale("vi", "VN")

fun fmtDateTime(t: Long): String = SimpleDateFormat("dd/MM HH:mm", viLocale).format(Date(t))
fun fmtDate(t: Long): String = SimpleDateFormat("dd/MM/yyyy", viLocale).format(Date(t))

fun parseDate(s: String): Long {
    return try {
        val f = SimpleDateFormat("dd/MM/yyyy", viLocale)
        f.isLenient = false
        f.parse(s.trim())?.time ?: 0L
    } catch (e: Exception) {
        0L
    }
}

fun monthStart(year: Int, month: Int): Long {
    val c = Calendar.getInstance()
    c.clear()
    c.set(year, month, 1, 0, 0, 0)
    return c.timeInMillis
}

/** month: 0-11. month có thể âm hoặc > 11 -> Calendar tự chuẩn hóa. */
fun monthRange(year: Int, month: Int): LongRange = monthStart(year, month) until monthStart(year, month + 1)

fun daysInMonth(year: Int, month: Int): Int {
    val c = Calendar.getInstance()
    c.clear()
    c.set(year, month, 1)
    return c.getActualMaximum(Calendar.DAY_OF_MONTH)
}

fun yearOf(t: Long): Int = Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.YEAR)
fun monthOf(t: Long): Int = Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.MONTH)
fun dayOf(t: Long): Int = Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.DAY_OF_MONTH)
