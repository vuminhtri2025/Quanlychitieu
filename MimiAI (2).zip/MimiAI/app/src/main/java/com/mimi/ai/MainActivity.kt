package com.mimi.ai

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mimi.ai.ui.AccountScreen
import com.mimi.ai.ui.AutoScreen
import com.mimi.ai.ui.BillsScreen
import com.mimi.ai.ui.BudgetScreen
import com.mimi.ai.ui.C
import com.mimi.ai.ui.ChatScreen
import com.mimi.ai.ui.DebtScreen
import com.mimi.ai.ui.MimiTheme
import com.mimi.ai.ui.MimiViewModel
import com.mimi.ai.ui.RecurringScreen
import com.mimi.ai.ui.ToolsScreen
import com.mimi.ai.ui.TransactionsScreen
import com.mimi.ai.ui.T
import com.mimi.ai.ui.VoiceOverlay
import com.mimi.ai.ui.WalletsScreen

class MainActivity : ComponentActivity() {
    private val vm: MimiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        )
        setContent {
            MimiTheme { MimiApp(vm) }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.runRecurring()
    }

    override fun onStop() {
        super.onStop()
        vm.save()
    }
}

private val tabs = listOf(
    "💬" to "Chat",
    "📒" to "Giao dịch",
    "👤" to "Tài khoản"
)

@Composable
fun MimiApp(vm: MimiViewModel) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var subScreen by remember { mutableStateOf("") }   // "" | "wallets"
    var showVoice by remember { mutableStateOf(false) }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            showVoice = true
        } else {
            Toast.makeText(ctx, "Cần cấp quyền micro để nhập bằng giọng nói", Toast.LENGTH_LONG).show()
        }
    }
    fun openMic() {
        tab = 0
        subScreen = ""
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) {
            showVoice = true
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    BackHandler(enabled = showVoice || subScreen.isNotEmpty() || tab != 0) {
        when {
            showVoice -> showVoice = false
            subScreen.isNotEmpty() -> subScreen = ""
            else -> tab = 0
        }
    }

    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    Surface(Modifier.fillMaxSize(), color = C.bg, contentColor = C.ink) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        subScreen == "wallets" -> WalletsScreen(vm) { subScreen = "" }
                        subScreen == "budget" -> BudgetScreen(vm) { subScreen = "" }
                        subScreen == "debts" -> DebtScreen(vm) { subScreen = "" }
                        subScreen == "auto" -> AutoScreen(vm) { subScreen = "" }
                        subScreen == "recurring" -> RecurringScreen(vm) { subScreen = "" }
                        subScreen == "bills" -> BillsScreen(vm) { subScreen = "" }
                        subScreen == "tools" -> ToolsScreen(vm) { subScreen = "" }
                        tab == 0 -> ChatScreen(vm, onMic = { openMic() })
                        tab == 1 -> TransactionsScreen(vm, onWallets = { tab = 2; subScreen = "wallets" })
                        else -> AccountScreen(vm, onOpen = { subScreen = it })
                    }
                }
                if (!imeVisible) {
                    BottomBar(tab) { tab = it; subScreen = "" }
                }
            }
            if (showVoice) {
                VoiceOverlay(
                    onResult = { text ->
                        showVoice = false
                        vm.send(text)
                    },
                    onClose = { showVoice = false }
                )
            }
        }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(C.white).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tabs.forEachIndexed { i, (icon, label) ->
            val sel = i == selected
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (sel) C.greenSoft else C.white)
                    .clickable { onSelect(i) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                T(icon, 20)
                T(label, 10, if (sel) FontWeight.Bold else FontWeight.Medium, if (sel) C.green else C.sub, maxLines = 1)
            }
        }
    }
}
