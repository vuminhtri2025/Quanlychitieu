package com.mimi.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mimi.ai.data.Cats
import com.mimi.ai.data.Debt
import com.mimi.ai.data.DebtDir
import com.mimi.ai.data.TxType
import com.mimi.ai.data.fmt
import com.mimi.ai.data.fmtDate
import com.mimi.ai.data.fmtDateTime
import com.mimi.ai.data.parseDate
import com.mimi.ai.data.parseMoney

// ============================================================ NGÂN SÁCH

@Composable
fun BudgetScreen(vm: MimiViewModel, onBack: () -> Unit) {
    val y = vm.currentYear()
    val m = vm.currentMonth()
    val spentBy = vm.categorySpent(y, m)
    val spent = spentBy.values.sum()
    val budget = vm.totalBudget()
    val pct = if (budget > 0) (spent * 100 / budget).toInt() else 0
    var editCat by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        SubHeader("Ngân sách", onBack)
        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), color = C.lilac) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("🎯", 30)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        T("Ngân sách tháng này", 14, FontWeight.SemiBold)
                        T(if (budget > 0) fmt(budget) else "Chưa đặt", 26, FontWeight.Bold)
                    }
                    if (budget > 0) {
                        val over = pct > 100
                        Box(Modifier.clip(RoundedCornerShape(50)).background(if (over) C.redSoft else C.greenSoft).padding(horizontal = 12.dp, vertical = 6.dp)) {
                            T("${if (over) "▲" else "●"} $pct%", 14, FontWeight.Bold, if (over) C.red else C.green)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                ProgressBar(if (budget > 0) spent.toFloat() / budget else 0f, if (pct > 100) C.red else C.green, 10.dp, C.white)
                Spacer(Modifier.height(8.dp))
                T(
                    "Đã dùng: ${fmt(spent)} • " + (if (budget > 0) (if (spent > budget) "Vượt: ${fmt(spent - budget)}" else "Còn lại: ${fmt(budget - spent)}") else "Chạm vào danh mục để đặt hạn mức"),
                    13, color = C.sub
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        T("Danh mục chi tiêu", 18, FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(8.dp))
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Cats.expense.forEach { cat ->
                val s = spentBy[cat.name] ?: 0L
                val limit = vm.budgets[cat.name] ?: 0L
                val frac = if (limit > 0) s.toFloat() / limit else 0f
                val col = when {
                    limit <= 0 -> Color(cat.color)
                    frac > 1f -> C.red
                    frac > 0.8f -> Color(0xFFF59E2B)
                    else -> Color(cat.color)
                }
                Card20(Modifier.fillMaxWidth().clickable { editCat = cat.name }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(cat.icon, Color(cat.color).copy(alpha = 0.15f), 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row {
                                T(cat.name, 15, FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                T(if (limit > 0) "${(frac * 100).toInt()}%" else "—", 13, FontWeight.SemiBold, col)
                            }
                            T(if (limit > 0) "${fmt(s)} / ${fmt(limit)}" else "${fmt(s)} • chưa đặt hạn mức", 12, color = C.sub)
                            Spacer(Modifier.height(6.dp))
                            ProgressBar(frac, col, 6.dp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.padding(horizontal = 20.dp)) { Tip(vm.tip()) }
    }

    editCat?.let { name ->
        var v by remember(name) { mutableStateOf((vm.budgets[name] ?: 0L).let { if (it > 0) it.toString() else "" }) }
        Dialog2("Ngân sách “$name”", { editCat = null }, "Lưu", onConfirm = { vm.setBudget(name, parseMoney(v)); editCat = null }) {
            MoneyField(v, { v = it }, "Hạn mức mỗi tháng")
            T("Để trống hoặc 0 để bỏ hạn mức.", 12, color = C.sub)
        }
    }
}

// ============================================================ NỢ

@Composable
fun DebtScreen(vm: MimiViewModel, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) } // 0 tất cả, 1 tôi nợ, 2 nợ tôi
    var adding by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Debt?>(null) }

    val all = vm.debts.sortedByDescending { it.createdAt }
    val filtered = all.filter { tab == 0 || (tab == 1 && it.dir == DebtDir.I_OWE) || (tab == 2 && it.dir == DebtDir.OWE_ME) }
    val open = filtered.filter { vm.remaining(it) > 0 }
    val closed = filtered.filter { vm.remaining(it) <= 0 }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        SubHeader("Sổ nợ", onBack) { RoundBtn("＋", C.green, Color.White) { adding = true } }
        Card20(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), color = C.lilac) {
            Column(Modifier.padding(18.dp)) {
                T("Tổng nợ phải trả", 15, FontWeight.SemiBold)
                T(fmt(vm.totalIOwe()), 32, FontWeight.Bold, C.red)
                Spacer(Modifier.height(6.dp))
                T("Được nợ (phải thu): ${fmt(vm.totalOwedToMe())}", 14, FontWeight.SemiBold, C.green)
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.padding(horizontal = 20.dp)) {
            PillRow(listOf("Tất cả", "Tôi nợ", "Nợ tôi"), tab) { tab = it }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (open.isEmpty() && closed.isEmpty()) {
                T("Chưa có khoản nợ nào.\nBấm ＋ hoặc nhắn Mimi: “Cho Nam vay 500k”, “Vay Hùng 2 triệu”.", 14, color = C.sub)
            }
            open.forEach { d -> DebtCard(vm, d) { selected = d } }
            if (closed.isNotEmpty()) {
                T("Đã tất toán", 14, FontWeight.SemiBold, C.sub, modifier = Modifier.padding(top = 8.dp))
                closed.forEach { d -> DebtCard(vm, d) { selected = d } }
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.padding(horizontal = 20.dp)) {
            Tip("Mẹo nhỏ: Thanh toán đúng hạn giúp bạn tránh phát sinh lãi suất và giữ uy tín nhé!")
        }
    }

    if (adding) AddDebtDialog(vm) { adding = false }
    selected?.let { d ->
        if (vm.debts.any { it.id == d.id }) {
            DebtDetailDialog(vm, d) { selected = null }
        }
    }
}

@Composable
private fun DebtCard(vm: MimiViewModel, d: Debt, onClick: () -> Unit) {
    val rem = vm.remaining(d)
    val paid = vm.repaid(d)
    val owe = d.dir == DebtDir.I_OWE
    val col = if (owe) C.red else C.green
    val overdue = d.dueAt > 0 && rem > 0 && d.dueAt < System.currentTimeMillis()
    Card20(Modifier.fillMaxWidth().clickable { onClick() }) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(if (owe) "🤝" else "💸", if (owe) C.redSoft else C.greenSoft)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    T(d.person, 16, FontWeight.Bold, maxLines = 1)
                    T(
                        (if (owe) "Tôi nợ" else "Nợ tôi") + " • Gốc ${fmt(d.principal)}" +
                            (if (d.dueAt > 0) " • Hạn ${fmtDate(d.dueAt)}" else ""),
                        12, color = if (overdue) C.red else C.sub, maxLines = 1
                    )
                }
                Spacer(Modifier.width(8.dp))
                T(if (rem > 0) fmt(rem) else "✓", 17, FontWeight.Bold, if (rem > 0) col else C.green)
            }
            Spacer(Modifier.height(10.dp))
            ProgressBar(if (d.principal > 0) paid.toFloat() / d.principal else 0f, if (owe) C.red else C.green, 6.dp)
            Spacer(Modifier.height(4.dp))
            T("Còn lại: ${fmt(rem)} • Đã ${if (owe) "trả" else "thu"}: ${fmt(paid)}" + (if (overdue) " • Quá hạn" else ""), 12, color = C.sub)
        }
    }
}

@Composable
private fun AddDebtDialog(vm: MimiViewModel, onClose: () -> Unit) {
    var dir by remember { mutableStateOf(DebtDir.OWE_ME) }
    var person by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var walletId by remember { mutableStateOf(vm.settings.defaultWalletId.ifBlank { vm.wallets.first().id }) }
    var due by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Dialog2("Thêm khoản nợ", onClose, "Lưu", onConfirm = {
        val a = parseMoney(amount)
        when {
            person.isBlank() -> error = "Hãy nhập tên người"
            a <= 0 -> error = "Hãy nhập số tiền"
            due.isNotBlank() && parseDate(due) == 0L -> error = "Hạn trả sai định dạng (dd/MM/yyyy)"
            else -> {
                vm.addDebt(dir, person, a, walletId, note.trim(), if (due.isBlank()) 0L else parseDate(due))
                onClose()
            }
        }
    }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Tôi cho vay", dir == DebtDir.OWE_ME) { dir = DebtDir.OWE_ME }
            Pill("Tôi đi vay", dir == DebtDir.I_OWE) { dir = DebtDir.I_OWE }
        }
        TextInput(person, { person = it }, "Người liên quan")
        MoneyField(amount, { amount = it })
        Picker(if (dir == DebtDir.OWE_ME) "Tiền ra từ" else "Tiền vào ví", vm.walletName(walletId), vm.wallets.map { it.icon + " " + it.name }) { walletId = vm.wallets[it].id }
        TextInput(due, { due = it }, "Hạn trả (dd/MM/yyyy, tùy chọn)")
        TextInput(note, { note = it }, "Ghi chú")
        if (error.isNotEmpty()) T(error, 13, color = C.red)
    }
}

@Composable
private fun DebtDetailDialog(vm: MimiViewModel, d: Debt, onClose: () -> Unit) {
    val owe = d.dir == DebtDir.I_OWE
    val rem = vm.remaining(d)
    var paying by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    if (paying) {
        var amount by remember { mutableStateOf(rem.toString()) }
        var walletId by remember { mutableStateOf(vm.settings.defaultWalletId.ifBlank { vm.wallets.first().id }) }
        Dialog2(if (owe) "Trả nợ ${d.person}" else "${d.person} trả nợ", { paying = false }, "Ghi nhận", onConfirm = {
            val a = parseMoney(amount)
            if (a > 0) {
                vm.repay(d, a, walletId)
                paying = false
                onClose()
            }
        }) {
            T("Còn lại: ${fmt(rem)}", 14, color = C.sub)
            MoneyField(amount, { amount = it }, if (owe) "Số tiền trả" else "Số tiền nhận")
            Picker(if (owe) "Trả từ ví" else "Nhận vào ví", vm.walletName(walletId), vm.wallets.map { it.icon + " " + it.name }) { walletId = vm.wallets[it].id }
        }
        return
    }

    Dialog2(d.person, onClose, if (rem > 0) (if (owe) "Trả nợ" else "Thu nợ") else null, if (rem > 0) ({ paying = true }) else null) {
        DetailLine("Loại", if (owe) "Tôi nợ" else "Nợ tôi")
        DetailLine("Số tiền gốc", fmt(d.principal))
        DetailLine("Còn lại", fmt(rem))
        DetailLine("Ngày tạo", fmtDate(d.createdAt))
        if (d.dueAt > 0) DetailLine("Hạn trả", fmtDate(d.dueAt))
        if (d.note.isNotBlank()) DetailLine("Ghi chú", d.note)
        val history = vm.txs.filter { it.debtId == d.id && it.type.isRepay }.sortedByDescending { it.time }
        if (history.isNotEmpty()) {
            T("Lịch sử ${if (owe) "trả" else "thu"} nợ", 14, FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            history.forEach { t ->
                Row(Modifier.fillMaxWidth()) {
                    T(fmtDateTime(t.time) + " • " + vm.walletName(t.walletId), 12, color = C.sub, modifier = Modifier.weight(1f))
                    T(fmt(t.amount), 13, FontWeight.SemiBold, if (owe) C.red else C.green)
                }
            }
        }
        if (!confirmDelete) {
            Box(Modifier.clip(RoundedCornerShape(50)).background(C.redSoft).clickable { confirmDelete = true }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                T("🗑 Xóa khoản nợ", 14, FontWeight.SemiBold, C.red)
            }
        } else {
            T("Xóa khoản nợ cùng toàn bộ giao dịch liên quan? Số dư ví sẽ được tính lại.", 13, color = C.red)
            Box(Modifier.clip(RoundedCornerShape(50)).background(C.red).clickable { vm.deleteDebt(d.id); onClose() }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                T("Xác nhận xóa", 14, FontWeight.SemiBold, Color.White)
            }
        }
    }
}
