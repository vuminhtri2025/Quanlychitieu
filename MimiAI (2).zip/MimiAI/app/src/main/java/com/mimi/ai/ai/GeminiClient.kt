package com.mimi.ai.ai

import com.mimi.ai.data.Cats
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gọi Gemini (tùy chọn). Nếu lỗi/không có mạng, ứng dụng tự quay về bộ phân tích nội bộ. */
object GeminiClient {

    private fun prompt(text: String, walletNames: List<String>, debtPeople: List<String>): String = """
Bạn là Mimi, trợ lý quản lý chi tiêu tiếng Việt. Phân tích câu của người dùng và CHỈ trả về một JSON object.
Các trường:
- intent: "expense" | "income" | "transfer" | "lend" (tôi cho người khác vay) | "borrow" (tôi đi vay) | "repay_paid" (tôi trả nợ) | "repay_received" (người khác trả nợ tôi) | "query" | "chat"
- amount: số nguyên VND (45k = 45000, 1 triệu rưỡi = 1500000). Nếu thiếu = 0.
- category: một trong [${Cats.expense.joinToString { it.name }}] cho chi tiêu, hoặc [${Cats.income.joinToString { it.name }}] cho thu nhập.
- wallet: tên ví nguồn, chọn trong [${walletNames.joinToString()}] hoặc rỗng nếu không nhắc tới.
- to_wallet: tên ví đích khi chuyển ví.
- person: tên người liên quan đến vay/nợ. Các khoản nợ đang mở với: [${debtPeople.joinToString()}].
- note: nội dung ngắn gọn.
- query: "balance" | "spend" | "debt" | "advice" | "help" khi intent = query.
- reply: câu trả lời ngắn thân thiện bằng tiếng Việt khi intent = chat.
Câu người dùng: "${text.replace("\"", "'")}"
""".trimIndent()

    /** Chạy trên luồng IO. Trả về null nếu thất bại. */
    fun classify(
        apiKey: String,
        model: String,
        text: String,
        walletNames: List<String>,
        debtPeople: List<String>
    ): JSONObject? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent?key=${apiKey.trim()}")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt(text, walletNames, debtPeople)))
                        )
                    )
                )
                .put(
                    "generationConfig",
                    JSONObject().put("temperature", 0.1).put("responseMimeType", "application/json")
                )
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val resp = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val out = JSONObject(resp)
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
            JSONObject(out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
