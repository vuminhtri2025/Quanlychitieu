@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.Manifest
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.text.input.VisualTransformation
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val RED = Color(0xFFD32F2F)
private val GREEN = Color(0xFF2E7D32)

@Composable
fun Pick(value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("$value ▾") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false }) }
        }
    }
}

private val AVATARS = listOf(Color(0xFF2E9E5B), Color(0xFF1E88E5), Color(0xFFF4511E),
    Color(0xFF8E24AA), Color(0xFFFB8C00), Color(0xFF00897B))

/** Tab Chat: Store.chatWallet == 0 (hoặc ví không còn) -> danh sách ví; ngược lại -> cuộc trò chuyện của ví đó. */
@Composable
fun ChatScreen(active: Boolean = true) {
    val w = Store.wallets.firstOrNull { it.id == Store.chatWallet }
    if (w == null) ChatList() else ChatRoom(w, active)
}

@Composable
fun ChatList() {
    val total = Store.wallets.groupBy { it.currency }.mapValues { e -> e.value.sumOf { Store.balance(it) } }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 8.dp)) {
            Text("🤖 ${Store.aiName}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Tổng số dư: ${total.show()}", style = MaterialTheme.typography.bodySmall)
        }
        HorizontalDivider()
        LazyColumn(Modifier.fillMaxSize()) {
            items(Store.wallets.toList(), key = { it.id }) { w ->
                val bal = Store.balance(w)
                val last = Store.chats[w.id]?.takeIf { it.size > 1 }?.lastOrNull()
                val preview = when {
                    w.id in Store.busy -> "${Store.aiName} đang nghĩ…"
                    last == null -> "Chạm để bắt đầu trò chuyện"
                    else -> (if (last.fromUser) "Bạn: " else "") + last.text.replace('\n', ' ')
                }
                val ini = w.name.trim().let { if (it.isEmpty()) "?" else String(Character.toChars(it.codePointAt(0))).uppercase() }
                Row(Modifier.fillMaxWidth().clickable { Store.chatWallet = w.id }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(AVATARS[(w.name.hashCode() and 0x7fffffff) % AVATARS.size], CircleShape),
                        contentAlignment = Alignment.Center) {
                        Text(ini, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(w.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.width(8.dp))
                            Text(bal.money(w.currency), fontWeight = FontWeight.Medium, color = if (bal < 0) RED else Color.Unspecified)
                        }
                        Text(preview, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                HorizontalDivider(Modifier.padding(start = 76.dp))
            }
        }
    }
}

@Composable
fun ChatRoom(w: Wallet, active: Boolean) {
    val ctx = LocalContext.current
    val wid = w.id
    val chat = Store.chatOf(wid)
    val maxBubble = (LocalConfiguration.current.screenWidthDp * 0.78f).dp
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val busy = wid in Store.busy
    BackHandler(enabled = active) { Store.chatWallet = 0L }
    var recording by remember { mutableStateOf(false) }
    val recorder = remember { Recorder() }
    val needKey = "Bạn chưa nhập API key. Vào tab Cài đặt, dán key lấy từ Google AI Studio nhé."

    fun say(t: String) { chat.add(Msg(false, t)) }
    // Chạy trên scope của app: rời khỏi phòng chat khi AI đang trả lời thì câu trả lời vẫn được lưu vào ví đó
    fun run(m: Msg, audio: ByteArray?) {
        Store.busy.add(wid)
        Store.scope.launch {
            try {
                val r = Gemini.ask(chat, wid, audio)
                if (audio != null) m.text = "🎤 " + r.heard.ifBlank { "(không nghe rõ)" }
                r.items.forEach { if (it.auto && Store.savePending(it) == null) { it.saved = true; it.autoSaved = true } }
                chat.add(Msg(false, r.reply, r.items).also { it.typing = Store.typeEffect })
            } catch (e: Exception) {
                say("⚠️ ${e.message}")
            } finally {
                Store.busy.remove(wid)
                Store.saveChats()
            }
        }
    }
    fun send(t: String) {
        if (t.isBlank() || busy) return
        if (Store.apiKey.isBlank()) { say(needKey); return }
        val m = Msg(true, t); chat.add(m); input = ""; run(m, null)
    }
    fun stopRec() {
        if (!recording) return
        recording = false
        val pcm = recorder.stop()
        if (!hasSound(pcm)) { say("Không thu được âm thanh (mic có thể đang bị app khác chặn). Thử đổi chế độ trong Cài đặt → Giọng nói."); return }
        if (Store.apiKey.isBlank()) { say(needKey); return }
        val m = Msg(true, "🎤 đang nghe…"); chat.add(m); run(m, wav(pcm))
    }
    fun startRec() {
        try { recorder.start(); recording = true } catch (e: Exception) { say("⚠️ Không mở được mic: ${e.message}. Thử đổi chế độ trong Cài đặt → Giọng nói.") }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else say("Bạn chưa cấp quyền micro cho app.")
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }
    LaunchedEffect(chat.size, busy, wid) { list.animateScrollToItem(chat.size) }
    LaunchedEffect(chat.size, busy) { if (!busy) Store.saveChats() }
    val last = chat.lastOrNull()
    LaunchedEffect(last, last?.typing) { while (last?.typing == true) { list.scrollToItem(chat.size); delay(200) } }
    LaunchedEffect(recording) { if (recording) { delay(Store.maxRecSec * 1000L); stopRec() } }
    // rời phòng chat khi đang ghi âm thì dừng mic, không gửi
    DisposableEffect(Unit) { onDispose { if (recording) { recording = false; recorder.stop() } } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { Store.chatWallet = 0L }) { Text("←", style = MaterialTheme.typography.titleLarge) }
            Column(Modifier.weight(1f)) {
                Text("👛 ${w.name}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Số dư: ${Store.balance(w).money(w.currency)} • 🤖 ${Store.aiName}", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { Store.resetChat(wid) }) { Text("🧹") }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp), state = list, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(chat) { m ->
                val align = if (m.fromUser) Alignment.End else Alignment.Start
                Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
                    Column(Modifier.widthIn(max = maxBubble), horizontalAlignment = align) {
                        Surface(shape = RoundedCornerShape(14.dp),
                            color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                            BubbleText(m)
                        }
                        if (!m.typing) m.pending.forEach { PendingCard(it) }
                    }
                }
            }
            item { if (busy) Text("${Store.aiName} đang nghĩ…", style = MaterialTheme.typography.bodySmall) }
        }
        if (recording) Text("🔴 Đang ghi âm… nói xong bấm ⏹ để gửi cho Gemini", Modifier.padding(horizontal = 12.dp), color = RED)
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Nhập khoản chi tiêu…") }, maxLines = 3)
            IconButton(onClick = {
                if (Store.voiceMode == "system") {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
                    try { voice.launch(i) } catch (e: ActivityNotFoundException) {
                        Toast.makeText(ctx, "Máy chưa có dịch vụ nhận diện giọng nói", Toast.LENGTH_SHORT).show()
                    }
                } else if (recording) stopRec()
                else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
                else perm.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text(if (recording) "⏹" else "🎤") }
            Button(onClick = { send(input) }, enabled = !busy) { Text("Gửi") }
        }
    }
}

@Composable
fun MonthBar(off: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = { onChange(off - 1) }) { Text("◀") }
        Text(SimpleDateFormat("'Tháng' MM/yyyy", Locale.US).format(monthStart(off).time), fontWeight = FontWeight.Bold)
        TextButton(onClick = { onChange(off + 1) }, enabled = off < 0) { Text("▶") }
    }
}

@Composable
fun BudgetScreen() {
    var edit by remember { mutableStateOf<String?>(null) }
    var txt by remember { mutableStateOf("") }
    val spent = txsOfMonth(0).filter { !it.income && Store.cur(it.walletId) == "VND" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Ngân sách tháng này (chạm để đặt hạn mức)", fontWeight = FontWeight.Bold)
        CATEGORIES.filter { it !in INCOME_CATS }.forEach { c ->
            val lim = Store.budgets[c] ?: 0L
            val s = spent[c] ?: 0L
            Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                .padding(10.dp).then(Modifier), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { edit = c; txt = if (lim > 0) lim.toString() else "" }) {
                    Text("$c: ${s.vnd()} / ${if (lim > 0) lim.vnd() else "chưa đặt"}")
                }
                if (lim > 0) {
                    LinearProgressIndicator(progress = { (s.toFloat() / lim).coerceAtMost(1f) }, Modifier.fillMaxWidth(),
                        color = if (s > lim) RED else MaterialTheme.colorScheme.primary)
                    if (s > lim) Text("⚠️ Vượt ngân sách ${(s - lim).vnd()}", color = RED)
                }
            }
        }
    }
    edit?.let { c ->
        AlertDialog(onDismissRequest = { edit = null }, title = { Text("Hạn mức: $c") },
            text = { OutlinedTextField(txt, { txt = it.filter(Char::isDigit) }, label = { Text("Số tiền (đ)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
            confirmButton = { TextButton(onClick = {
                val v = txt.toLongOrNull() ?: 0L
                if (v > 0) Store.budgets[c] = v else Store.budgets.remove(c)
                Store.save(); edit = null
            }) { Text("Lưu") } },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("Hủy") } })
    }
}

@Composable
fun DateTimeRow(time: Long, onChange: (Long) -> Unit) {
    val ctx = LocalContext.current
    val cal = Calendar.getInstance().apply { timeInMillis = time }
    Row {
        TextButton(onClick = {
            DatePickerDialog(ctx, { _, y, m, d ->
                onChange(Calendar.getInstance().apply { timeInMillis = time; set(y, m, d) }.timeInMillis)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }) { Text("📅 " + SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(time))) }
        TextButton(onClick = {
            TimePickerDialog(ctx, { _, h, mi ->
                onChange(Calendar.getInstance().apply { timeInMillis = time; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, mi) }.timeInMillis)
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }) { Text("🕒 " + SimpleDateFormat("HH:mm", Locale.US).format(Date(time))) }
    }
}

@Composable
fun EditTxDialog(t: Tx, onClose: () -> Unit) {
    var amount by remember { mutableStateOf(t.amount.toString()) }
    var income by remember { mutableStateOf(t.income) }
    var wid by remember { mutableLongStateOf(t.walletId) }
    var cat by remember { mutableStateOf(t.category) }
    var note by remember { mutableStateOf(t.note) }
    var time by remember { mutableLongStateOf(t.time) }
    var report by remember { mutableStateOf(t.report) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Sửa giao dịch") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false }, label = { Text("Chi") })
                    FilterChip(selected = income, onClick = { income = true }, label = { Text("Thu") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pick(Store.walletName(wid), Store.wallets.map { it.name }) { n -> Store.wallets.firstOrNull { it.name == n }?.let { wid = it.id } }
                    Pick(cat, CATEGORIES) { cat = it }
                }
                DateTimeRow(time) { time = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                ReportSwitch(report) { report = it }
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = amount.toLongOrNull() ?: 0L
            if (a > 0) { Store.updateTx(t.copy(amount = a, income = income, walletId = wid, category = cat, note = note, time = time, report = report)); onClose() }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun HistoryScreen() {
    var off by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    val ctx = LocalContext.current
    var transferring by remember { mutableStateOf(false) }
    val list = txsOfMonth(off, true).filter { !(it.transferId != 0L && it.income) }.sortedByDescending { it.time }
    val rep = txsOfMonth(off)
    val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        MonthBar(off) { off = it }
        Text("Chi ${sumByCur(rep.filter { !it.income }).show()}  •  Thu ${sumByCur(rep.filter { it.income }).show()}")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Chạm vào giao dịch để sửa", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { transferring = true }) { Text("🔁 Chuyển ví") }
        }
        if (list.isEmpty()) Text("Chưa có giao dịch.", Modifier.padding(top = 16.dp))
        LazyColumn {
            items(list, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth().clickable { if (t.debtId == 0L) editing = t else Toast.makeText(ctx, "Khoản vay/nợ: sửa trong tab Nợ", Toast.LENGTH_SHORT).show() }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (t.transferId != 0L) "🔁 Chuyển ví • ${Store.walletName(t.walletId)} → ${Store.walletName(Store.txs.firstOrNull { it.transferId == t.transferId && it.income }?.walletId ?: 0L)}" else "${t.category} • ${Store.walletName(t.walletId)}", fontWeight = FontWeight.Medium)
                        Text(df.format(Date(t.time)) + (if (t.note.isNotBlank()) " — ${t.note}" else "") + (if (!t.report && t.debtId == 0L) " • không tính báo cáo" else ""), style = MaterialTheme.typography.bodySmall)
                    }
                    Text(if (t.transferId != 0L) t.fmt() else (if (t.income) "+" else "-") + t.fmt(), color = if (t.transferId != 0L) Color.Gray else if (t.income) GREEN else RED)
                    if (t.debtId == 0L) TextButton(onClick = { if (t.transferId != 0L) Store.deleteTransfer(t.transferId) else { Store.txs.remove(t); Store.save() } }) { Text("🗑") } else Text("🤝", Modifier.padding(12.dp))
                }
                HorizontalDivider()
            }
        }
    }
    editing?.let { if (it.transferId != 0L) TransferDialog(it) { editing = null } else EditTxDialog(it) { editing = null } }
    if (transferring) TransferDialog(null) { transferring = false }
}

@Composable
fun StatsScreen() {
    var off by remember { mutableIntStateOf(0) }
    val m = txsOfMonth(off)
    val thu = sumByCur(m.filter { it.income })
    val chiAll = sumByCur(m.filter { !it.income })
    val net = (thu.keys + chiAll.keys).associateWith { (thu[it] ?: 0L) - (chiAll[it] ?: 0L) }
    val chi = m.filter { !it.income && Store.cur(it.walletId) == "VND" }
    val total = chi.sumOf { it.amount }
    val byCat = chi.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        MonthBar(off) { off = it }
        Text("Thu: ${thu.show()}", color = GREEN); Text("Chi: ${chiAll.show()}", color = RED)
        Text("Còn lại: ${net.show()}", fontWeight = FontWeight.Bold)
        Text("Chi theo mục (ví VND)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        byCat.forEach { (k, v) ->
            Text("$k — ${v.vnd()} (${if (total > 0) v * 100 / total else 0}%)")
            LinearProgressIndicator(progress = { if (total > 0) v.toFloat() / total else 0f }, Modifier.fillMaxWidth())
        }
        Text("Số dư các ví", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Store.wallets.forEach { Text("${it.name}: ${Store.balance(it).money(it.currency)}") }
    }
}

@Composable
fun WalletDialog(w: Wallet?, onClose: () -> Unit) {
    var name by remember { mutableStateOf(w?.name ?: "") }
    var cur by remember { mutableStateOf(w?.currency ?: "VND") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (w == null) "Thêm ví" else "Sửa ví") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Tên ví") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Đơn vị tiền: "); Pick(cur, CURRENCIES.keys.toList()) { cur = it } }
                if (err.isNotEmpty()) Text(err, color = RED)
            }
        },
        confirmButton = { TextButton(onClick = {
            val n = name.trim()
            if (n.isEmpty()) err = "Tên ví không được để trống"
            else if (Store.wallets.any { it.name.equals(n, true) && it.id != w?.id }) err = "Tên ví đã tồn tại"
            else {
                if (w == null) Store.wallets.add(Wallet(System.currentTimeMillis(), n, cur))
                else { val i = Store.wallets.indexOfFirst { it.id == w.id }; if (i >= 0) Store.wallets[i] = w.copy(name = n, currency = cur) }
                Store.save(); onClose()
            }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun DeleteWalletDialog(w: Wallet, onClose: () -> Unit) {
    val n = Store.txs.count { it.walletId == w.id }
    val others = Store.wallets.filter { it.id != w.id }
    var target by remember { mutableLongStateOf(others.first().id) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Xóa ví \"${w.name}\"") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (n == 0) Text("Ví chưa có giao dịch nào.") else {
                    Text("Ví có $n giao dịch. Chuyển chúng sang ví:")
                    Pick(Store.walletName(target), others.map { it.name }) { nm -> others.firstOrNull { it.name == nm }?.let { target = it.id } }
                }
            }
        },
        confirmButton = { TextButton(onClick = { Store.deleteWallet(w.id, if (n == 0) null else target); onClose() }) {
            Text(if (n == 0) "Xóa ví" else "Chuyển & xóa ví") } },
        dismissButton = { Column {
            if (n > 0) TextButton(onClick = { Store.deleteWallet(w.id, null); onClose() }) { Text("Xóa cả giao dịch", color = RED) }
            TextButton(onClick = onClose) { Text("Hủy") }
        } })
}

@Composable
fun SettingsScreen(active: Boolean = true) {
    var page by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = active && page != null) { page = null }
    val p = page
    if (p == null) SettingsMenu { page = it } else SettingsPage(p) { page = null }
}

@Composable
fun SettingsMenu(open: (String) -> Unit) {
    val rows = listOf(
        Triple("ai", "🤖 Trợ lý AI", "${Store.aiName} • ${Store.persona} • trả lời ${Store.replyLen.lowercase()}"),
        Triple("auto", "⚡ Tự động lưu", if (Store.autoSave) "Bật • ngưỡng ${(Store.autoThreshold * 100).toInt()}% • AI đã học ${Auto.learned()} giao dịch" else "Tắt"),
        Triple("key", "🔑 Kết nối Gemini", Store.model + " • " + if (Store.apiKey.isBlank()) "chưa nhập key" else "đã có key"),
        Triple("voice", "🎙️ Giọng nói", if (Store.voiceMode == "gemini") "Ghi âm → Gemini nghe" else "Nhận diện của máy"),
        Triple("fx", "✨ Hiệu ứng chat", if (Store.typeEffect) "Chữ hiện dần • ${Store.typeMs / 1000}s" else "Tắt"),
        Triple("wallet", "👛 Ví", "${Store.wallets.size} ví"),
        Triple("data", "📤 Dữ liệu", "${Store.txs.size} giao dịch")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Cài đặt", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        rows.forEach { (id, title, sub) ->
            Card(Modifier.fillMaxWidth().clickable { open(id) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(sub, style = MaterialTheme.typography.bodySmall) }
                    Text("›")
                }
            }
        }
    }
}

@Composable
fun SettingsPage(id: String, back: () -> Unit) {
    val title = when (id) {
        "ai" -> "🤖 Trợ lý AI"; "auto" -> "⚡ Tự động lưu"; "key" -> "🔑 Kết nối Gemini"; "voice" -> "🎙️ Giọng nói"
        "fx" -> "✨ Hiệu ứng chat"; "wallet" -> "👛 Ví"; else -> "📤 Dữ liệu"
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = back) { Text("← Cài đặt") }
            Text(title, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (id) {
                "ai" -> AiSettings()
                "auto" -> AutoSettings()
                "key" -> KeySettings()
                "voice" -> VoiceSettings()
                "fx" -> FxSettings()
                "wallet" -> WalletSettings()
                else -> DataSettings()
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun Chips(options: List<String>, selected: String, onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o -> FilterChip(selected = o == selected, onClick = { onPick(o) }, label = { Text(o) }) }
    }
}

@Composable
fun Radio(label: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Column { Text(label, fontWeight = FontWeight.Medium); if (desc.isNotEmpty()) Text(desc, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun AiSettings() {
    Section("Nhân vật") {
        OutlinedTextField(Store.aiName, { Store.aiName = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("Tên AI") }, singleLine = true)
        OutlinedTextField(Store.userName, { Store.userName = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("AI gọi bạn là") }, singleLine = true)
    }
    Section("Tính cách") {
        PERSONAS.forEach { (k, v) -> Radio(k, v, Store.persona == k) { Store.persona = k; Store.save() } }
    }
    Section("Cách trả lời") {
        Text("Độ dài")
        Chips(listOf("Ngắn", "Vừa", "Chi tiết"), Store.replyLen) { Store.replyLen = it; Store.save() }
        Text("Độ sáng tạo: " + String.format(Locale.US, "%.1f", Store.temp))
        Slider(Store.temp, { Store.temp = it }, valueRange = 0f..1f, onValueChangeFinished = { Store.save() })
    }
}

@Composable
fun KeySettings() {
    var show by remember { mutableStateOf(false) }
    Section("API key Google AI Studio") {
        OutlinedTextField(Store.apiKey, { Store.apiKey = it; Store.save() }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation())
        TextButton(onClick = { show = !show }) { Text(if (show) "🙈 Ẩn key" else "👁 Hiện key") }
        Text("Key chỉ lưu trên máy này. Lấy key tại aistudio.google.com.", style = MaterialTheme.typography.bodySmall)
    }
    Section("Model") {
        OutlinedTextField(Store.model, { Store.model = it.trim(); Store.save() }, Modifier.fillMaxWidth(), label = { Text("Tên model") }, singleLine = true)
        Chips(listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro"), Store.model) { Store.model = it; Store.save() }
    }
}

@Composable
fun VoiceSettings() {
    Section("Cách nhập giọng nói") {
        Radio("Ghi âm rồi gửi Gemini nghe", "Khuyên dùng: Gemini nghe và hiểu thẳng", Store.voiceMode == "gemini") { Store.voiceMode = "gemini"; Store.save() }
        Radio("Nhận diện giọng nói của máy", "Dùng bộ nhận diện Google có sẵn trên máy", Store.voiceMode == "system") { Store.voiceMode = "system"; Store.save() }
    }
    Section("Ghi âm tối đa (giây)") {
        Chips(listOf("30", "60", "120"), Store.maxRecSec.toString()) { Store.maxRecSec = it.toInt(); Store.save() }
    }
    Section("Khi mic không hoạt động") {
        Text("Nếu ghi âm không thu được tiếng, thử đổi sang \"Nhận diện giọng nói của máy\" ở trên (hoặc ngược lại).", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun FxSettings() {
    Section("Chữ hiện dần khi AI trả lời") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Bật hiệu ứng", Modifier.weight(1f))
            Switch(Store.typeEffect, { Store.typeEffect = it; Store.save() })
        }
        Text("Thời gian hiện hết một tin nhắn dài (giây)")
        Chips(listOf("2", "3", "5"), (Store.typeMs / 1000).toString()) { Store.typeMs = it.toInt() * 1000; Store.save() }
    }
}

@Composable
fun WalletSettings() {
    var editW by remember { mutableStateOf<Wallet?>(null) }
    var delW by remember { mutableStateOf<Wallet?>(null) }
    var adding by remember { mutableStateOf(false) }
    Section("Danh sách ví") {
        Store.wallets.toList().forEach { w ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(w.name, fontWeight = FontWeight.Medium)
                    Text("${w.currency} • ${Store.balance(w).money(w.currency)}", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { editW = w }) { Text("✏️") }
                if (Store.wallets.size > 1) TextButton(onClick = { delW = w }) { Text("🗑") }
            }
        }
        Button(onClick = { adding = true }) { Text("➕ Thêm ví") }
    }
    editW?.let { WalletDialog(it) { editW = null } }
    if (adding) WalletDialog(null) { adding = false }
    delW?.let { DeleteWalletDialog(it) { delW = null } }
}

@Composable
fun DataSettings() {
    val ctx = LocalContext.current
    Section("Xuất dữ liệu") {
        Text("${Store.txs.size} giao dịch", style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val csv = "Thời gian,Loại,Số tiền,Đơn vị,Ví,Mục,Ghi chú\n" + Store.txs.sortedBy { it.time }.joinToString("\n") {
                "${f.format(Date(it.time))},${if (it.income) "Thu" else "Chi"},${it.amount},${Store.cur(it.walletId)},${Store.walletName(it.walletId)},${it.category},\"${it.note.replace("\"", "\"\"")}\""
            }
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, csv), "Xuất CSV"))
        }) { Text("📤 Xuất CSV") }
    }
    Section("Cuộc trò chuyện") {
        OutlinedButton(onClick = { Store.resetChat() }) { Text("🧹 Xóa tất cả cuộc trò chuyện") }
    }
}

@Composable
fun BubbleText(m: Msg) {
    var shown by remember { mutableIntStateOf(if (m.typing) 0 else m.text.length) }
    LaunchedEffect(m) {
        if (m.typing) {
            val n = m.text.length
            val ms = (n * 50L).coerceIn(800L, Store.typeMs.toLong()).toInt()
            try {
                Animatable(0f).animateTo(1f, tween(ms, easing = LinearEasing)) { shown = (value * n).toInt() }
            } finally { m.typing = false }
        }
    }
    val txt = if (m.typing) buildAnnotatedString {
        append(m.text.take(shown))
        withStyle(SpanStyle(color = Color.Transparent)) { append(m.text.drop(shown)) }
    } else AnnotatedString(m.text)
    Text(txt, Modifier.padding(10.dp))
}

@Composable
fun DueRow(due: Long, onChange: (Long) -> Unit) {
    val ctx = LocalContext.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = {
            val c = Calendar.getInstance().apply { if (due > 0) timeInMillis = due }
            DatePickerDialog(ctx, { _, y, m, d ->
                onChange(Calendar.getInstance().apply { set(y, m, d, 23, 59, 59) }.timeInMillis)
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }) { Text("📆 Hạn trả: " + if (due > 0) SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(due)) else "chưa đặt") }
        if (due > 0) TextButton(onClick = { onChange(0L) }) { Text("✕") }
    }
}

@Composable
fun PendingCard(p: Pending) {
    if (p.dismissed) return
    if (p.autoSaved) { AutoSavedCard(p); return }
    val debt = p.kind in listOf("borrow", "lend", "repay", "collect")
    Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text(p.label() + ": " + (if (p.kind == "transfer") "" else if (p.isIncome()) "+" else "-") + p.amount.money(Store.cur(p.walletId)),
                fontWeight = FontWeight.Bold, color = if (p.kind == "transfer") Color.Gray else if (p.isIncome()) GREEN else RED)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pick(p.label(), KIND_LABELS) { p.setLabel(it) }
                Pick(Store.walletName(p.walletId), Store.wallets.map { it.name }) { n ->
                    Store.wallets.firstOrNull { it.name == n }?.let {
                        p.walletId = it.id
                        if (p.kind == "transfer" && !Store.canTransfer(p.walletId, p.toWalletId)) p.toWalletId = Store.defaultTo(p.walletId)
                    }
                }
            }
            if (p.kind == "transfer") {
                val opts = Store.wallets.filter { it.id != p.walletId && it.currency == Store.cur(p.walletId) }
                if (opts.isEmpty()) Text("Chưa có ví thứ hai cùng đơn vị tiền để chuyển.", color = RED, style = MaterialTheme.typography.bodySmall)
                else Pick("→ " + (Store.wallets.firstOrNull { it.id == p.toWalletId }?.name ?: "Chọn ví nhận"), opts.map { it.name }) { n ->
                    opts.firstOrNull { it.name == n }?.let { p.toWalletId = it.id }
                }
            } else if (!debt) Pick(p.category, CATEGORIES) { p.category = it; p.income = it in INCOME_CATS }
            else {
                OutlinedTextField(p.person, { p.person = it }, Modifier.fillMaxWidth(), label = { Text("Tên người") }, singleLine = true)
                if (p.kind == "borrow" || p.kind == "lend") DueRow(p.due) { p.due = it }
            }
            DateTimeRow(p.time) { p.time = it }
            if (!debt) ReportSwitch(p.report) { p.report = it }
            if (p.note.isNotBlank()) Text("📝 ${p.note}", style = MaterialTheme.typography.bodySmall)
            if (p.error.isNotEmpty()) Text(p.error, color = RED, style = MaterialTheme.typography.bodySmall)
            if (p.conf > 0f && p.kind == "tx" && !p.saved) Text("🤔 Tin cậy ${(p.conf * 100).toInt()}% — cần bạn xác nhận: ${p.why}", style = MaterialTheme.typography.bodySmall)
            if (p.saved) Text("✅ Đã lưu", color = GREEN) else Row {
                Button(onClick = {
                    val e = Store.savePending(p)
                    if (e == null) { p.saved = true; p.error = "" } else p.error = e
                }) { Text("Lưu") }
                TextButton(onClick = { p.dismissed = true }) { Text("Bỏ") }
            }
        }
    }
}

fun sumDebt(l: List<Debt>): Map<String, Long> = l.groupBy { it.cur }.mapValues { e -> e.value.sumOf { Store.remaining(it) } }

@Composable
fun DebtScreen() {
    val names = listOf("Mình nợ", "Nợ mình", "Đã xong")
    var tab by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    val open = Store.debts.filter { Store.remaining(it) > 0 }
    val shown = when (tab) {
        0 -> open.filter { !it.lend }
        1 -> open.filter { it.lend }
        else -> Store.debts.filter { Store.remaining(it) <= 0 }
    }
    Column(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Mình đang nợ: " + sumDebt(open.filter { !it.lend }).show(), color = RED, fontWeight = FontWeight.Bold)
                Text("Người khác nợ mình: " + sumDebt(open.filter { it.lend }).show(), color = GREEN, fontWeight = FontWeight.Bold)
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Chips(names, names[tab]) { tab = names.indexOf(it) } }
            Button(onClick = { adding = true }) { Text("➕ Thêm") }
        }
        if (shown.isEmpty()) Text("Chưa có khoản nào. Bạn cũng có thể nhắn cho AI: \"vay anh Nam 2 triệu\".", Modifier.padding(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown.sortedBy { if (it.due > 0) it.due else Long.MAX_VALUE }, key = { it.id }) { DebtCard(it) }
        }
    }
    if (adding) DebtDialog(null) { adding = false }
}

@Composable
fun DebtCard(d: Debt) {
    var expand by remember { mutableStateOf(false) }
    var pay by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    val paid = Store.paid(d)
    val rem = d.principal - paid
    val over = d.due > 0 && d.due < System.currentTimeMillis() && rem > 0
    val df = remember { SimpleDateFormat("dd/MM/yyyy", Locale.US) }
    val dft = remember { SimpleDateFormat("dd/MM HH:mm", Locale.US) }
    val verb = if (d.lend) "thu" else "trả"
    Card(Modifier.fillMaxWidth().clickable { expand = !expand }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row {
                Text((if (d.lend) "👤 " else "🏦 ") + d.person, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(rem.money(d.cur), color = if (d.lend) GREEN else RED, fontWeight = FontWeight.Bold)
            }
            Text("Gốc ${d.principal.money(d.cur)} • đã $verb ${paid.money(d.cur)}", style = MaterialTheme.typography.bodySmall)
            LinearProgressIndicator(progress = { (paid.toFloat() / d.principal).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
            Text("Ngày ${df.format(Date(d.time))}" + if (d.due > 0) " • hạn ${df.format(Date(d.due))}" else "",
                style = MaterialTheme.typography.bodySmall, color = if (over) RED else Color.Unspecified)
            if (over) Text("⚠️ Quá hạn", color = RED, fontWeight = FontWeight.Bold)
            if (d.note.isNotBlank()) Text("📝 ${d.note}", style = MaterialTheme.typography.bodySmall)
            if (expand) {
                val pays = Store.txs.filter { it.debtId == d.id && it.id != d.id }.sortedByDescending { it.time }
                if (pays.isEmpty()) Text("Chưa có lần $verb nào.", style = MaterialTheme.typography.bodySmall)
                pays.forEach { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${dft.format(Date(t.time))} • ${Store.walletName(t.walletId)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Text(t.amount.money(d.cur))
                        TextButton(onClick = { Store.txs.remove(t); Store.save() }) { Text("🗑") }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (rem > 0) Button(onClick = { pay = true }) { Text(if (d.lend) "💰 Thu nợ" else "💸 Trả nợ") }
                TextButton(onClick = { edit = true }) { Text("✏️ Sửa") }
                TextButton(onClick = { del = true }) { Text("🗑 Xóa", color = RED) }
            }
        }
    }
    if (pay) PayDialog(d) { pay = false }
    if (edit) DebtDialog(d) { edit = false }
    if (del) AlertDialog(onDismissRequest = { del = false }, title = { Text("Xóa khoản nợ của ${d.person}?") },
        text = { Text("Sẽ xóa luôn các giao dịch gốc và trả/thu của khoản này, số dư ví thay đổi theo.") },
        confirmButton = { TextButton(onClick = { Store.deleteDebt(d); del = false }) { Text("Xóa", color = RED) } },
        dismissButton = { TextButton(onClick = { del = false }) { Text("Hủy") } })
}

@Composable
fun PayDialog(d: Debt, onClose: () -> Unit) {
    val rem = Store.remaining(d)
    val ws = Store.wallets.filter { it.currency == d.cur }
    var amount by remember { mutableStateOf(rem.toString()) }
    var wid by remember { mutableLongStateOf(ws.firstOrNull()?.id ?: 0L) }
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (d.lend) "Thu nợ từ ${d.person}" else "Trả nợ cho ${d.person}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (ws.isEmpty()) Text("Chưa có ví nào dùng đơn vị ${d.cur}. Hãy thêm ví trong Cài đặt.", color = RED) else {
                    Text("Còn lại: ${rem.money(d.cur)}")
                    OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Pick(Store.walletName(wid), ws.map { it.name }) { n -> ws.firstOrNull { it.name == n }?.let { wid = it.id } }
                    DateTimeRow(time) { time = it }
                    OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                }
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = (amount.toLongOrNull() ?: 0L).coerceAtMost(rem)
            if (a > 0 && wid != 0L) { Store.addPayment(d, a, wid, time, note); onClose() }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun DebtDialog(d: Debt?, onClose: () -> Unit) {
    var lend by remember { mutableStateOf(d?.lend ?: false) }
    var person by remember { mutableStateOf(d?.person ?: "") }
    var amount by remember { mutableStateOf("") }
    var wid by remember { mutableLongStateOf(Store.wallets.first().id) }
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var due by remember { mutableLongStateOf(d?.due ?: 0L) }
    var note by remember { mutableStateOf(d?.note ?: "") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (d == null) "Thêm khoản nợ" else "Sửa khoản nợ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (d == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !lend, onClick = { lend = false }, label = { Text("Mình vay") })
                        FilterChip(selected = lend, onClick = { lend = true }, label = { Text("Cho vay") })
                    }
                }
                OutlinedTextField(person, { person = it }, label = { Text("Tên người") }, singleLine = true)
                if (d == null) {
                    OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Pick(Store.walletName(wid), Store.wallets.map { it.name }) { n -> Store.wallets.firstOrNull { it.name == n }?.let { wid = it.id } }
                    DateTimeRow(time) { time = it }
                }
                DueRow(due) { due = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                if (err.isNotEmpty()) Text(err, color = RED)
            }
        },
        confirmButton = { TextButton(onClick = {
            val p = person.trim()
            val a = amount.toLongOrNull() ?: 0L
            if (p.isEmpty()) err = "Nhập tên người"
            else if (d == null) {
                if (a <= 0) err = "Nhập số tiền"
                else { Store.addDebt(Debt(System.nanoTime(), p, lend, a, Store.cur(wid), time, due, note), wid); onClose() }
            } else {
                val i = Store.debts.indexOfFirst { it.id == d.id }
                if (i >= 0) Store.debts[i] = d.copy(person = p, due = due, note = note)
                Store.save(); onClose()
            }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun ReportSwitch(on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = on, onCheckedChange = onChange)
        Text("  Tính vào báo cáo tổng", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun TransferDialog(t: Tx?, onClose: () -> Unit) {
    val inLeg = t?.let { x -> Store.txs.firstOrNull { it.transferId == x.transferId && it.income } }
    var amount by remember { mutableStateOf(t?.amount?.toString() ?: "") }
    var from by remember { mutableLongStateOf(t?.walletId ?: Store.wallets.first().id) }
    var to by remember { mutableLongStateOf(inLeg?.walletId ?: Store.defaultTo(from)) }
    var time by remember { mutableLongStateOf(t?.time ?: System.currentTimeMillis()) }
    var note by remember { mutableStateOf(t?.note ?: "") }
    var report by remember { mutableStateOf(t?.report ?: false) }
    var err by remember { mutableStateOf("") }
    val opts = Store.wallets.filter { it.id != from && it.currency == Store.cur(from) }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (t == null) "Chuyển tiền giữa ví" else "Sửa chuyển ví") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Số tiền (${Store.cur(from)})") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Pick("Từ: " + Store.walletName(from), Store.wallets.map { it.name }) { n ->
                    Store.wallets.firstOrNull { it.name == n }?.let { from = it.id; if (!Store.canTransfer(from, to)) to = Store.defaultTo(from) }
                }
                if (opts.isEmpty()) Text("Không có ví nào khác cùng đơn vị tiền (${Store.cur(from)}).", color = RED)
                else Pick("Đến: " + (Store.wallets.firstOrNull { it.id == to }?.name ?: "chọn ví"), opts.map { it.name }) { n ->
                    opts.firstOrNull { it.name == n }?.let { to = it.id }
                }
                DateTimeRow(time) { time = it }
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") })
                ReportSwitch(report) { report = it }
                if (err.isNotEmpty()) Text(err, color = RED)
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = amount.toLongOrNull() ?: 0L
            if (a <= 0) err = "Nhập số tiền"
            else if (!Store.canTransfer(from, to)) err = "Chọn hai ví khác nhau và cùng đơn vị tiền"
            else {
                if (t != null) Store.deleteTransfer(t.transferId)
                Store.addTransfer(from, to, a, time, note, report, t?.transferId ?: System.nanoTime())
                onClose()
            }
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Hủy") } })
}

@Composable
fun AutoSavedCard(p: Pending) {
    var edit by remember { mutableStateOf(false) }
    val t = Store.txs.firstOrNull { it.id == p.txId }
    Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Column(Modifier.padding(10.dp)) {
            if (t == null) Text("🗑 Giao dịch đã bị xóa", style = MaterialTheme.typography.bodySmall) else {
                Text((if (t.income) "+" else "-") + t.fmt(), fontWeight = FontWeight.Bold, color = if (t.income) GREEN else RED)
                Text("${t.category} • ${Store.walletName(t.walletId)} • " + SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date(t.time)),
                    style = MaterialTheme.typography.bodySmall)
                if (t.note.isNotBlank()) Text("📝 ${t.note}", style = MaterialTheme.typography.bodySmall)
                Text("⚡ Đã tự lưu • tin cậy ${(p.conf * 100).toInt()}% — ${p.why}", style = MaterialTheme.typography.bodySmall, color = GREEN)
                Row {
                    TextButton(onClick = { Store.txs.remove(t); Store.save(); p.autoSaved = false; p.saved = false }) { Text("↩ Hoàn tác") }
                    TextButton(onClick = { edit = true }) { Text("✏️ Sửa") }
                }
            }
        }
    }
    if (edit && t != null) EditTxDialog(t) { edit = false }
}

@Composable
fun AutoSettings() {
    val n = Auto.learned()
    val caps = linkedMapOf("500k" to 500_000L, "1tr" to 1_000_000L, "2tr" to 2_000_000L, "5tr" to 5_000_000L, "10tr" to 10_000_000L)
    Section("Mức hiểu biết của AI") {
        Text("AI đã học từ $n giao dịch — ${Auto.level(n)}", fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { (n / 100f).coerceAtMost(1f) }, Modifier.fillMaxWidth())
        Text("Càng nhiều giao dịch, AI càng nhận ra thói quen (khoản hay gặp, ví hay dùng, số tiền thường thấy) và càng dám tự lưu.", style = MaterialTheme.typography.bodySmall)
    }
    Section("Tự động lưu") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Cho phép AI tự lưu", Modifier.weight(1f))
            Switch(Store.autoSave, { Store.autoSave = it; Store.save() })
        }
        Text("Độ tự tin tối thiểu: ${(Store.autoThreshold * 100).toInt()}%")
        Slider(Store.autoThreshold, { Store.autoThreshold = it }, valueRange = 0.6f..0.99f, onValueChangeFinished = { Store.save() })
        Text("Chỉ tự lưu khoản không quá")
        Chips(caps.keys.toList(), caps.entries.firstOrNull { it.value == Store.autoMax }?.key ?: "") { Store.autoMax = caps[it] ?: Store.autoMax; Store.save() }
        Text("Bắt đầu tự lưu khi đã học ít nhất (giao dịch)")
        Chips(listOf("10", "20", "50"), Store.autoMinData.toString()) { Store.autoMinData = it.toInt(); Store.save() }
    }
    Section("Luôn cần bạn xác nhận") {
        Text("Vay/nợ, trả nợ, chuyển ví, ví khác VND, khoản vượt hạn mức và khoản AI chưa đủ tự tin. Mọi khoản tự lưu đều có nút Hoàn tác và Sửa ngay trong khung chat.", style = MaterialTheme.typography.bodySmall)
    }
}
