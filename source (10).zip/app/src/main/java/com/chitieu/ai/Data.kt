package com.chitieu.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

val CATEGORIES = listOf("Ăn uống", "Di chuyển", "Mua sắm", "Hóa đơn", "Giải trí", "Sức khỏe",
    "Giáo dục", "Nhà cửa", "Du lịch", "Quà tặng", "Lương", "Thu nhập khác", "Khác")
val INCOME_CATS = setOf("Lương", "Thu nhập khác")
val CURRENCIES = linkedMapOf("VND" to "đ", "USD" to "\$", "EUR" to "€", "JPY" to "¥", "KRW" to "₩", "GBP" to "£", "THB" to "฿")

val PERSONAS = linkedMapOf(
    "Thân thiện" to "ấm áp, gần gũi, hay động viên, dùng emoji vừa phải",
    "Mỉa mai" to "mỉa mai, châm biếm duyên dáng khi người dùng tiêu tiền hoang phí, nhưng vẫn ghi chép chính xác",
    "Nghiêm khắc" to "như người mẹ nghiêm khắc, hay nhắc nhở tiết kiệm, càu nhàu nhẹ nhưng thương con",
    "Hài hước" to "vui nhộn, pha trò, chơi chữ, ví von hài hước",
    "Chuyên gia" to "chuyên nghiệp, ngắn gọn, đưa nhận xét tài chính thực tế",
    "Dễ thương" to "đáng yêu, nũng nịu, xưng em gọi anh/chị, nhiều emoji cute"
)

data class Wallet(val id: Long, val name: String, val currency: String)

data class Tx(val id: Long, val amount: Long, val income: Boolean, val walletId: Long,
              val category: String, val note: String, val time: Long, val debtId: Long = 0L,
              val transferId: Long = 0L, val report: Boolean = true)  // report=false: không tính vào báo cáo tổng

// Khoản vay/nợ. lend=false: mình đi vay (mình nợ); lend=true: mình cho vay (người khác nợ mình)
data class Debt(val id: Long, val person: String, val lend: Boolean, val principal: Long, val cur: String,
                val time: Long, val due: Long, val note: String)

class Pending(amount: Long, income: Boolean, walletId: Long, category: String, note: String, time: Long,
              kind: String = "tx", person: String = "", due: Long = 0L,
              toWalletId: Long = 0L, report: Boolean = true) {
    var kind by mutableStateOf(kind)   // tx | borrow | lend | repay | collect
    var person by mutableStateOf(person)
    var due by mutableLongStateOf(due)
    var error by mutableStateOf("")
    var toWalletId by mutableLongStateOf(toWalletId)
    var report by mutableStateOf(report)
    var conf by mutableFloatStateOf(0f)      // độ tin cậy tính từ lịch sử
    var why by mutableStateOf("")
    var auto = false                          // đủ tự tin để tự lưu
    var autoSaved by mutableStateOf(false)
    var txId by mutableLongStateOf(0L)
    var amount by mutableLongStateOf(amount)
    var income by mutableStateOf(income)
    var walletId by mutableLongStateOf(walletId)
    var category by mutableStateOf(category)
    var note by mutableStateOf(note)
    var time by mutableLongStateOf(time)
    var saved by mutableStateOf(false)
    var dismissed by mutableStateOf(false)
}

val KIND_LABELS = listOf("Chi tiêu", "Thu nhập", "Chuyển ví", "Vay", "Cho vay", "Trả nợ", "Thu nợ")
fun Pending.label() = when (kind) {
    "borrow" -> "Vay"; "lend" -> "Cho vay"; "repay" -> "Trả nợ"; "collect" -> "Thu nợ"; "transfer" -> "Chuyển ví"
    else -> if (income) "Thu nhập" else "Chi tiêu"
}
fun Pending.isIncome() = when (kind) { "borrow", "collect" -> true; "lend", "repay" -> false; else -> income }
fun Pending.setLabel(l: String) {
    if (l == "Chuyển ví") report = false else if (kind == "transfer") report = true
    when (l) {
        "Chi tiêu" -> { kind = "tx"; income = false }
        "Thu nhập" -> { kind = "tx"; income = true }
        "Chuyển ví" -> {
            kind = "transfer"
            if (!Store.canTransfer(walletId, toWalletId)) toWalletId = Store.defaultTo(walletId)
        }
        "Vay" -> kind = "borrow"
        "Cho vay" -> kind = "lend"
        "Trả nợ" -> kind = "repay"
        else -> kind = "collect"
    }
}

class Msg(val fromUser: Boolean, text: String, val pending: List<Pending> = emptyList()) {
    var text by mutableStateOf(text)
    var typing by mutableStateOf(false)
}

fun Long.vnd(): String = String.format(Locale.US, "%,d", this).replace(',', '.') + "đ"
fun Long.money(cur: String): String =
    if (cur == "VND") vnd() else (CURRENCIES[cur] ?: cur) + String.format(Locale.US, "%,d", this)
fun Tx.fmt(): String = amount.money(Store.cur(walletId))
fun sumByCur(l: List<Tx>): Map<String, Long> =
    l.groupBy { Store.cur(it.walletId) }.mapValues { e -> e.value.sumOf { it.amount } }
fun Map<String, Long>.show(): String =
    if (isEmpty()) "0đ" else entries.joinToString(" + ") { it.value.money(it.key) }

fun monthStart(off: Int): Calendar = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, off)
}

// Mặc định bỏ qua giao dịch vay/nợ (không tính là thu/chi); withDebt=true để hiện trong sổ
fun txsOfMonth(off: Int, withDebt: Boolean = false): List<Tx> {
    val s = monthStart(off)
    val e = (s.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
    return Store.txs.filter { it.time >= s.timeInMillis && it.time < e.timeInMillis && (withDebt || (it.debtId == 0L && it.report)) }
}

object Store {
    private lateinit var sp: SharedPreferences
    val txs = mutableStateListOf<Tx>()
    val wallets = mutableStateListOf<Wallet>()
    val debts = mutableStateListOf<Debt>()
    val budgets = mutableStateMapOf<String, Long>()
    val chats = HashMap<Long, MutableList<Msg>>()   // mỗi ví một cuộc trò chuyện
    var chatWallet by mutableLongStateOf(0L)        // 0 = đang ở danh sách ví; khác 0 = đang mở chat của ví đó
    val busy = mutableStateListOf<Long>()            // các ví đang chờ AI trả lời
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    var apiKey by mutableStateOf("")
    var aiName by mutableStateOf("Mimi")
    var persona by mutableStateOf("Thân thiện")
    var model by mutableStateOf("gemini-2.5-flash")
    var userName by mutableStateOf("")
    var replyLen by mutableStateOf("Vừa")
    var temp by mutableFloatStateOf(0.5f)
    var typeEffect by mutableStateOf(true)
    var typeMs by mutableIntStateOf(3000)
    var maxRecSec by mutableIntStateOf(60)
    var themeMode by mutableStateOf("system")   // "system" | "light" | "dark"
    var systemDark by mutableStateOf(false)     // hệ thống đang ở chế độ tối (MainActivity cập nhật)
    // Chế độ du lịch
    var travelOn by mutableStateOf(false)
    var travelName by mutableStateOf("")
    var travelCur by mutableStateOf("USD")
    var travelRate by mutableDoubleStateOf(25400.0)   // 1 đơn vị ngoại tệ = ? VND
    var travelStart by mutableLongStateOf(0L)
    var travelEnd by mutableLongStateOf(0L)
    var autoSave by mutableStateOf(true)
    var autoThreshold by mutableFloatStateOf(0.85f)
    var autoMax by mutableLongStateOf(2_000_000L)
    var autoMinData by mutableIntStateOf(10)
    var voiceMode by mutableStateOf("gemini")   // "gemini" = ghi âm gửi Gemini nghe; "system" = nhận diện của máy

    fun walletName(id: Long) = wallets.firstOrNull { it.id == id }?.name ?: "(ví đã xóa)"
    fun cur(id: Long) = wallets.firstOrNull { it.id == id }?.currency ?: "VND"
    fun balance(w: Wallet) = txs.filter { it.walletId == w.id }.sumOf { if (it.income) it.amount else -it.amount }

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("chitieu", Context.MODE_PRIVATE)
        apiKey = sp.getString("key", "") ?: ""
        aiName = sp.getString("name", "Mimi") ?: "Mimi"
        persona = sp.getString("persona", "Thân thiện") ?: "Thân thiện"
        model = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        voiceMode = sp.getString("vmode", "gemini") ?: "gemini"
        userName = sp.getString("uname", "") ?: ""
        replyLen = sp.getString("rlen", "Vừa") ?: "Vừa"
        temp = sp.getFloat("temp", 0.5f)
        typeEffect = sp.getBoolean("fx", true)
        typeMs = sp.getInt("fxms", 3000)
        maxRecSec = sp.getInt("recsec", 60)
        themeMode = sp.getString("theme", "system") ?: "system"
        travelOn = sp.getBoolean("trOn", false)
        travelName = sp.getString("trName", "") ?: ""
        travelCur = sp.getString("trCur", "USD") ?: "USD"
        travelRate = sp.getString("trRate", null)?.toDoubleOrNull() ?: 25400.0
        travelStart = sp.getLong("trStart", 0L)
        travelEnd = sp.getLong("trEnd", 0L)
        autoSave = sp.getBoolean("autosave", true)
        autoThreshold = sp.getFloat("autothr", 0.85f)
        autoMax = sp.getLong("automax", 2_000_000L)
        autoMinData = sp.getInt("automin", 10)
        // ví: bản cũ lưu mảng tên (String), bản mới lưu object {id,name,cur}
        val w = JSONArray(sp.getString("wallets", "[]"))
        for (i in 0 until w.length()) {
            val e = w.get(i)
            if (e is JSONObject) wallets.add(Wallet(e.getLong("id"), e.getString("name"), e.optString("cur", "VND")))
            else wallets.add(Wallet(i + 1L, e.toString(), "VND"))
        }
        if (wallets.isEmpty()) listOf("Tiền mặt", "Ngân hàng", "Ví MoMo").forEachIndexed { i, n -> wallets.add(Wallet(i + 1L, n, "VND")) }
        val a = JSONArray(sp.getString("txs", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val wid = if (o.has("walletId")) o.getLong("walletId")
                else wallets.firstOrNull { it.name == o.optString("wallet") }?.id ?: wallets[0].id
            txs.add(Tx(o.getLong("id"), o.getLong("amount"), o.getBoolean("income"), wid,
                o.getString("category"), o.getString("note"), o.getLong("time"), o.optLong("debtId", 0L), o.optLong("transferId", 0L), o.optBoolean("report", true)))
        }
        val dj = JSONArray(sp.getString("debts", "[]"))
        for (i in 0 until dj.length()) {
            val o = dj.getJSONObject(i)
            debts.add(Debt(o.getLong("id"), o.getString("person"), o.getBoolean("lend"), o.getLong("principal"),
                o.optString("cur", "VND"), o.getLong("time"), o.optLong("due", 0L), o.optString("note")))
        }
        val b = JSONObject(sp.getString("budgets", "{}"))
        for (k in b.keys()) budgets[k] = b.getLong(k)
        val cj = JSONObject(sp.getString("chats", "{}"))
        for (k in cj.keys()) {
            val id = k.toLongOrNull() ?: continue
            if (wallets.none { it.id == id }) continue
            val arr = cj.getJSONArray(k)
            val l = mutableStateListOf<Msg>()
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); l.add(Msg(o.getBoolean("u"), o.getString("t"))) }
            if (l.isNotEmpty()) chats[id] = l
        }
    }

    fun welcome(wid: Long) = Msg(false, "Chào ${if (userName.isBlank()) "bạn" else userName.trim()}! 👋\nHôm nay mình giúp bạn quản lý tiền bạc nhé. Bạn muốn ghi lại khoản chi nào?\n(Ví: ${walletName(wid)} — ví dụ: \"sáng nay ăn phở 45k\")")

    fun chatOf(wid: Long): MutableList<Msg> = chats.getOrPut(wid) { mutableStateListOf(welcome(wid)) }

    /** wid == null: xóa tất cả cuộc trò chuyện; ngược lại chỉ xóa trang chat của ví đó. */
    fun resetChat(wid: Long? = null) {
        val ids = if (wid != null) listOf(wid) else chats.keys.toList()
        ids.forEach { id -> val l = chatOf(id); l.clear(); l.add(welcome(id)) }
        saveChats()
    }

    fun saveChats() {
        val o = JSONObject()
        chats.forEach { (id, l) ->
            if (wallets.none { it.id == id }) return@forEach
            val a = JSONArray()
            l.takeLast(40).forEach { a.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
            o.put(id.toString(), a)
        }
        sp.edit().putString("chats", o.toString()).apply()
    }

    fun add(t: Tx) { txs.add(t); save() }
    fun updateTx(t: Tx) { val i = txs.indexOfFirst { it.id == t.id }; if (i >= 0) { txs[i] = t; save() } }

    // moveTo != null: chuyển giao dịch sang ví khác; null: xóa luôn giao dịch của ví
    fun deleteWallet(id: Long, moveTo: Long?) {
        if (moveTo != null) { for (i in txs.indices) if (txs[i].walletId == id) txs[i] = txs[i].copy(walletId = moveTo) }
        else {
            val dead = debts.filter { d -> txs.any { it.id == d.id && it.walletId == id } }.map { it.id }.toSet()
            val tdead = txs.filter { it.walletId == id && it.transferId != 0L }.map { it.transferId }.toSet()
            txs.removeAll { it.walletId == id || it.debtId in dead || it.transferId in tdead }
            debts.removeAll { it.id in dead }
        }
        wallets.removeAll { it.id == id }
        chats.remove(id)
        save(); saveChats()
    }

    // ---- Chuyển ví: 2 dòng (ra/vào) cùng transferId; chỉ cho phép hai ví khác nhau, cùng đơn vị tiền
    fun canTransfer(from: Long, to: Long) =
        from != to && wallets.any { it.id == from } && wallets.any { it.id == to } && cur(from) == cur(to)
    fun defaultTo(from: Long) = wallets.firstOrNull { it.id != from && it.currency == cur(from) }?.id ?: 0L

    fun addTransfer(from: Long, to: Long, amount: Long, time: Long, note: String, report: Boolean, tid: Long = System.nanoTime()) {
        txs.add(Tx(tid, amount, false, from, "Chuyển ví", note, time, 0L, tid, report))
        txs.add(Tx(tid + 1, amount, true, to, "Chuyển ví", note, time, 0L, tid, report))
        save()
    }
    fun deleteTransfer(tid: Long) { txs.removeAll { it.transferId == tid }; save() }

    // ---- Vay / nợ: gốc và các lần trả đều là Tx có debtId, nên số dư ví luôn đúng
    fun paid(d: Debt) = txs.filter { it.debtId == d.id && it.id != d.id }.sumOf { it.amount }
    fun remaining(d: Debt) = d.principal - paid(d)

    fun addDebt(d: Debt, walletId: Long) {
        debts.add(d)
        txs.add(Tx(d.id, d.principal, !d.lend, walletId, if (d.lend) "Cho vay" else "Vay nợ",
            listOf(d.person, d.note).filter { it.isNotBlank() }.joinToString(" – "), d.time, d.id))
        save()
    }

    fun addPayment(d: Debt, amount: Long, walletId: Long, time: Long, note: String) {
        txs.add(Tx(System.nanoTime(), amount, d.lend, walletId, if (d.lend) "Thu nợ" else "Trả nợ", note.ifBlank { d.person }, time, d.id))
        save()
    }

    fun deleteDebt(d: Debt) { txs.removeAll { it.debtId == d.id }; debts.removeAll { it.id == d.id }; save() }

    /** Lưu thẻ xem trước từ chat. Trả về thông báo lỗi, null nếu thành công. */
    fun savePending(p: Pending): String? {
        when (p.kind) {
            "tx" -> {
                val t = Tx(System.nanoTime(), p.amount, p.income, p.walletId, p.category, p.note, p.time, 0L, 0L, p.report)
                add(t); p.txId = t.id
            }
            "transfer" -> {
                if (!canTransfer(p.walletId, p.toWalletId)) return "Chỉ chuyển giữa hai ví khác nhau và cùng đơn vị tiền"
                addTransfer(p.walletId, p.toWalletId, p.amount, p.time, p.note, p.report)
            }
            "borrow", "lend" -> {
                if (p.person.isBlank()) return "Cần nhập tên người"
                addDebt(Debt(System.nanoTime(), p.person.trim(), p.kind == "lend", p.amount, cur(p.walletId), p.time, p.due, p.note), p.walletId)
            }
            else -> {
                val lend = p.kind == "collect"
                val name = p.person.trim()
                val d = debts.firstOrNull { it.lend == lend && remaining(it) > 0 && name.isNotEmpty() &&
                    (it.person.contains(name, true) || name.contains(it.person, true)) }
                    ?: return "Không thấy khoản ${if (lend) "cho vay" else "đang nợ"} nào với \"$name\". Hãy sửa tên hoặc chọn loại Vay/Cho vay."
                if (cur(p.walletId) != d.cur) return "Ví này khác đơn vị tiền với khoản nợ (${d.cur})"
                addPayment(d, minOf(p.amount, remaining(d)), p.walletId, p.time, p.note)
            }
        }
        return null
    }

    fun save() {
        val a = JSONArray()
        txs.forEach { a.put(JSONObject().put("id", it.id).put("amount", it.amount).put("income", it.income)
            .put("walletId", it.walletId).put("category", it.category).put("note", it.note).put("time", it.time).put("debtId", it.debtId).put("transferId", it.transferId).put("report", it.report)) }
        val w = JSONArray()
        wallets.forEach { w.put(JSONObject().put("id", it.id).put("name", it.name).put("cur", it.currency)) }
        val dj = JSONArray()
        debts.forEach { dj.put(JSONObject().put("id", it.id).put("person", it.person).put("lend", it.lend).put("principal", it.principal)
            .put("cur", it.cur).put("time", it.time).put("due", it.due).put("note", it.note)) }
        val b = JSONObject(); budgets.forEach { (k, v) -> b.put(k, v) }
        sp.edit().putString("txs", a.toString()).putString("wallets", w.toString())
            .putString("debts", dj.toString()).putString("budgets", b.toString()).putString("key", apiKey).putString("name", aiName)
            .putString("persona", persona).putString("model", model).putString("vmode", voiceMode)
            .putString("uname", userName).putString("rlen", replyLen).putFloat("temp", temp)
            .putString("theme", themeMode).putBoolean("trOn", travelOn).putString("trName", travelName).putString("trCur", travelCur)
            .putString("trRate", travelRate.toString()).putLong("trStart", travelStart).putLong("trEnd", travelEnd).putBoolean("fx", typeEffect).putInt("fxms", typeMs).putInt("recsec", maxRecSec)
            .putBoolean("autosave", autoSave).putFloat("autothr", autoThreshold).putLong("automax", autoMax).putInt("automin", autoMinData).apply()
    }
}
