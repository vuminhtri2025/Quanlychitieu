@file:OptIn(ExperimentalMaterial3Api::class)

package com.chitieu.ai

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Calendar

/** Tab Giao dịch: gộp thống kê (tổng Thu/Chi, donut, dòng tiền) và sổ giao dịch trong một trang cuộn. */
@Composable
fun TransactionsScreen() {
    var sel by remember { mutableLongStateOf(0L) }       // 0 = tổng cộng (tất cả ví)
    var picker by remember { mutableStateOf(false) }
    var range by remember { mutableIntStateOf(0) }      // 0 = theo tháng, 1 = 6 tháng gần nhất
    var off by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(0) }
    var showAllCats by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    var transferring by remember { mutableStateOf(false) }
    var dayPick by remember { mutableIntStateOf(0) }      // ngày đang mở trong lịch (0 = không)
    var addTime by remember { mutableLongStateOf(0L) }    // > 0: đang thêm giao dịch với giờ này
    val ctx = LocalContext.current

    val wallet = Store.wallets.firstOrNull { it.id == sel }
    val curSel = wallet?.currency ?: "VND"
    fun inScope(t: Tx) = wallet == null || t.walletId == wallet.id
    val balText = if (wallet != null) Store.balance(wallet).money(wallet.currency)
        else Store.wallets.groupBy { it.currency }.mapValues { e -> e.value.sumOf { Store.balance(it) } }.show()

    val offs = if (range == 0) listOf(off) else (-5..0).toList()
    // số liệu báo cáo (không tính chuyển ví / giao dịch tắt báo cáo)
    val m = offs.flatMap { txsOfMonth(it) }.filter { inScope(it) }
    val thu = sumByCur(m.filter { it.income })
    val chiAll = sumByCur(m.filter { !it.income })
    val net = (thu.keys + chiAll.keys).associateWith { (thu[it] ?: 0L) - (chiAll[it] ?: 0L) }
    val chi = m.filter { !it.income && Store.cur(it.walletId) == curSel }
    val total = chi.sumOf { it.amount }
    // tổng thu/chi theo ngày cho lịch (chỉ khi xem theo tháng)
    val dayExp = LongArray(32)
    val dayInc = LongArray(32)
    if (range == 0) {
        m.filter { Store.cur(it.walletId) == curSel }.forEach { tx ->
            val d = Calendar.getInstance().apply { timeInMillis = tx.time }.get(Calendar.DAY_OF_MONTH)
            if (tx.income) dayInc[d] += tx.amount else dayExp[d] += tx.amount
        }
    }
    val byCat = chi.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }

    // dòng tiền (theo đơn vị tiền của ví đang chọn, mặc định VND): lũy kế theo ngày (1 tháng) hoặc tổng theo tháng (6 tháng)
    val vndIds = Store.wallets.filter { it.currency == curSel }.map { it.id }.toSet()
    val a = ArrayList<Float>()
    val b = ArrayList<Float>()
    val labels: List<String>
    val flowTitle: String
    if (range == 0) {
        val days = if (off == 0) Calendar.getInstance().get(Calendar.DAY_OF_MONTH) else monthStart(off).getActualMaximum(Calendar.DAY_OF_MONTH)
        val tin = LongArray(days + 1)
        val tout = LongArray(days + 1)
        m.filter { it.walletId in vndIds }.forEach { t ->
            val d = Calendar.getInstance().apply { timeInMillis = t.time }.get(Calendar.DAY_OF_MONTH)
            if (d in 1..days) { if (t.income) tin[d] += t.amount else tout[d] += t.amount }
        }
        var ci = 0L
        var co = 0L
        for (d in 1..days) { ci += tin[d]; co += tout[d]; a.add(ci.toFloat()); b.add(co.toFloat()) }
        labels = listOf(1, 1 + (days - 1) / 4, 1 + (days - 1) / 2, 1 + 3 * (days - 1) / 4, days).distinct().map { it.toString() }
        flowTitle = "Dòng tiền trong tháng (lũy kế)"
    } else {
        offs.forEach { o ->
            val mm = txsOfMonth(o).filter { inScope(it) && it.walletId in vndIds }
            a.add(mm.filter { it.income }.sumOf { it.amount }.toFloat())
            b.add(mm.filter { !it.income }.sumOf { it.amount }.toFloat())
        }
        labels = offs.map { "T" + (monthStart(it).get(Calendar.MONTH) + 1) }
        flowTitle = "Dòng tiền theo tháng"
    }
    val maxV = maxOf(a.maxOrNull() ?: 0f, b.maxOrNull() ?: 0f).coerceAtLeast(1f)

    // danh sách giao dịch (có chuyển ví, mỗi lần chuyển chỉ hiện một dòng)
    val all = offs.flatMap { txsOfMonth(it, true) }.filter { inScope(it) && (wallet != null || !(it.transferId != 0L && it.income)) }
    val list = when (filter) {
        1 -> all.filter { it.income && it.transferId == 0L }
        2 -> all.filter { !it.income && it.transferId == 0L }
        3 -> all.filter { it.transferId != 0L }
        else -> all
    }.sortedByDescending { it.time }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Giao dịch") {
            RoundBtn(onClick = { transferring = true }, bg = Lilac) { Text("🔁", fontSize = 20.sp) }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.weight(1f, fill = false).clip(CircleShape).background(Paper).clickable { picker = true }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (wallet == null) "🌐" else "👛", fontSize = 18.sp)
                        Spacer(Modifier.width(6.dp))
                        Text(wallet?.name ?: "Tổng cộng", Modifier.weight(1f, fill = false), fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.width(6.dp))
                        Text("⇅", color = Muted, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Số dư", color = Muted, fontSize = 13.sp, maxLines = 1, softWrap = false)
                        Spacer(Modifier.width(6.dp))
                        Text(balText, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
                            color = if (wallet != null && Store.balance(wallet) < 0L) Coral else Charcoal)
                    }
                }
            }
            item { PillTabs(listOf("Theo tháng", "6 tháng"), range) { range = it } }
            item {
                if (range == 0) MonthBar(off) { off = it }
                else Text("6 tháng gần nhất", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp))
            }
            if (range == 0) item { MonthCalendar(off, dayExp, dayInc, dayPick) { dayPick = it } }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SumCard("Thu", "+" + thu.show(), Fresh, FreshSoft, Modifier.weight(1f))
                        SumCard("Chi", "-" + chiAll.show(), Coral, CoralSoft, Modifier.weight(1f))
                    }
                    Text("Còn lại: " + net.show(), color = if (net.values.sum() >= 0L) Fresh else Coral, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 4.dp))
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Chi tiêu theo danh mục ($curSel)", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        CategoryDonut(topCats(chi, 4), total, "Chi tiêu") { it.money(curSel) }
                        if (byCat.size > 1) {
                            Text(
                                if (showAllCats) "Ẩn chi tiết ▴" else "Chi tiết theo mục ▾",
                                color = Fresh, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                                modifier = Modifier.clickable { showAllCats = !showAllCats }
                            )
                            if (showAllCats) {
                                byCat.forEach { (k, v) ->
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(catEmoji(k) + "  " + k, Modifier.weight(1f), fontSize = 14.sp)
                                            Text("${v.money(curSel)} (${if (total > 0L) v * 100 / total else 0}%)", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        }
                                        Bar(if (total > 0L) v.toFloat() / total else 0f, catColor(k))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(flowTitle, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            LegendDot(Fresh, "Thu")
                            Spacer(Modifier.width(10.dp))
                            LegendDot(Coral, "Chi")
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth().height(150.dp)) {
                            Column(Modifier.fillMaxHeight().padding(end = 8.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Text(maxV.toLong().shortVnd(), fontSize = 11.sp, color = Muted)
                                Text((maxV / 2).toLong().shortVnd(), fontSize = 11.sp, color = Muted)
                                Text("0", fontSize = 11.sp, color = Muted)
                            }
                            LineChart(a, b, Fresh, Coral, maxV, Modifier.weight(1f).fillMaxHeight())
                        }
                        Row(Modifier.fillMaxWidth().padding(start = 36.dp, top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            labels.forEach { Text(it, fontSize = 11.sp, color = Muted) }
                        }
                    }
                }
            }
            item { Text("Danh sách giao dịch", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp)) }
            item { PillTabs(listOf("Tất cả", "Thu", "Chi", "Chuyển"), filter) { filter = it } }
            if (list.isEmpty()) item { Text("Chưa có giao dịch.", color = Muted, modifier = Modifier.padding(16.dp)) }
            items(list, key = { it.id }) { t ->
                TxRow(t, signed = wallet != null) {
                    // chuyển ví: luôn sửa từ chân "chuyển đi" (hộp thoại tự lấy chân nhận)
                    if (t.debtId == 0L) editing = if (t.transferId != 0L) (Store.txs.firstOrNull { it.transferId == t.transferId && !it.income } ?: t) else t
                    else Toast.makeText(ctx, "Khoản vay/nợ: sửa trong Tài khoản → Sổ nợ", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    editing?.let { if (it.transferId != 0L) TransferDialog(it) { editing = null } else EditTxDialog(it) { editing = null } }
    if (transferring) TransferDialog(null) { transferring = false }
    if (dayPick > 0 && range == 0) {
        val dayStart = monthStart(off).apply { set(Calendar.DAY_OF_MONTH, dayPick) }.timeInMillis
        val dayEnd = monthStart(off).apply { set(Calendar.DAY_OF_MONTH, dayPick); add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
        DayDialog(
            dayStart, all.filter { it.time >= dayStart && it.time < dayEnd }.sortedBy { it.time }, wallet != null,
            onAdd = { addTime = timeOnDay(dayStart) },
            onEdit = { tx ->
                if (tx.debtId == 0L) editing = if (tx.transferId != 0L) (Store.txs.firstOrNull { it.transferId == tx.transferId && !it.income } ?: tx) else tx
                else Toast.makeText(ctx, "Khoản vay/nợ: sửa trong Tài khoản → Sổ nợ", Toast.LENGTH_SHORT).show()
            },
            onClose = { dayPick = 0 }
        )
    }
    if (addTime > 0L) AddTxDialog(addTime, wallet?.id ?: Store.wallets.first().id) { addTime = 0L }
    if (picker) WalletPicker(wallet?.id ?: 0L, onPick = { sel = it; picker = false }, onClose = { picker = false })
}

@Composable
private fun WalletPickRow(
    emoji: String, color: Color, name: String, sub: String, selected: Boolean, onClick: () -> Unit,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().background(if (selected) FreshSoft else Color.Transparent).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(if (selected) Fresh else Color.Transparent, CircleShape))
        Spacer(Modifier.width(10.dp))
        IconBubble(emoji, color, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

/** Màn "Chọn ví": Tổng cộng + từng ví (chạm để chọn, ⋯ để sửa/xóa, nút + để thêm ví). */
@Composable
private fun WalletPicker(selected: Long, onPick: (Long) -> Unit, onClose: () -> Unit) {
    var editW by remember { mutableStateOf<Wallet?>(null) }
    var delW by remember { mutableStateOf<Wallet?>(null) }
    var adding by remember { mutableStateOf(false) }
    var menuId by remember { mutableLongStateOf(0L) }
    val totals = Store.wallets.groupBy { it.currency }.mapValues { e -> e.value.sumOf { Store.balance(it) } }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Lavender)) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Đóng") }
                    Text("Chọn ví", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AppCard(Modifier.fillMaxWidth()) {
                        WalletPickRow("🌐", Color(0xFF3F8FE0), "Tổng cộng", totals.show(), selected == 0L, onClick = { onPick(0L) })
                    }
                    Text("Tính vào tổng", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
                    AppCard(Modifier.fillMaxWidth()) {
                        Store.wallets.toList().forEachIndexed { i, w ->
                            WalletPickRow(
                                "👛", Color(0xFFF2994A), w.name, Store.balance(w).money(w.currency), selected == w.id,
                                onClick = { onPick(w.id) }
                            ) {
                                Box {
                                    IconButton(onClick = { menuId = w.id }) { Icon(Icons.Default.MoreVert, contentDescription = "Tùy chọn") }
                                    DropdownMenu(expanded = menuId == w.id, onDismissRequest = { menuId = 0L }) {
                                        DropdownMenuItem(text = { Text("✏️ Sửa ví") }, onClick = { menuId = 0L; editW = w })
                                        if (Store.wallets.size > 1) DropdownMenuItem(text = { Text("🗑 Xóa ví") }, onClick = { menuId = 0L; delW = w })
                                    }
                                }
                            }
                            if (i < Store.wallets.size - 1) HorizontalDivider(Modifier.padding(start = 76.dp), color = Lilac)
                        }
                    }
                }
            }
            Box(Modifier.align(Alignment.BottomEnd).padding(24.dp)) {
                RoundBtn(onClick = { adding = true }, size = 60.dp) { Icon(Icons.Default.Add, contentDescription = "Thêm ví", tint = Color.White) }
            }
        }
    }
    editW?.let { WalletDialog(it) { editW = null } }
    if (adding) WalletDialog(null) { adding = false }
    delW?.let { DeleteWalletDialog(it) { delW = null } }
}
